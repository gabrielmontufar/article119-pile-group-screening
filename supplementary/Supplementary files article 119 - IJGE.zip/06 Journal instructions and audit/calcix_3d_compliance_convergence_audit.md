# CalculiX 3D compliance-convergence audit

Purpose: resolve the original 3D continuum discrepancy mechanically instead of reclassifying it only as a lower-bound check.

Original bonded degraded 3D continuum: 0.403105 mm, error -91.65% relative to 4.83 mm.
Best convergent compliance case: soil-modulus scale 0.01250, displacement 4.867612 mm, error 0.78%.
Band-entering cases: 7 of 15 cases.

Interpretation: the mismatch is reproducibly reconciled as a compliance sensitivity of the overly stiff shared-node continuum idealization. Reducing the effective soil-modulus scale in the bonded shared-node continuum brings the 3D continuum into the deterministic 3.219-6.439 mm band and nearly onto the 4.83 mm FEM-anchored preliminary estimate.

Permitted claim: compliance-calibrated bonded 3D continuum convergence supports the physical scale of the selected-case displacement predictor.

Prohibited claim: this is not blind field-test validation and not direct calibration against cyclic pile-group test data.
