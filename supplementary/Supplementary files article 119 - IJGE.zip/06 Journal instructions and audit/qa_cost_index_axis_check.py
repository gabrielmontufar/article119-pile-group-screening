from __future__ import annotations
import csv
import re
from pathlib import Path
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
FIG3 = ROOT / "02 Figures" / "Fig3_performance_cost_tradeoff.png"

def fail(msg):
    raise SystemExit("COST INDEX AXIS CONSISTENCY QA FAILED: " + msg)

cost_path = AUDIT / "canonical_cost_results.csv"
if not cost_path.exists():
    fail("missing canonical_cost_results.csv")
with cost_path.open(encoding="utf-8", newline="") as f:
    rows = list(csv.DictReader(f))
if len(rows) != 175:
    fail(f"unexpected canonical cost rows: {len(rows)}")
selected = [r for r in rows if r["selected_candidate"] == "yes"]
if len(selected) != 1:
    fail("expected one selected cost row")
s = selected[0]
if round(float(s["C_norm"]), 1) != 12.1:
    fail("selected C_norm does not round to 12.1")
if abs(float(s["C_raw"]) / float(s["C_ref"]) - float(s["C_norm"])) > 1e-4:
    fail("C_raw/C_ref != C_norm")
if not FIG3.exists():
    fail("Figure 3 file missing")
doc = Document(DOCX)
text = "\n".join([p.text for p in doc.paragraphs] + [cell.text for t in doc.tables for row in t.rows for cell in row.cells])
lower = text.lower()
for required in ["C_raw = 780 Vc + 145 Lt + 95 Ac", "C_norm = C_raw / C_ref", "C_ref = 1000", "Normalized cost index C_norm"]:
    if required not in text:
        fail(f"missing cost convention text: {required}")
if re.search(r"\b106\.1\b|\b139\.3\b|31\.3% premium", text):
    fail("legacy cost/premium remains")
if "Figure 3. Performance-cost trade-off for feasible 2x2 designs using the normalized cost index C_norm = C_raw / 1000" not in text:
    fail("Figure 3 caption does not specify normalized cost axis")
if "Cost index |" in text or "\nCost index\n" in text:
    fail("ambiguous Cost index header remains")
if "Reweighted normalized index C_norm,w" not in text:
    fail("Table 9 reweighted cost convention missing")
if "Comparable to baseline" not in text:
    fail("Table 9 comparability column missing")
print("COST INDEX AXIS CONSISTENCY QA PASSED")
