from pathlib import Path
from docx import Document
import csv, json, hashlib

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
SUPP = ROOT / "04 Supplementary"
BLIND = AUDIT / "blind_validation"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

for name in ["blind_inputs.csv","blind_predictions_frozen.csv","blind_outputs_revealed.csv","error_metrics.csv","README_blind_protocol.md","hash_manifest.json","source_manifest.csv"]:
    assert (BLIND/name).exists(), name
    assert (SUPP/"blind_validation"/name).exists(), "supplement missing "+name
manifest=json.loads((BLIND/"hash_manifest.json").read_text(encoding="utf-8"))
for key,file in [
    ("blind_inputs_sha256","blind_inputs.csv"),
    ("blind_predictions_frozen_sha256","blind_predictions_frozen.csv"),
    ("blind_outputs_revealed_sha256","blind_outputs_revealed.csv"),
    ("error_metrics_sha256","error_metrics.csv"),
]:
    assert manifest[key] == sha256(BLIND/file), key
inputs=list(csv.DictReader((BLIND/"blind_inputs.csv").open(encoding="utf-8")))
preds=list(csv.DictReader((BLIND/"blind_predictions_frozen.csv").open(encoding="utf-8")))
outs=list(csv.DictReader((BLIND/"blind_outputs_revealed.csv").open(encoding="utf-8")))
metrics=list(csv.DictReader((BLIND/"error_metrics.csv").open(encoding="utf-8")))
assert len(inputs)==3
assert len({r["case_id"] for r in inputs})==3
assert not any("GEOLAB" in r["source"].upper() for r in inputs)
assert all(r["outputs_hidden_at_prediction_time"]=="yes" for r in inputs)
assert len(preds)==len(outs)
assert all(r["revealed_after_prediction_freeze"]=="yes" for r in outs)
assert all(float(r["nrmse_by_measured_umax"]) < 0.25 for r in metrics)
text="\n".join(p.text for p in Document(DOCX).paragraphs)
for token in ["External blind validation protocol","blind_predictions_frozen.csv","blind_outputs_revealed.csv","0.115, 0.229 and 0.166","not selected-profile calibration"]:
    assert token in text, token
print("EXTERNAL_BLIND_VALIDATION_PROTOCOL_QA_PASSED")
