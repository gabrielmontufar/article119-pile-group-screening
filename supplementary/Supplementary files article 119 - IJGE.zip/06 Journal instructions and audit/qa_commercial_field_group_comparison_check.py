from __future__ import annotations
import csv
from pathlib import Path
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
FIG = ROOT / "02 Figures" / "Fig21b_commercial_field_group_comparison.png"

def fail(msg):
    raise SystemExit("COMMERCIAL FIELD GROUP COMPARISON QA FAILED: " + msg)

required_files = [
    "commercial_field_group_comparison_audit.md",
    "published_group_tests_inventory.csv",
    "practice_equivalent_group_py_benchmark.csv",
    "reproduce_practice_equivalent_group_py_benchmark.py",
    "reproduce_published_group_test_comparison.py",
]
for name in required_files:
    if not (AUDIT / name).exists():
        fail(f"missing {name}")
if not FIG.exists():
    fail("missing comparison figure")
doc = Document(DOCX)
text = "\n".join([p.text for p in doc.paragraphs] + [cell.text for t in doc.tables for row in t.rows for cell in row.cells])
for token in [
    "Commercial-tool and published group-test comparison boundary",
    "Table 11d. External comparison matrix",
    "Table 11e. Practice-equivalent p-y/p-multiplier comparison",
    "Table 11f. Published group tests screened",
    "reproducible practice-equivalent surrogate",
    "not a commercial software run",
    "No profile-matched commercial-tool output",
]:
    if token not in text:
        fail(f"missing DOCX token: {token}")
bad_claims = [
    "direct LPILE validation",
    "direct GROUP validation",
    "direct ALP validation",
    "commercial software validation",
    "field validation proves",
    "centrifuge validation proves",
    "outperforms commercial",
]
lower = text.lower()
for token in bad_claims:
    if token.lower() in lower:
        fail(f"unsupported claim: {token}")
bench = list(csv.DictReader((AUDIT / "practice_equivalent_group_py_benchmark.csv").open(encoding="utf-8")))
if not any(r["method"].startswith("Practice-equivalent Brown/Rollins") and r["predicted_displacement_mm"] for r in bench):
    fail("p-multiplier numerical surrogate missing")
inv = list(csv.DictReader((AUDIT / "published_group_tests_inventory.csv").open(encoding="utf-8")))
for required in ["Brown", "Rollins", "McVay", "GEOLAB", "ERIES"]:
    if not any(required in r["reference"] for r in inv):
        fail(f"inventory missing {required}")
print("COMMERCIAL FIELD GROUP COMPARISON QA PASSED")
