from __future__ import annotations
import csv, math
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = BASE / "reproducible_2x2_pipeline" / "data"
rows = list(csv.DictReader((DATA / "canonical_2x2_design_space.csv").open(encoding="utf-8")))
if len(rows) != 175:
    raise SystemExit(f"expected 175 alternatives, got {len(rows)}")
if {r["topology"] for r in rows} != {"2x2"}:
    raise SystemExit("non-2x2 topology found")
keys = [(r["topology"], r["D_m"], r["L_m"], r["spacing_D"]) for r in rows]
if len(keys) != len(set(keys)):
    raise SystemExit("duplicate design vectors found")
sel = [r for r in rows if r["selected_candidate"] == "yes"]
if len(sel) != 1:
    raise SystemExit("selected candidate count mismatch")
s = sel[0]
if not (s["D_m"] == "0.60" and s["L_m"] == "8.0" and s["spacing_D"] == "2.5"):
    raise SystemExit("selected candidate values mismatch")
D=float(s["D_m"]); L=float(s["L_m"]); Ac=float(s["Ac_m2"]); Vc=float(s["Vc_m3"]); Lt=float(s["Lt_m"])
C=780*Vc + 145*Lt + 95*Ac
if abs(C - float(s["C_raw"])) > 1e-3:
    raise SystemExit("C_raw formula mismatch")
if abs(C/1000 - float(s["C_norm"])) > 1e-6:
    raise SystemExit("C_norm formula mismatch")
for name in ["reproducibility_manifest.csv", "text_table_figure_consistency_matrix.csv", "enumeration_cardinality.csv"]:
    if not (DATA / name).exists():
        raise SystemExit(f"missing {name}")
print("REPRODUCIBLE 2X2 ENUMERATION QA PASSED")
