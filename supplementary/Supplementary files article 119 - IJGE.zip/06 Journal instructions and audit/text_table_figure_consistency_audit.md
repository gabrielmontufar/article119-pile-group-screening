# Text-table-figure consistency audit

| Section | Table/Figure | Current phrase | Text value/trend | Table value/trend | Figure value/trend | Reproducible source | Contradiction detected | Correction applied | Final status |
|---|---|---|---|---|---|---|---|---|---|
| Baseline text | Table 6 | identical utilization | identical | 0.640 vs 0.860 | n/a | table_06_baseline.csv | Contradiction | Replaced with utilization increases from 0.640 to 0.860 | corrected |
| Reserve check | Table 7/Fig. 6 | possible topology/cost premium legacy | none retained | 2x2 all rows; cost 12.1 to 12.2 | 2x2 reserve bars | table_07_reserve.csv; figure_06_reserve_check_source.csv | No current 4x3/4x4 support | Caption and text specify current 2x2 design space | corrected |
| Local sensitivity | Fig. 4 | almost proportional | normalized sensitivity 1.00 | canonical sensitivity source | near-proportional lateral-load line | figure_04_sensitivity_source.csv | Needs numeric support | Text now reports normalized sensitivity = 1.00 | corrected |
| Degradation sensitivity | Table 8/Fig. 7 | 175 to 174 and non-monotonic utilization | discrete design transition | spacing 2.5D to 3.0D at 4.0x | line dips at 4.0x | table_08_degradation.csv; figure_07_degradation_sensitivity_source.csv | Old compact table lacked design-change detail | Expanded Table 8 with D, L, spacing and displacement | corrected |
| Winkler check | Table 11/Fig. 8 | ranking/rank column | single case | one 2x2 row | single-case bar chart | table_11_winkler.csv; figure_08_winkler_ranking_source.csv | Rank language not applicable | Table 11 now has no rank column | corrected |

All sensitivity/reserve figures were regenerated from CSV source files in this audit folder. No multtopology reserve transition is reported for the current ERIES-aligned 2x2 canonical design set.