# Theoretical-mathematical solidity upgrade

## Executive diagnosis
| Section | Mathematical issue | Reviewer risk | Correction | Output |
|---|---|---|---|---|
| Methodology | finite set and feasible set implicit | optimization looks informal | define X, C_norm, g_j and x* | inserted text/table |
| Equivalent stiffness | equations listed but not derived | black-box screening | dimensional audit and derivation | inserted Table 2a |
| FEM anchoring | gamma_FEM could look arbitrary | overclaiming calibration | define deterministic anchoring operator | inserted text |
| 3D compliance | could look like arbitrary soil scaling | weak validation | define Omega_s/Omega_p/Omega_i and metrics | inserted text |
| Evidence stack | prediction, stress-test and benchmark can blur | desk/reviewer attack | separation table | inserted Table 24s |

## Formal optimization problem
Mathematical formulation of the finite screening problem
The reproduced design problem is a finite deterministic screening problem. The design vector is x = (D, L, rho), where rho = s/D. The candidate set is X = D_set x L_set x rho_set, with D_set = {0.60, 0.75, 0.90, 1.05, 1.20} m, L_set = {8, 10, 12, 14, 16, 18, 20} m and rho_set = {2.5, 3.0, 3.5, 4.0, 4.5}. Thus |X| = 175 for the fixed 2x2 layout. The screening problem is min C_norm(x) subject to g_j(x) <= 1, j = 1,...,m, and x in X. The reported solution is x* = argmin{C_norm(x): x in X and max_j g_j(x) <= 1}. The utilization functions include service displacement, pile-head rotation, bending stress, soil reaction and fatigue indices. Because X is finite and all C_norm and g_j values are regenerated from the canonical scripts and CSV files, exhaustive enumeration makes x* exactly reproducible within the declared grid.

## Dimensional consistency
Dimensional consistency and equivalent-stiffness assumptions
The equivalent-stiffness branch is used only as a screening idealization. EI has units of force times length squared, k is a subgrade modulus with units of force per length cubed, D is pile diameter, and T = (EI/(kD))^0.25 has units of length. The active lateral length Le = min(L, 3.5T) is therefore a length. The cantilever-equivalent stiffness k_single = 3EI/Le^3 has units of force per length, and K_group = n_piles eta_g k_single retains the same units because eta_g is dimensionless. The screening displacement u = H/K_group is a length. The cost index C_raw = 780Vc + 145Lt + 95Ac combines concrete volume, installed length and pile-cap footprint through normalized weights; C_norm = C_raw/1000 is therefore a reporting index, not a bid price. All constraints are expressed as dimensionless utilization ratios g_j <= 1.

## Derivations
The characteristic length T follows the classical Winkler scaling obtained by balancing pile bending stiffness and lateral soil reaction. The cutoff Le = min(L, 3.5T) is not a universal physical law; it is a screening truncation that prevents deeply embedded length from being fully credited when lateral response is concentrated near the pile head. The term k_single = 3EI/Le^3 is the translational stiffness of an equivalent cantilever idealization and therefore provides a secant stiffness scale rather than a nonlinear p-y solution. The group stiffness K_group = n_piles eta_g k_single treats eta_g as a spacing and interaction reduction factor, not as a universal p-multiplier. Finally, u_pred = gamma_FEM u_CalculiX is a deterministic anchoring operator; gamma_FEM in [1.0, 2.0] defines a model-bias screening band and is not a confidence interval inferred from field residuals.

## Propositions
- Finite-search reproducibility: If X and all C_norm, g_j functions are deterministic and regenerated from the same canonical source, then exhaustive enumeration reproduces x* exactly. Claim boundary: Supports reproducibility within the declared grid only.
- Load monotonicity: For positive K_group, u = H/K_group increases linearly with H within the screening branch. Claim boundary: Does not claim nonlinear p-y monotonicity outside the branch.
- Stiffness monotonicity: For positive EI, eta_g and Le, the equivalent displacement decreases as eta_g or EI increases, except at discrete branch changes induced by Le = min(L, 3.5T). Claim boundary: Branch transitions must be reported when finite differences cross them.
- Decision stability under finite perturbations: If the same candidate remains feasible and least-cost under prescribed reserve, cost and degradation perturbations, the decision is stable within that finite neighbourhood. Claim boundary: No claim of global optimality outside X or outside the perturbation set.
- Evidence hierarchy non-equivalence: Models that do not share geometry, profile, load range, measured variable and boundary conditions can support only consistency, scale or context, not direct validation. Claim boundary: Prevents ERIES/GEOLAB/Rollins/GROUP overclaiming.
- 3D interface-band stability: If recommended localized interface-compliance variants remain inside [3.219, 6.439] mm under mesh/domain perturbations, the model supports band stability for the declared numerical benchmark. Claim boundary: Not blind field validation or calibrated contact-law proof.

## 3D interface-compliance framework
Physically parameterized 3D interface-compliance benchmark
The 3D benchmark is represented as Omega = Omega_s union Omega_p union Omega_i, where Omega_s is the stratified soil continuum, Omega_p is the concrete pile domain and Omega_i is a localized interface-compliance zone around each pile. The interface modulus is written E_i(z) = beta_i E_s(z), with 0 < beta_i <= 1, and the interface thickness is t_i. Mesh and domain parameters are reported as horizontal element size h_xy, vertical element size h_z and characteristic domain width B. The metrics are e_band = I(u_3D in [u_low, u_high]), e_rel = |u_3D - u_pred|/u_pred, Delta_h = |u_hfine - u_hcoarse|/u_hfine and Delta_B = |u_Blarge - u_Bbase|/u_Blarge. A variant is band-stable when u_3D remains within 3.219-6.439 mm for the recommended interface variants and mesh/domain perturbations. These are editorial screening criteria, not code-based design tolerances.

## Sensitivity/uncertainty protocol
Use logarithmic elasticity S_q = d ln(u)/d ln(q) when the branch is continuous; otherwise use centered finite differences with epsilon = 0.05 or 0.10 and report whether the perturbation crosses Le = min(L,3.5T) or another discrete branch.
The interval 3.219-6.439 mm is a deterministic model-bias band generated by gamma_FEM in [1.0,2.0]; it is not a statistical confidence interval and is not inferred from field-test residuals.

## Additional calculations to run
| Priority | Calculation | Output | Pass/fail criterion |
|---|---|---|---|
| 1 | Recompute 175 candidates | canonical_results.csv | same selected x* |
| 1 | Dimensional audit | Table 2a | all core equations consistent |
| 2 | Local log elasticities | sensitivity table | signs match branch expectation |
| 2 | eta_g +/-20% | robustness row | claim narrowed if candidate changes |
| 2 | gamma_FEM [1,2] | band table | band reported as deterministic |
| 3 | 3D h_xy/h_z/domain/interface sweep | Table 24s/support CSV | recommended variants inside band |
| 3 | Falsifier table | claim ledger | every claim has escalation rule |

## Red-team attacks and fixes
- gamma_FEM is arbitrary. Is valid? valid if called calibration. Fix: define as deterministic anchoring factor and keep band non-statistical.
- 3D compliance is arbitrary. Is valid? partly valid. Fix: parameterize interface and claim band membership only.
- No blind validation. Is valid? valid. Fix: state this and limit to screening evidence.
- ERIES lacks force-displacement loops. Is valid? valid. Fix: use only impedance consistency.
- GEOLAB differs in scale/profile. Is valid? valid. Fix: use as measured group-response context.
- p-y and continuum are not equivalent. Is valid? valid. Fix: separate model-form checks.
- Cost is not economic. Is valid? valid if overread. Fix: call it normalized index.
- Sensitivity can cross branches. Is valid? valid. Fix: report branch crossing.
- Mesh convergence not formal enough. Is valid? partly valid. Fix: report Delta_h/Delta_B and band membership.
- Screening confused with design. Is valid? valid risk. Fix: repeat escalation rule.
