# V4-S validation audit

V4-S is defined as strong pre-design validation for the selected 2x2 screening domain. It is stronger than a narrative evidence hierarchy because it requires pass/fail criteria, numerical quantities, solver traces, uncertainty, external-evidence limits and QA. It is not described as field-test calibration, and it does not replace final project-specific p-y, commercial or continuum design analysis.
