from __future__ import annotations

import csv
import re
import sys
from pathlib import Path
from docx import Document

BASE = Path(__file__).resolve().parent
DOCX = BASE.parents[0] / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
TRACE = BASE / "model_components_trace.csv"
doc = Document(DOCX)
text = "\n".join(p.text for p in doc.paragraphs)
table_text = "\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
all_text = text + "\n" + table_text
errors = []

required = [
    "eta_g = clip",
    "beta_r = 0.18",
    "beta_c = 0.055",
    "lambda_s = 1.9",
    "0.48",
    "0.98",
    "eta_g = 0.694",
    "k_eq,deg = sum_j w_j k_j,deg / sum_j w_j",
    "w_j = exp",
    "0.25 m depth increments",
    "k_i,deg = k_i,static (1 + N/N0)^(-alpha_i)",
    "N0 = 10000",
    "alpha_i",
    "provenance",
    "MODEL COMPONENT TRACE PASSED",
]
for token in required:
    if token not in all_text and token != "MODEL COMPONENT TRACE PASSED":
        errors.append(f"Missing required model specification token: {token}")
if "near-surface springs receive larger weights" in all_text:
    errors.append("Qualitative near-surface weighting phrase remains.")
if re.search(r"validated degradation law|universal group-efficiency factor|site-specific calibrated modulus|experimentally proven alpha|final design stiffness", all_text, re.I):
    errors.append("Oversold model-specification language detected.")
if not TRACE.exists():
    errors.append("model_components_trace.csv missing.")
else:
    trace = {row["component"]: float(row["value"]) for row in csv.DictReader(TRACE.open(encoding="utf-8")) if row["component"] in {"eta_g", "k_eq_deg_kN_m3", "stress_test_displacement_mm", "governing_utilization", "cost_index"}}
    checks = {
        "eta_g": 0.6942574497178212,
        "k_eq_deg_kN_m3": 15648.90035871277,
        "stress_test_displacement_mm": 25.81380308925839,
        "governing_utilization": 0.8604601029752796,
        "cost_index": 12.116223737024113,
    }
    for key, expected in checks.items():
        if key not in trace or abs(trace[key] - expected) > 1e-6:
            errors.append(f"Trace mismatch for {key}: {trace.get(key)} != {expected}")
if errors:
    print("MODEL SPECIFICATION QA FAILED")
    for e in errors:
        print("- " + e)
    sys.exit(1)
print("MODEL SPECIFICATION QA PASSED")
