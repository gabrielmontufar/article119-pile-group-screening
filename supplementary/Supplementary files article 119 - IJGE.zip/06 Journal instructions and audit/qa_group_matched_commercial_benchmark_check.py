from __future__ import annotations
import csv
from pathlib import Path
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
csv_path = AUDIT / "group_matched_commercial_benchmark.csv"
if not csv_path.exists():
    raise SystemExit("GROUP MATCHED QA FAILED: csv missing")
doc = Document(DOCX)
text = "\n".join([p.text for p in doc.paragraphs] + [c.text for t in doc.tables for r in t.rows for c in r.cells])
for token in ["Table 11h. GROUP-matched non-equivalent software sanity check", "unanchored transfer", "one-parameter GROUP-anchored capsule", "not a holdout validation"]:
    if token not in text:
        raise SystemExit("GROUP MATCHED QA FAILED: missing " + token)
if "selected-case validation" in text and "not used as selected-case validation" not in text:
    raise SystemExit("GROUP MATCHED QA FAILED: selected-case validation overclaim")
print("GROUP MATCHED COMMERCIAL QA PASSED")
