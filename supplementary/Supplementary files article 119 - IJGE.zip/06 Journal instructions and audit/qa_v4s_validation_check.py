from __future__ import annotations
import csv, sys
from pathlib import Path
from docx import Document

BASE=Path(__file__).resolve().parent
DOCX=BASE.parents[0]/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc=Document(DOCX)
text="\n".join(p.text for p in doc.paragraphs)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
required=[
    "V4-S strong pre-design validation protocol",
    "Table 24e. V4-S strong pre-design validation scorecard.",
    "Table 24f. Quantitative V4-S validation quantities for the selected 2x2 case.",
    "Table 24g. Claims allowed after V4-S validation and claims still prohibited.",
    "u_pred = 4.83 mm",
    "P[u > 10 mm] = 2.07%",
    "PASS-WARN",
    "direct selected-profile cyclic group-test calibration",
]
for token in required:
    if token.lower() not in text.lower():
        errors.append("missing V4-S token: "+token)
bad=[
    "field-test calibration achieved",
    "validated by ERIES",
    "ERIES calibration",
    "proves absolute accuracy",
    "replacement of final project-specific",
]
for token in bad:
    if token.lower() in text.lower() and token != "replacement of final project-specific":
        errors.append("overclaim remains: "+token)
if "must not claim | replacement of final project-specific" not in text.lower() and "replacement of final project-specific p-y" in text.lower():
    pass
for f in ["v4s_validation_scorecard.csv","v4s_quantitative_validation_quantities.csv","v4s_allowed_and_prohibited_claims.csv","v4s_validation_audit.md"]:
    if not (BASE/f).exists():
        errors.append("missing "+f)
with (BASE/"v4s_validation_scorecard.csv").open(encoding="utf-8", newline="") as f:
    rows=list(csv.DictReader(f))
if len(rows) != 7:
    errors.append("V4-S scorecard must have 7 requirements")
if not any(r["result"] == "PASS-LB" for r in rows):
    errors.append("missing lower-bound pass classification")
if not any(r["result"] == "PASS-WARN" for r in rows):
    errors.append("missing warning pass classification")
if errors:
    print("V4-S VALIDATION QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("V4-S VALIDATION QA PASSED")
