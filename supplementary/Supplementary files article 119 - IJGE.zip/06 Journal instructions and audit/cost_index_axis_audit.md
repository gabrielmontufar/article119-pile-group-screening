# Cost-index and figure-axis audit

Convention selected: the manuscript reports the normalized weighted cost index `C_norm = C_raw / C_ref`, where `C_raw = 780Vc + 145Lt + 95Ac` and `C_ref = 1000`. All cost tables and cost-axis figures use `C_plot = C_norm`.

| Location | Reported cost value | Associated table/figure | Formula/value reproduced from code | Graphic scale | Discrepancy detected | Correction applied | Final status |
|---|---|---|---|---|---|---|---|
| Methods formula | C_raw = 780Vc + 145Lt + 95Ac; C_norm = C_raw/1000 | n/a | 12116.2 raw; 12.1 normalized for selected | Figure 3 uses C_norm | Old formula did not state /1000 | Declared C_ref = 1000 and C_norm convention | corrected |
| Table 4 | 12.1 | Selected candidate | C_raw=12116.2, C_norm=12.1 | same as Figure 3 | Cost scale ambiguous | Added C_raw and C_norm rows | corrected |
| Table 5 | 12.1 | Selected candidate | C_norm=12.1 | same as Figure 3 | Header said cost index only | Header changed to Normalized cost index C_norm | corrected |
| Table 7/Figure 6 | 12.1 to 12.2 | Reserve check | C_norm=12.1 to 12.2 | same normalized scale | Could be read as raw cost | Text and header changed to C_norm | corrected |
| Table 8 | 12.1/12.2 | Degradation sensitivity | C_norm values | not cost-axis figure | Header ambiguous | Header changed to C_norm | corrected |
| Table 9 | 10.7-13.5 | Cost-weight sensitivity | reweighted normalized index | not directly baseline-comparable under changed weights | Comparability unclear | Added comparable-to-baseline column | corrected |
| Figure 3 | C_norm range around 12.116224 | Performance-cost plot | selected C_norm=12.1 | x-axis C_norm from canonical CSV | Old axis could imply 50-175 legacy scale | Figure regenerated from canonical_cost_results.csv | corrected |
