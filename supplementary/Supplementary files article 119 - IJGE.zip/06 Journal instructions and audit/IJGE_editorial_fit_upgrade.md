# IJGE editorial-fit upgrade
## Recommended target
| Journal/type target | Fit | Emphasize | Reduce | Editorial risk |
|---|---:|---|---|---|
| International Journal of Geotechnical Engineering / applied computational geotechnics | 9/10 | Innovative application, numerical modelling, foundations, soil-pile interaction, reproducibility | Claims of field calibration or general topology optimization | Moderate: reviewer may ask for direct test calibration |
| Reliability/risk/geotechnical decision-support journal | 8.5/10 | Claim governance, CSI, uncertainty, escalation | Long pile-specific evidence stack | Risk: may want stronger formal reliability theory |
| Experimental geotechnics journal | 6/10 | GEOLAB/ERIES evidence | Solver-only validation | High: would require physical calibration |

Recommended principal target: International Journal of Geotechnical Engineering. Strategic second option: a reliability/risk/geotechnical decision-support outlet if IJGE rejects because of limited direct physical validation.

## Positioning sentence
The contribution is not a new p-y law, not a commercial-software replacement and not a general topology optimizer. It is a reproducible evidence-governed pre-design screening workflow for a declared 2x2 pile-group layout, where each numerical claim is linked to its source model, evidence tier, QA gate, falsifier and escalation rule.

## Title alternatives
| Title | Compatible profile | Advantage | Risk | Recommendation |
|---|---|---|---|---|
| Evidence-Governed Pre-Design Screening of an ERIES-Aligned Laterally Loaded 2x2 Pile Group under Cyclic Degradation | Applied/computational geotechnics | Best balance of scope and limits | Long but precise | Final |
| A Reproducible V4-S Evidence-Governed Screening Framework for Laterally Loaded Pile Groups | Computational methods | Emphasizes method | Less case-specific | Alternative |
| FEM-Anchored Preliminary Screening of an ERIES-Aligned 2x2 Laterally Loaded Pile Group | Numerical geotechnics | Highlights FEM anchor | Underplays governance | Good |
| Claim-Level Validation Governance for Preliminary Screening of Laterally Loaded Pile Groups | Reliability/decision support | Novel governance angle | May sound abstract | Second option |
| Fixed-Layout Diameter-Length-Spacing Screening for a Laterally Loaded Pile Group under Cyclic Degradation | Applied geotechnics | Very practical | Less novel | Usable |
| Evidence Hierarchies for Reproducible Pre-Design of Laterally Loaded Pile Groups | Decision support | Strong novelty framing | Less p-y explicit | Usable |
| A Reproducible Screening Capsule for Cyclic Laterally Loaded 2x2 Pile Groups | Reproducibility-focused | Clear capsule message | Narrower journal appeal | Backup |
| Pre-Design Escalation Rules for Laterally Loaded Pile Groups using p-y and FEM Evidence | Practice/numerical | Strong engineering utility | Less elegant | Backup |

## Revised abstract
Laterally loaded pile groups are commonly sized from a small set of regular layouts before nonlinear p-y, commercial group-analysis or continuum models are justified. The gap is not only computational: preliminary choices often lack an auditable link between screening assumptions, model-form evidence, uncertainty and the point at which escalation is required. This paper presents an evidence-governed pre-design screening workflow for a fixed ERIES-aligned 2x2 pile group under cyclic lateral loading. The workflow enumerates diameter, embedded length and spacing choices, applies cyclic-degradation and group-interaction screening factors, evaluates serviceability, soil reaction, bending and fatigue utilization, and records each numerical conclusion in a V4-S decision-validation passport with a Claim Support Index. For the declared case, the selected candidate is D = 0.60 m, L = 8.0 m and s/D = 2.5; displacement, rather than bending or fatigue, governs the decision. The central preliminary head displacement is 4.83 mm, with a FEM-anchored deterministic screening band of 3.219-6.439 mm and a separate 25.81 mm severe-degradation stress-test envelope. Evidence support is hierarchical: CalculiX and OpenSeesPy p-y implementations, a localized 3D interface-layer benchmark, uncertainty propagation and bounded GEOLAB/ERIES external checks support the screening-scale decision without claiming field calibration. The method is intended for auditable preliminary selection and escalation, not final design or site-specific nonlinear p-y/contact-FEM validation.

## Introduction closing
For this reason, the paper is framed around five practical design questions that are directly relevant to preliminary geotechnical engineering: which D-L-s/D candidate is feasible within a fixed 2x2 layout; whether displacement, soil reaction, fatigue or cost controls the selected candidate; how the decision changes when cyclic degradation is included; how defensible the preliminary displacement band is before project-specific calibration; and when the result must be escalated to nonlinear p-y analysis, three-dimensional FEM, commercial group-analysis software or physical testing. The proposed contribution is therefore a reproducible pre-design decision workflow, not a replacement for detailed site-specific pile-group design.

## Proposed structure
| Current section | Problem | New location | Action |
|---|---|---|---|
| Introduction | Needs explicit design questions | Introduction | Added practical five-question close |
| State of the art and contribution | Strong but broad | Literature positioning and contribution | Tighten to p-y, SSI, cyclic degradation and governance |
| Methodology | Mixes formulation and evidence | Fixed-topology pre-design screening workflow | Keep core model in main text |
| V4-S/CSI material | High value but dense | V4-S passport and CSI | Keep summary, move full ledgers to supplement |
| ERIES/GEOLAB/Rollins/GROUP details | Secondary evidence dominates | Evidence hierarchy + supplement | Keep maximum claims in main text |
| Discussion | Defensive tone risk | Scope, evidence hierarchy and escalation | Rewritten into can/cannot/useful blocks |
| Conclusions | Too long and mixed | Conclusions | Rewritten as six focused conclusions |

## Main text versus supplement
| Material | Main text | Supplement | Reason |
|---|---|---|---|
| Fixed 2x2 search and selected D-L-s/D | Yes | CSV trace | Central decision |
| V4-S passport and CSI summary | Yes | Full ledger | Novel contribution without overloading body |
| Multi-model displacement band | Yes | Scripts and raw outputs | Core evidence |
| ERIES details | Summary only | Full inventory/processing | Secondary geometry consistency |
| GEOLAB measured curve | Summary only | Full extraction | External scale check, not selected-profile calibration |
| Rollins/GROUP/Brown surrogate | Brief role statement | Full tables | Avoid secondary validation noise |
| CalculiX/OpenSeesPy scripts | Summary results | Full scripts | Reproducibility |

## Evidence hierarchy
| Evidence | Main-text role | Supplement role | Maximum claim |
|---|---|---|---|
| Fixed 2x2 enumeration | Primary | Full CSV | Selected candidate is reproducible in declared grid |
| CalculiX p-y + OpenSeesPy p-y | Primary | Solver scripts | Same-family model-form support for screening band |
| Localized 3D interface layer | Primary model-form bound | Mesh/domain traces | Continuum-style support, not field validation |
| V4-S passport/CSI | Primary governance | Full ledger | Claim-level auditability |
| ERIES impedance | Secondary | Trace processing | Geometry-consistent dynamic-response evidence |
| GEOLAB measured group response | Secondary | Extraction scripts | External measured stiffness/shape scale |
| Rollins/GROUP/Brown surrogate | Secondary | Documentation | Component/sanity checks only |

## Discussion text inserted
- What the framework can support. The workflow is intentionally positioned between hand calculations and project-specific nonlinear analysis. It supports preliminary D-L-s/D ranking within a fixed 2x2 layout, identification of the active design driver, a FEM-anchored preliminary displacement-screening band, degradation-sensitive feasibility checks and explicit escalation rules. This is useful because detailed pile-group analysis usually begins after an initial geometry family has already been chosen; the present workflow makes that early choice reproducible and reviewable.
- What the framework cannot support. The method is not a final design procedure, not a field-validated displacement predictor, not a general topology optimizer and not a commercial-tool equivalent. The cyclic-degradation exponents are transparent screening parameters rather than site-specific laboratory calibrations, and the group-efficiency factor should be replaced by project-specific p-multipliers, nonlinear p-y analyses or three-dimensional contact/interface modelling when design consequences are high.
- Why the workflow remains useful. The V4-S passport and Claim Support Index prevent unsupported conclusions from being hidden inside a single optimum. The selected 2x2 case shows how a candidate can be structurally conservative but serviceability-governed, and how the reported displacement should be read as a bounded screening quantity rather than as a field-calibrated prediction. ERIES, GEOLAB, Rollins, GROUP and continuum checks are therefore reported with restricted roles: they provide geometry consistency, measured group-response scale, component-level severe p-y behaviour, non-equivalent software sanity checking and model-form bounds, respectively, while the detailed evidence files remain in the reproducibility capsule.

## Conclusions inserted
- (1) This paper proposed an evidence-governed pre-design screening workflow for a fixed ERIES-aligned 2x2 pile group under cyclic lateral loading. The main transferable contribution is the V4-S passport and Claim Support Index, which convert preliminary geotechnical screening results into auditable claims with evidence tiers, QA gates, falsifiers and escalation rules.
- (2) For the declared three-layer profile and 100 kN lateral screening case, the selected candidate used D = 0.60 m, L = 8.0 m and s/D = 2.5. The result is not the stiffest available geometry; it is the least-cost feasible fixed-layout candidate after serviceability, soil-reaction, bending and fatigue screening.
- (3) Cyclic degradation changes the engineering interpretation by making displacement the active constraint while bending, soil reaction and fatigue remain below their limits. The workflow therefore identifies a serviceability-governed decision that a strength-only screening could miss.
- (4) The displacement result is reported as a FEM-anchored preliminary screening band. The central value is 4.83 mm, the deterministic model-bias band is 3.219-6.439 mm, and the 25.81 mm severe-degradation envelope is retained as a stress-test scenario rather than a central design prediction.
- (5) The evidence hierarchy supports the selected-case screening claim but does not convert the method into a field-calibrated design model. CalculiX/OpenSeesPy p-y checks, localized 3D interface-layer comparisons, uncertainty propagation and bounded external ERIES/GEOLAB checks have different evidentiary roles and are not interchangeable.
- (6) The method should be escalated to site-specific nonlinear p-y analysis, commercial group-analysis software, three-dimensional contact/interface FEM or physical testing whenever the candidate approaches serviceability limits, the soil profile is materially different, cyclic degradation governs acceptance or the design consequence is high.

## Fit-to-journal table
Inserted as Table 1a in the manuscript.

## Problematic language replacements
| Prior phrase | Replacement |
|---|---|
| disruptive element | main transferable contribution |
| absolute preliminary displacement band | FEM-anchored preliminary screening band |
| validation, where not direct | evidence support / model-form check / benchmark |
| optimized topology | fixed-layout candidate |
| confirmed by FEM | supported by model-form comparison |
| commercial benchmark | non-equivalent software sanity check |

## Checklist
| Criterion | Status | Action |
|---|---|---|
| Title reflects fixed-layout screening | Yes | Completed or retained |
| Abstract focused on problem, method, outputs and limits | Yes | Completed or retained |
| No new p-y law promised | Yes | Completed or retained |
| No general topology optimization promised | Yes | Completed or retained |
| V4-S formalized as method | Yes | Completed or retained |
| Secondary validation no longer dominates framing | Yes | Completed or retained |
| Editorial workflow figure created | Yes | Completed or retained |
| Allowed/prohibited claims clear | Yes | Completed or retained |
| Discussion organized as can/cannot/useful | Yes | Completed or retained |
| Conclusions design-oriented | Yes | Completed or retained |
| Supplement absorbs long traces | Yes | Completed or retained |
| CSV/scripts/QA remain clear | Yes | Completed or retained |
