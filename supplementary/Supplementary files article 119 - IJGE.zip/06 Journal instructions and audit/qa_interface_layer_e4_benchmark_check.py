from pathlib import Path
import csv, zipfile
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
ZIP_PATH = ROOT / "04 Supplementary" / "Supplementary files article 119 - IJGE.zip"

rows = list(csv.DictReader((AUDIT / "calcix_3d_interface_layer_benchmark.csv").open(encoding="utf-8")))
d = {r["case"]: r for r in rows}
for case in ["3D-6b_interface_very_low", "3D-6c_interface_extreme_low", "3D-6d_interface_thick_low", "3D-7_recommended_medium", "3D-7_recommended_fine", "3D-1_domain_large"]:
    assert d[case]["inside_3p219_6p439_band"] == "true", case
assert abs(float(d["3D-7_recommended_medium"]["mean_top_displacement_mm"]) - 4.143226) < 1e-6
assert abs(float(d["3D-7_recommended_fine"]["mean_top_displacement_mm"]) - 5.642838) < 1e-6

text = "\n".join(p.text for p in Document(DOCX).paragraphs)
for token in [
    "Physically parameterized 3D interface-layer benchmark",
    "Table 20g. Physically parameterized 3D interface-layer benchmark.",
    "4.143-5.734 mm",
    "not claim experimental calibration, fully converged contact FEM or final design verification",
]:
    assert token in text, f"Missing token: {token}"

with zipfile.ZipFile(ZIP_PATH, "r") as z:
    names = set(z.namelist())
    for name in [
        "06 Journal instructions and audit/calcix_3d_interface_layer_benchmark.csv",
        "06 Journal instructions and audit/interface_layer_e4_summary_table.csv",
        "06 Journal instructions and audit/interface_layer_e4_claim_audit.md",
        "04 Supplementary/calcix_3d_interface_layer_benchmark/3D-7_recommended_medium.dat",
        "04 Supplementary/calcix_3d_interface_layer_benchmark/3D-7_recommended_fine.dat",
    ]:
        assert name in names, f"Missing ZIP entry: {name}"

print("INTERFACE LAYER E4 BENCHMARK QA PASSED")
