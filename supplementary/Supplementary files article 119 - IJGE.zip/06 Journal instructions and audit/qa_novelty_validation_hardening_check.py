from __future__ import annotations
import sys
from pathlib import Path
from docx import Document

BASE=Path(__file__).resolve().parent
DOCX=BASE.parents[0]/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc=Document(DOCX)
text="\n".join(p.text for p in doc.paragraphs)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
required=[
    "Table 24b. Novelty stress test against the 2024-2026 frontier.",
    "Table 24c. Validation attack surface and strengthened evidence-to-claim mapping.",
    "Table 24d. Defensible contribution claims after validation hardening.",
    "fixed-layout D-L-s/D decision enumeration",
    "evidence-tiered validation protocol",
    "FEM-anchored preliminary screening band",
    "No new physical-test data were invented" # checked in audit below
]
for token in required[:-1]:
    if token.lower() not in text.lower():
        errors.append("missing manuscript token: "+token)
for bad in ["outperforms high-fidelity", "validated by ERIES", "ERIES calibration", "direct selected-profile field validation", "proves absolute accuracy"]:
    if bad.lower() in text.lower():
        errors.append("overclaim remains: "+bad)
for f in ["novelty_stress_test_2024_2026.csv","validation_attack_surface_claim_mapping.csv","defensible_contribution_claims.csv","novelty_validation_hardening_audit.md"]:
    if not (BASE/f).exists():
        errors.append("missing "+f)
audit=(BASE/"novelty_validation_hardening_audit.md").read_text(encoding="utf-8")
if required[-1].lower() not in audit.lower():
    errors.append("audit does not state no invented physical data")
if errors:
    print("NOVELTY VALIDATION HARDENING QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("NOVELTY VALIDATION HARDENING QA PASSED")
