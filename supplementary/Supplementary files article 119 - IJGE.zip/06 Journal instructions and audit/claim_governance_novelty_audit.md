# Claim-governance novelty audit

The manuscript novelty is formalized as claim-level validation governance rather than a new p-y law.

Added artifacts:
- `v4s_passport_canonical_claims.csv`: canonical claim passport with source, evidence tier, QA gate, falsifier, escalation rule and maximum defensible claim.
- `claim_support_index_csi.csv`: audit index classifying each claim by evidence, QA, reproducibility, independence and falsifier severity.
- `eries_aligned_2x2_screening_capsule/`: reusable benchmark capsule manifest, README, requirements and run_all script.

Allowed novelty claim: claim-governed, evidence-bounded, reproducible pre-design workflow for laterally loaded pile groups.
Prohibited novelty claim: new p-y law, general topology optimizer, experimental validation, or final-design predictor.
