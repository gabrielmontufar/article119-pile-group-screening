# Simplified screening, gamma_FEM and severe-envelope audit

The method is retained as a pre-design screening workflow, not a general displacement theory. The central factor 1.5 is formalized as gamma_FEM = 1.5 inside the deterministic interval [1.0, 2.0]. The 25.81 mm value remains a severe-degradation stress-test envelope and is not the principal prediction.

Required corrective artifacts: gamma_fem_sensitivity.csv, eta_g_sensitivity.csv, displacement_quantity_roles.csv, evidence_hierarchy_simplified_screening.csv, screening_use_rules.csv and alternative_model_displacement_comparison.csv.
