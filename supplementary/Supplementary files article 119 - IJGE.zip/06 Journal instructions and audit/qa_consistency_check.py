from __future__ import annotations

import re
import sys
from pathlib import Path
from docx import Document

DOCX = Path(__file__).resolve().parents[1] / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"

doc = Document(DOCX)
text = "\n".join(p.text for p in doc.paragraphs)
table_text = "\n".join(
    "\n".join(" | ".join(c.text for c in r.cells) for r in t.rows)
    for t in doc.tables
)
all_text = text + "\n" + table_text
errors = []

abstract = ""
for i, p in enumerate(doc.paragraphs):
    if p.text.strip().lower() == "abstract" and i + 1 < len(doc.paragraphs):
        abstract = doc.paragraphs[i + 1].text
        break

if "4.83 mm" not in abstract or "3.219-6.439 mm" not in abstract:
    errors.append("Abstract does not contain canonical 4.83 mm and 3.219-6.439 mm values.")
if "4.83 mm" not in all_text:
    errors.append("4.83 mm is absent from manuscript.")
if re.search(r"106\.1|139\.3", all_text):
    errors.append("Obsolete reserve-cost values 106.1/139.3 remain.")
if re.search(r"45\s+to\s+10|45-10|45[^.\n]{0,80}\b10\b", all_text, re.I):
    errors.append("Obsolete feasible-count claim 45 to 10 remains.")
if re.search(r"five evaluated topology-level optima|five topology|Spearman rank correlation\s*=\s*1\.00", all_text, re.I):
    errors.append("Unsupported five-topology/Spearman claim remains.")
if re.search(r"selected (?:screening )?candidate uses 1\.20 m|uses 1\.20 m piles", all_text, re.I):
    errors.append("Obsolete selected-candidate D=1.20 m wording remains.")
if re.search(r"25\.81 mm[^.\n]{0,80}(primary|calibrated preliminary|main prediction|principal calibrated)", all_text, re.I):
    errors.append("25.81 mm appears to be used as a primary calibrated prediction.")
if "Severe-degradation stress-test displacement | 25.81 mm" not in table_text and "Severe-degradation stress-test envelope | 25.81 mm" not in table_text:
    errors.append("Table 4 does not explicitly label 25.81 mm as stress-test envelope/displacement.")
if "FEM-anchored preliminary displacement | 4.83 mm" not in table_text and "Calibrated preliminary head displacement | 4.83 mm" not in table_text:
    errors.append("Table 4 does not explicitly label 4.83 mm as FEM-anchored preliminary displacement.")
if "2x2 | Feasible | 0.60 | 8 | 2.5D | 4.83 | 25.81" not in table_text or "0.860 from stress-test envelope" not in table_text:
    errors.append("Table 5 does not match canonical 2x2 row with utilization basis.")

captions = [p.text.strip() for p in doc.paragraphs if re.match(r"^(Table|Figure)\s+\d+\.", p.text.strip())]
seen = set()
dupes = []
for cap in captions:
    key = re.match(r"^(Table|Figure)\s+\d+\.", cap).group(0)
    if key in seen:
        dupes.append(key)
    seen.add(key)
if dupes:
    errors.append("Duplicate captions: " + ", ".join(sorted(set(dupes))))

if errors:
    print("CONSISTENCY QA FAILED")
    for err in errors:
        print("- " + err)
    sys.exit(1)
print("CONSISTENCY QA PASSED")
