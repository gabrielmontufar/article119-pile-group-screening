# Rollins benchmark audit

| Location | Previous claim | Value/report | Comparison type | Technical issue | Correction applied | Maximum defensible claim | Status |
|---|---|---|---|---|---|---|---|
| Section before Table 12 | external p-y benchmark/conservative check | Rollins liquefied sand vs selected design | average demand scale vs depth p-y | not profile matched; non-equivalent quantities | rewritten as limited severe p-y scale check | severe external scale context only | corrected |
| Table 12 | demand/p ratio treated as useful benchmark | shallow ratios 44.16 and 14.66 | non-equivalent scale comparison | average H/(nL) is not p_req(z) | table relabelled with equivalence warning | no adequacy claim | corrected |
| Figure 9 | visual external benchmark | ratio bars by depth | could imply validation | figure replaced with mismatch/non-equivalence warning | limited scale visualization only | corrected |
| Table 13/Figure 10 | calibration/validation language | same Rollins backbone train/holdout | same-backbone numerical fit | not independent design validation | relabelled surrogate fit | component fit only | corrected |
| Evidence hierarchy | external p-y scale check | Rollins row | hierarchy could overstate credibility | not stratified/profile matched | maximum claim narrowed | not profile-matched validation | corrected |
