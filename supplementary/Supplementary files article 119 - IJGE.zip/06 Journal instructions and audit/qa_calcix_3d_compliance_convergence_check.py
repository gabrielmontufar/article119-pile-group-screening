from __future__ import annotations

import csv
import zipfile
from pathlib import Path
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
CSV_PATH = ROOT / "06 Journal instructions and audit" / "calcix_3d_compliance_sensitivity.csv"
SUPP = ROOT / "04 Supplementary" / "calcix_3d_compliance_sensitivity"
ZIP_PATH = ROOT / "04 Supplementary" / "Supplementary files article 119 - IJGE.zip"

with CSV_PATH.open(newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
match = [r for r in rows if r["soil_modulus_scale"] == "0.01250"]
assert match, "Missing convergent compliance case in CSV"
r = match[0]
assert r["inside_3p219_6p439_band"] == "true", "Convergent case is not marked inside band"
assert abs(float(r["mean_top_displacement_mm"]) - 4.83) <= 0.05, "Convergent case is not close to 4.83 mm"

doc = Document(DOCX)
text = "\n".join(p.text for p in doc.paragraphs)
for needle in [
    "Table 24o. CalculiX 3D compliance-convergence sensitivity",
    "Table 24p. Interpretation of the 3D continuum convergence evidence",
    "4.867612",
    "not blind field-test validation",
]:
    assert needle in text, f"Missing manuscript evidence: {needle}"

for ext in [".inp", ".dat", ".frd", ".sta"]:
    assert (SUPP / f"continuum_degraded_soilscale_0p0125{ext}").exists(), f"Missing supplement case file {ext}"

with zipfile.ZipFile(ZIP_PATH, "r") as z:
    names = set(z.namelist())
    assert "06 Journal instructions and audit/calcix_3d_compliance_sensitivity.csv" in names
    assert "06 Journal instructions and audit/calcix_3d_compliance_convergence_audit.md" in names
    assert "04 Supplementary/calcix_3d_compliance_sensitivity/continuum_degraded_soilscale_0p0125.dat" in names

print("CALCULIX 3D COMPLIANCE CONVERGENCE QA PASSED")
