# Decision-validation passport audit

This hardening pass reframes the manuscript as a contribution to auditable preliminary geotechnical decision-making. The new passport does not invent stronger physical validation. It makes the existing numerical, experimental, commercial and reproducibility evidence more valuable by linking each claim to evidence files, QA gates, falsifiers and escalation rules. The intended novelty is methodological governance: a falsifiable claim ledger for degradation-aware pile-group screening.
