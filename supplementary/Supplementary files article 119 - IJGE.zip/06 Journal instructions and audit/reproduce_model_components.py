from __future__ import annotations

import csv
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
N = 100000.0
N0 = 10000.0
rows, cols, D, L, spacing_D = 2, 2, 0.60, 8.0, 2.5
H = 100.0
E = 30000000.0
layers = [
    ("Loose silty sand", 0.0, 4.0, 18000.0, 145.0, 0.18),
    ("Medium dense sand", 4.0, 11.0, 45000.0, 320.0, 0.14),
    ("Stiff sandy clay", 11.0, 22.0, 70000.0, 520.0, 0.10),
]

def layer_at(z):
    for layer in layers:
        if layer[1] <= z < layer[2]:
            return layer
    return layers[-1]

def eta_group(nr, nc, sd):
    penalty = (0.18*(nr-1) + 0.055*(nc-1)) * math.exp(-(sd-3.0)/1.9)
    return max(0.48, min(0.98, 1.0 - penalty))

dz = 0.25
points = []
for i in range(int(L/dz)):
    z = i*dz + dz/2
    layer = layer_at(z)
    w = math.exp(-z / max(2.5, 0.35*L))
    deg = (1 + N/N0) ** (-layer[5])
    kdeg = layer[3] * deg
    points.append((layer, z, w, deg, kdeg))
sw = sum(p[2] for p in points)
k_eq = sum(p[2]*p[4] for p in points) / sw
pult_eq = sum(p[2]*p[0][4] for p in points) / sw
eta = eta_group(rows, cols, spacing_D)
I = math.pi * D**4 / 64
T = (E * I / (k_eq * D)) ** 0.25
Le = min(L, 3.5*T)
k_single = 3 * E * I / Le**3
k_group = rows * cols * eta * k_single
u_mm = H / k_group * 1000
cap_area = ((cols-1)*spacing_D*D + D) * ((rows-1)*spacing_D*D + D)
concrete_volume = rows*cols * math.pi*D**2/4 * L
cost = (780*concrete_volume + 145*rows*cols*L + 95*cap_area)/1000
util = u_mm / 30.0

trace = {
    "eta_g": eta,
    "k_eq_deg_kN_m3": k_eq,
    "T_m": T,
    "Le_m": Le,
    "k_single_kN_m": k_single,
    "k_group_kN_m": k_group,
    "stress_test_displacement_mm": u_mm,
    "governing_utilization": util,
    "cost_index": cost,
}
with (OUT / "model_components_trace.csv").open("w", newline="", encoding="utf-8") as fh:
    writer = csv.writer(fh)
    writer.writerow(["component", "value", "unit"])
    for k, v in trace.items():
        writer.writerow([k, f"{v:.12g}", ""])

checks = [
    abs(eta - 0.6942574497178212) < 1e-9,
    abs(k_eq - 15648.90035871277) < 1e-6,
    abs(u_mm - 25.81380308925839) < 1e-6,
    abs(util - 0.8604601029752796) < 1e-9,
    abs(cost - 12.116223737024113) < 1e-9,
]
for key, value in trace.items():
    print(f"{key} = {value:.6g}")
if not all(checks):
    raise SystemExit("MODEL COMPONENT TRACE FAILED")
print("MODEL COMPONENT TRACE PASSED")
