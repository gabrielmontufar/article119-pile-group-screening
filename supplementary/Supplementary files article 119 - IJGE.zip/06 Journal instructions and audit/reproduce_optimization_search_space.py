from __future__ import annotations
import csv
from pathlib import Path

BASE = Path(__file__).resolve().parent
SPACE = BASE / "optimization_search_space.csv"
RESULTS = BASE / "optimization_results_canonical.csv"
DOCX = BASE.parent / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"

def read_csv(path):
    with path.open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))

space = read_csv(SPACE)
results = read_csv(RESULTS)
included = [r for r in space if r["included_in_final_search"] == "yes"]
topologies = sorted({r["topology"] for r in included})
if topologies != ["2x2"]:
    raise SystemExit(f"unexpected final topologies: {topologies}")
if len(included) != 175:
    raise SystemExit(f"unexpected candidate count: {len(included)}")
if len(results) != 175:
    raise SystemExit(f"unexpected result count: {len(results)}")
selected = [r for r in results if r.get("selected_candidate") == "yes"]
if len(selected) != 1:
    raise SystemExit("expected one selected candidate")
s = selected[0]
if not (s["topology"] == "2x2" and s["D_m"] == "0.60" and s["L_m"] == "8" and s["spacing_D"] == "2.5"):
    raise SystemExit("selected candidate mismatch")
try:
    from docx import Document
    doc = Document(DOCX)
    text = "\n".join([p.text for p in doc.paragraphs] + [cell.text for t in doc.tables for row in t.rows for cell in row.cells])
    if "175 alternatives: 1 topology x 5 diameters x 7 lengths x 5 spacing values" not in text:
        raise SystemExit("candidate-count statement missing from DOCX")
    if "Topology | 2x2 only" in text:
        pass
except ImportError:
    pass
print("OPTIMIZATION SEARCH SPACE REPRODUCED")
