from __future__ import annotations
from pathlib import Path
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
AUDIT = ROOT / "06 Journal instructions and audit"
doc = Document(DOCX)
text = "\n".join([p.text for p in doc.paragraphs] + [c.text for t in doc.tables for r in t.rows for c in r.cells])
bad = [
    "topology-aware design formulation",
    "topology-aware optimization",
    "topology selection",
    "topology as a design variable",
    "selected topology",
    "multi-topology rank",
]
for token in bad:
    if token.lower() in text.lower():
        raise SystemExit("TOPOLOGY FIXED QA FAILED: overclaim remains: " + token)
required = [
    "fixed-topology pre-design screening workflow",
    "ERIES-aligned 2x2",
    "does not claim general topology optimization",
    "175 ERIES-aligned 2x2 diameter-length-spacing candidate designs",
    "broader layout search would require regenerating",
]
for token in required:
    if token.lower() not in text.lower():
        raise SystemExit("TOPOLOGY FIXED QA FAILED: missing " + token)
for f in ["topology_aware_vs_2x2_fixed_audit.md", "topology_aware_vs_2x2_fixed_audit.csv"]:
    if not (AUDIT / f).exists():
        raise SystemExit("TOPOLOGY FIXED QA FAILED: missing " + f)
print("TOPOLOGY FIXED 2X2 QA PASSED")
