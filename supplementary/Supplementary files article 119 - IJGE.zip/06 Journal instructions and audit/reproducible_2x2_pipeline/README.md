# Reproducible 2x2 enumeration pipeline

Run scripts 01-08 from the scripts folder. The canonical source of truth is `data/canonical_2x2_design_space.csv`. The QA script verifies 175 alternatives, fixed 2x2 topology, unique design vectors, selected candidate values and the normalized cost formula.
