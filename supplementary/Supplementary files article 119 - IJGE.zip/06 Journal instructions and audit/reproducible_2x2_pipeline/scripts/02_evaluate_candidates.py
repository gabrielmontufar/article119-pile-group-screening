from pathlib import Path
import shutil
base=Path(__file__).resolve().parents[1]
shutil.copy2(base/'data'/'canonical_2x2_design_space.csv', base/'data'/'evaluated_candidates.csv')
print('evaluated candidates copied from canonical source of truth')
