from pathlib import Path
import csv
D=[0.60,0.75,0.90,1.05,1.20]; L=[8,10,12,14,16,18,20]; S=[2.5,3.0,3.5,4.0,4.5]
out=Path(__file__).resolve().parents[1]/'data'/'design_vectors_2x2.csv'
out.parent.mkdir(parents=True,exist_ok=True)
with out.open('w',newline='',encoding='utf-8') as f:
 w=csv.writer(f); w.writerow(['topology','D_m','L_m','spacing_D','candidate_id'])
 for d in D:
  for l in L:
   for s in S:
    w.writerow(['2x2',f'{d:.2f}',f'{l:.1f}',f'{s:.1f}',f'2x2_D{d:.2f}_L{l}_s{s:.1f}D'])
print('generated 175 design vectors')
