from pathlib import Path
import shutil
base=Path(__file__).resolve().parents[1]
for name in ['table_09_cost_weight.csv']:
 src=Path(__file__).resolve().parents[2]/name
 if src.exists(): shutil.copy2(src, base/'data'/name)
print('cost-weight sources staged')
