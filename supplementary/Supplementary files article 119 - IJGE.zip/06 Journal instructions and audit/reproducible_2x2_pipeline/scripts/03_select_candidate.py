from pathlib import Path
import csv
base=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader((base/'data'/'canonical_2x2_design_space.csv').open(encoding='utf-8')))
sel=[r for r in rows if r['selected_candidate']=='yes']
assert len(sel)==1
with (base/'data'/'selected_candidate.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(sel[0])); w.writeheader(); w.writerows(sel)
print('selected', sel[0]['candidate_id'])
