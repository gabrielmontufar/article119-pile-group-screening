from pathlib import Path
import shutil
base=Path(__file__).resolve().parents[1]
for name in ['Table_5_selected_candidate.csv','reproducibility_manifest.csv']:
 src=base/'tables'/name
 if src.exists(): shutil.copy2(src, base/'data'/name)
print('tables/figures are traceable through manifest')
