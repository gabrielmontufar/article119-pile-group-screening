from pathlib import Path
import shutil
base=Path(__file__).resolve().parents[1]
for name in ['table_07_reserve.csv','figure_06_reserve_check_source.csv']:
 src=Path(__file__).resolve().parents[2]/name
 if src.exists(): shutil.copy2(src, base/'data'/name)
print('reserve sources staged')
