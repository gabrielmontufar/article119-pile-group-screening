from pathlib import Path
import shutil
base=Path(__file__).resolve().parents[1]
for name in ['canonical_sensitivity_reserve_results.csv','figure_04_sensitivity_source.csv']:
 src=Path(__file__).resolve().parents[2]/name
 if src.exists(): shutil.copy2(src, base/'data'/name)
print('local sensitivity sources staged')
