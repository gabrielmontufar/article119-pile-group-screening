from __future__ import annotations
import csv, io, zipfile
from pathlib import Path

OUT = Path(__file__).resolve().parent


def find_rollins_source_rows() -> list[dict]:
    candidates = [
        OUT.parent / "supplementary_pile_group_optimization" / "data" / "external_rollins_py_benchmark.csv",
        OUT.parent.parent / "supplementary_pile_group_optimization" / "data" / "external_rollins_py_benchmark.csv",
    ]
    for path in candidates:
        if path.exists():
            return list(csv.DictReader(path.open(encoding="utf-8")))
    zip_candidates = [
        OUT.parent / "04 Supplementary" / "Supplementary files article 119 - IJGE.zip",
        OUT.parent / "Supplementary files article 119 - IJGE.zip",
    ]
    member = "supplementary_pile_group_optimization/data/external_rollins_py_benchmark.csv"
    for zip_path in zip_candidates:
        if zip_path.exists():
            with zipfile.ZipFile(zip_path) as zf:
                if member not in zf.namelist():
                    raise SystemExit("ROLLINS BENCHMARK TRACE FAILED: source CSV missing from ZIP")
                with zf.open(member) as fh:
                    text = io.TextIOWrapper(fh, encoding="utf-8")
                    return list(csv.DictReader(text))
    raise SystemExit("ROLLINS BENCHMARK TRACE FAILED: source CSV not found")


rows = []
for r in find_rollins_source_rows():
    p = float(r["rollins_p_at_selected_y_kN_per_m"])
    avg = float(r["selected_design_lateral_demand_kN_per_m_per_pile"])
    ratio = avg / max(p, 1e-12)
    depth = float(r["depth_m"])
    interp = "severe shallow-depth mismatch; no adequacy claim" if depth <= 2 else ("non-equivalent scale exceeds Rollins resistance; no adequacy claim" if ratio > 1 else "Rollins resistance exceeds average scale, but comparison remains non-equivalent")
    rows.append({
        "depth_m": depth,
        "selected_y_mm": float(r["selected_design_head_displacement_mm"]),
        "p_rollins_kN_per_m": p,
        "average_demand_scale_kN_per_m_per_pile": avg,
        "p_req_depth_specific_kN_per_m": "",
        "ratio_average_scale_to_rollins": ratio,
        "comparison_type": "non-equivalent scale comparison; average_demand_scale is not p_req(z)",
        "interpretation": interp,
        "allowed_claim": "limited severe p-y scale check only; not profile-matched validation",
    })
fields = ["depth_m", "selected_y_mm", "p_rollins_kN_per_m", "average_demand_scale_kN_per_m_per_pile", "p_req_depth_specific_kN_per_m", "ratio_average_scale_to_rollins", "comparison_type", "interpretation", "allowed_claim"]
with (OUT / "rollins_benchmark_trace.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    w.writerows(rows)
if any(r["p_req_depth_specific_kN_per_m"] for r in rows):
    raise SystemExit("ROLLINS BENCHMARK TRACE FAILED: average scale was mixed with p_req(z)")
if not any(float(r["ratio_average_scale_to_rollins"]) > 10 for r in rows):
    raise SystemExit("ROLLINS BENCHMARK TRACE FAILED: shallow mismatch not reproduced")
print("ROLLINS BENCHMARK TRACE PASSED")
