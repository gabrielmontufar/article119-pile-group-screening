# Displacement reconciliation audit

| Location | Reported value | Unit | Previous label | Correct meaning | Calculation source | Canonical match | Action |
|---|---:|---|---|---|---|---|---|
| Abstract | 4.83 | mm | calibrated absolute displacement | FEM-anchored preliminary prediction | 1.5 x CalculiX p-y FEM 3.219416 mm | yes | relabelled and formula added |
| Abstract/Table 21 | 3.219-6.439 | mm | prediction/uncertainty band | deterministic screening band | 1.0-2.0 x CalculiX p-y FEM | yes | deterministic basis stated |
| Table 4/Table 5 | 25.81 | mm | head/screening displacement | severe-degradation stress-test envelope | original screening model | yes | separated from principal prediction |
| Table 18/Table 21 | 3.219/3.22 | mm | CalculiX p-y displacement | independent p-y numerical anchor | CalculiX beam-spring p-y FEM | yes | retained as anchor |
| Table 11 | 2.55 | mm | independent Winkler displacement | independent elastic check | Winkler screening formula | yes | retained as check |
| Table 19/Table 21 | 0.403/0.286 | mm | CalculiX 3D continuum | stiff continuum lower-bound checks | CalculiX C3D8 continuum | yes | retained with limitation |
| Table 4/Table 5 | 0.860 | - | utilization | utilization from 25.81 mm stress-test envelope | 25.81/30 mm | yes | basis explicitly stated |
