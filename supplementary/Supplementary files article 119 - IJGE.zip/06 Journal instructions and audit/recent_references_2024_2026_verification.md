# Verification of 2024-2026 references

| Reference | DOI | Status | Title match | Year observed | Source |
|---|---|---|---|---|---|
| El-Garhy et al. 2025 | 10.28991/CEJ-2025-011-09-05 | Crossref HTTP 200 | yes | 2025 | https://api.crossref.org/works/10.28991%2FCEJ-2025-011-09-05 |
| He and Pan 2026 | 10.1016/j.marstruc.2025.103919 | Crossref HTTP 200 | yes | 2026 | https://api.crossref.org/works/10.1016%2Fj.marstruc.2025.103919 |
| Hong et al. 2024 | 10.1139/cgj-2023-0310 | Crossref HTTP 200 | partial (2/3) | 2024 | https://api.crossref.org/works/10.1139%2Fcgj-2023-0310 |
| Pitilakis et al. 2025 Zenodo | 10.5281/zenodo.15518567 | HTTP 200 | yes | yes | https://doi.org/10.5281/zenodo.15518567 |
| Di Laora et al. 2025 | 10.1007/978-3-031-98893-6_13 | Crossref HTTP 200 | yes | 2025 | https://api.crossref.org/works/10.1007%2F978-3-031-98893-6_13 |
| Li et al. 2025 | 10.48550/arXiv.2501.06232 | arXiv API HTTP 200 | yes | 2025 | https://export.arxiv.org/api/query?id_list=2501.06232 |
| Schlager et al. 2024 | 10.5281/zenodo.13373774 | HTTP 200 | yes | yes | https://doi.org/10.5281/zenodo.13373774 |
| Jiang and Chai 2025 | 10.1016/j.compgeo.2025.107277 | Crossref HTTP 200 | yes | 2025 | https://api.crossref.org/works/10.1016%2Fj.compgeo.2025.107277 |
| Zeng and Jiang 2025 | 10.1016/j.compgeo.2025.107499 | Crossref HTTP 200 | yes | 2025 | https://api.crossref.org/works/10.1016%2Fj.compgeo.2025.107499 |
| Zeng et al. 2025 | 10.1016/j.compgeo.2025.107413 | Crossref HTTP 200 | yes | 2025 | https://api.crossref.org/works/10.1016%2Fj.compgeo.2025.107413 |
| Zhu et al. 2025 | 10.1016/j.oceaneng.2025.122360 | Crossref HTTP 200 | yes | 2025 | https://api.crossref.org/works/10.1016%2Fj.oceaneng.2025.122360 |

Notes: DOI/API verification confirms bibliographic existence and broad title/year consistency. It does not substitute for reading every full article.
