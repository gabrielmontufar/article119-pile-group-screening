# Taylor & Francis Word template formatting audit

- Template used: TF_Template_Word_Windows_2016.dotx.
- The DOTX was converted to DOCX for style transfer because python-docx rejects DOTX content type.
- Applied template styles: Article title, Author names, Affiliation, Correspondence details, Abstract, Keywords, Heading 1, Heading 2, Paragraph, Table title, Figure caption, References.
- Backup before formatting: Cyclic Lateral Pile Group - IJGE manuscript - before TF template formatting.docx
- Formatted copy: Cyclic Lateral Pile Group - IJGE manuscript - TF template formatted.docx
