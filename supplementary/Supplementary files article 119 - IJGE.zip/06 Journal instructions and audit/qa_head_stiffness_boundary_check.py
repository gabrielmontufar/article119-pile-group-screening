from __future__ import annotations
import csv, re, sys
from pathlib import Path
from docx import Document
BASE=Path(__file__).resolve().parent
DOCX=BASE.parents[0]/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
CSV=BASE/"head_stiffness_boundary_cases.csv"
doc=Document(DOCX)
text="\n".join(p.text for p in doc.paragraphs)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
for token in ["cantilever-equivalent translational stiffness index","not a boundary-condition-exact p-y solution","Le = min(L, lambda_T T)","Table 29. Effective-length cutoff sensitivity","Table 30. Boundary-condition sensitivity","Table 31. Screening and CalculiX displacement comparison","head rotation is not an active independent prediction"]:
    if token not in text: errors.append("missing: "+token)
if "rotation = 0.000 mrad" in text or "Rotation = 0.000 mrad" in text: errors.append("rotation zero presented as result")
if re.search(r"rotation is zero because M\\s*=\\s*0", text, re.I): errors.append("M=0 used as sufficient rotation-zero reason")
if "CalculiX proves" in text or "validated boundary condition" in text: errors.append("overvalidation language")
if not CSV.exists(): errors.append("head_stiffness_boundary_cases.csv missing")
else:
    rows=list(csv.DictReader(CSV.open(encoding="utf-8")))
    if len(rows)<8: errors.append("boundary CSV incomplete")
    if not any(r["boundary_condition"]=="guided-head" for r in rows): errors.append("guided case missing")
if errors:
    print("HEAD STIFFNESS BOUNDARY QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("HEAD STIFFNESS BOUNDARY QA PASSED")
