# Interface-layer E4 benchmark claim audit

The added benchmark is a localized reduced-modulus interface-layer FEM model, not a global soil-modulus fit and not nonlinear contact.

Medium recommended interface case: 4.143 mm.
XY-fine case: 4.097 mm.
Z-fine case: 5.734 mm.
Fully fine case: 5.643 mm.
Large-domain case: 4.154 mm.

Interpretation: lateral mesh and domain-size checks are stable near 4.1-4.2 mm, while vertical refinement moves the result toward 5.6-5.7 mm. All recommended interface-layer checks remain inside the deterministic 3.219-6.439 mm band.

Allowed claim: band-stable open-source 3D interface-layer benchmark supporting the selected displacement scale.
Prohibited claim: fully mesh-converged contact FEM, blind validation, or measured displacement calibration.
