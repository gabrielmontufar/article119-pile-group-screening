from __future__ import annotations
import csv, sys
from pathlib import Path
from docx import Document

BASE=Path(__file__).resolve().parent
DOCX=BASE.parents[0]/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc=Document(DOCX)
text="\n".join(p.text for p in doc.paragraphs)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
for token in [
    "Direct open-data force-displacement validation add-on",
    "Table 24k. Direct GEOLAB measured force-displacement validation check.",
    "Table 24l. Normalized GEOLAB measured envelope versus linear screening shape.",
    "Figure 22. Direct GEOLAB measured force-displacement envelope",
    "not selected-profile calibration",
]:
    if token.lower() not in text.lower():
        errors.append("missing token: "+token)
for f in ["geolab_test4_force_displacement_downsampled.csv","geolab_test4_normalized_envelope.csv","geolab_test4_validation_summary.csv","geolab_direct_force_displacement_validation_audit.md"]:
    if not (BASE/f).exists():
        errors.append("missing "+f)
summary=list(csv.DictReader((BASE/"geolab_test4_validation_summary.csv").open(encoding="utf-8")))
if not summary:
    errors.append("empty summary")
else:
    rmse=float(summary[0]["normalized_rmse_vs_linear"])
    if not (0 <= rmse < 0.50):
        errors.append(f"unexpected normalized RMSE {rmse}")
if errors:
    print("GEOLAB DIRECT FORCE-DISPLACEMENT QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("GEOLAB DIRECT FORCE-DISPLACEMENT QA PASSED")
