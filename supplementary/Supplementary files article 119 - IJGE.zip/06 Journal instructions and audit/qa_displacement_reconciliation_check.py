from __future__ import annotations
import csv, re, sys
from pathlib import Path
from docx import Document
BASE=Path(__file__).resolve().parent
DOCX=BASE.parents[0]/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
TRACE=BASE/"displacement_calibration_trace.csv"
doc=Document(DOCX)
paras=[p.text for p in doc.paragraphs]
text="\n".join(paras)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
abstract=""
for i,p in enumerate(paras):
    if p.strip().lower()=="abstract" and i+1 < len(paras): abstract=paras[i+1]
if "4.83 mm" not in abstract: errors.append("4.83 mm missing from abstract")
if "25.81 mm" not in abstract or "stress-test envelope" not in abstract: errors.append("25.81 stress-test distinction missing from abstract")
results_tail="\n".join(paras[90:170])
if "1.5 x 3.219 mm" not in results_tail: errors.append("formula for 4.83 missing from Results")
if "gamma_FEM in [1.0, 2.0]" not in results_tail and "1.0-2.0 x" not in results_tail: errors.append("formula for deterministic band missing from Results")
conclusions="\n".join(paras[-70:])
if "4.83 mm" not in conclusions: errors.append("4.83 mm missing from conclusions/discussion tail")
if re.search(r"25\.81 mm[^.\n]{0,100}(principal|primary|calibrated|FEM-anchored)", text, re.I) and "not the principal displacement prediction" not in text:
    errors.append("25.81 mm appears as principal/calibrated prediction")
if "Head displacement | 25.81 mm" in text: errors.append("orphan Head displacement = 25.81 remains")
if "calibrated absolute head displacement" in text or "calibrated absolute displacement prediction" in text: errors.append("calibrated absolute language remains")
if "probabilistic uncertainty band" in text: errors.append("deterministic band described probabilistically")
for token in ["Table 21. Displacement hierarchy", "FEM-anchored preliminary prediction | 4.83 mm", "Prediction band upper bound | 6.439 mm", "Severe-degradation screening envelope | 25.81 mm", "0.860, based on the 25.81 mm stress-test envelope"]:
    if token not in text: errors.append("missing token: "+token)
if not TRACE.exists(): errors.append("trace csv missing")
else:
    d={r["quantity"]:float(r["value"]) for r in csv.DictReader(TRACE.open(encoding="utf-8"))}
    if abs(d.get("preliminary_prediction_mm",0)-4.829124)>1e-9: errors.append("trace preliminary mismatch")
    if abs(d.get("band_upper_mm",0)-6.438832)>1e-9: errors.append("trace band upper mismatch")
if errors:
    print("DISPLACEMENT RECONCILIATION QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("DISPLACEMENT RECONCILIATION QA PASSED")
