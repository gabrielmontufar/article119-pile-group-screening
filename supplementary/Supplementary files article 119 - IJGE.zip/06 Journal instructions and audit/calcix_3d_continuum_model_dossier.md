# CalculiX 3D continuum model dossier

## Identification
- Solver: CalculiX 2.23.0.
- Files: `continuum_static.*` and `continuum_degraded.*`.
- Generator: `calculix_3d_continuum_check.py`.
- Units: kN and m; reported displacements are converted to mm.

## Geometry and Mesh
- Soil block: 7.2 m x 7.2 m in plan and 8.0 m deep.
- Piles: 2x2 concrete inclusions at the selected pile coordinates, D = 0.60 m, L = 8.0 m.
- Cap: not explicitly modelled as a structural cap; load is distributed to top pile nodes.
- Element type: C3D8.
- Mesh: 2601 nodes and 2048 elements; 1920 soil elements and 128 pile-inclusion elements.

## Materials
- Concrete: E = 30,000,000 kN/m2, nu = 0.20.
- Soil: three linear elastic layers. Static case uses static layer moduli; degraded case applies cyclic degradation factors.
- Poisson ratio for soil: 0.35.

## Interface
The continuum model imposes a bonded no-slip/no-gap pile-soil interface and is therefore expected to be stiff relative to models allowing gap, slip or nonlinear p-y degradation.

## Boundary Conditions and Load
- Bottom boundary fixed in translations.
- X side faces restrain Ux; Y side faces restrain Uy.
- Ground surface is free.
- Lateral load = 100 kN distributed over 36 TOPPILE nodes, 2.7778 kN per node.

## Cases and Extraction
- Static layer stiffness: mean/max Ux = 0.286/0.294 mm.
- Degraded layer stiffness: mean/max Ux = 0.403/0.413 mm.
- Source: `.dat` files, set `TOPPILE`.
- Allowed claim: stiff continuum lower-bound stiffness check; not full nonlinear soil-pile validation.
