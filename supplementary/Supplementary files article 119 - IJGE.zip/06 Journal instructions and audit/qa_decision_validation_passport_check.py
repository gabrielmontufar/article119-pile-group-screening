from __future__ import annotations
import csv, sys
from pathlib import Path
from docx import Document

BASE=Path(__file__).resolve().parent
DOCX=BASE.parents[0]/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc=Document(DOCX)
text="\n".join(p.text for p in doc.paragraphs)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
required=[
    "V4-S decision-validation passport",
    "Decision-validation passport and claim ledger",
    "Table 24h. Why the framework is not just another screening article.",
    "Table 24i. Claim-level reproducibility ledger for the V4-S decision-validation passport.",
    "Table 24j. Escalation rules that convert screening output into engineering action.",
    "claim ledger, evidence tier, QA gate, falsifier and escalation rule",
    "prevents benchmark laundering",
    "falsifiable governance template",
]
for token in required:
    if token.lower() not in text.lower():
        errors.append("missing passport token: "+token)
bad=[
    "field-test calibration achieved",
    "validated by ERIES",
    "ERIES calibration",
    "proves absolute accuracy",
    "replacement for site-specific nonlinear",
]
for token in bad:
    if token.lower() in text.lower():
        errors.append("overclaim remains: "+token)
for f in ["decision_validation_passport_disruptive_contribution.csv","claim_level_reproducibility_ledger.csv","screening_to_design_escalation_rules.csv","decision_validation_passport_audit.md"]:
    if not (BASE/f).exists():
        errors.append("missing "+f)
with (BASE/"claim_level_reproducibility_ledger.csv").open(encoding="utf-8", newline="") as f:
    rows=list(csv.DictReader(f))
if len(rows) < 6:
    errors.append("claim ledger too small")
for r in rows:
    for col in ["evidence file","qa gate","maximum interpretation","falsifier"]:
        if not r[col].strip():
            errors.append("blank ledger field in "+r.get("claim id","unknown")+": "+col)
if errors:
    print("DECISION VALIDATION PASSPORT QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("DECISION VALIDATION PASSPORT QA PASSED")
