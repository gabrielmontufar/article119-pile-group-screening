# Figure presentation upgrade

Regenerated the main figure set with larger canvases, wrapped labels, external annotations, clearer legends and non-overlapping text. Updated files: Fig3, Fig4, Fig5, Fig6, Fig7, Fig8, Fig18, Fig19, Fig20 and Fig23.
