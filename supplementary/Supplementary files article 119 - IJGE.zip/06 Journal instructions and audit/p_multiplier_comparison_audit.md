# p-multiplier comparison audit

| Method cited | Manuscript section | Current numerical comparison | Data needed | Data available | Implementation possible | Reason/limit | Action applied | Final status |
|---|---|---|---|---|---|---|---|---|
| Brown et al.; Brown/Reese | cited in literature review and discussion | partial trend only | row p-multipliers | open summarized values leading 0.80/trailing 0.40 | yes | adapted from 3D sand to 2-row 2x2; not calibration | numerical sensitivity row added | corrected |
| Rollins et al. | spacing/group and liquefied p-y sections | yes, but not side-by-side p-multiplier | profile-matched p-y/group data | only non-equivalent Rollins checks in package | limited | not profile-matched | kept as scale/compatibility evidence | bounded |
| API/DNV | practice context | no | public group p-multiplier formula for selected case | not available in package | no | avoid proprietary/non-auditable implementation | not implemented row with reason | corrected |
| Modern cyclic group p-y | 2024-2026 literature | no | full formula and parameters mapped to selected profile | not available in package | no | no benchmark-compatible implementation | compatibility table row added | corrected |
| GEOLAB/ERIES | external evidence | yes but different benchmark | measured compatible force-displacement for selected case | not available | no direct benchmark | domain mismatch | not used as model superiority evidence | bounded |
| CalculiX p-y | solver check | yes | same selected 2x2 benchmark | available | yes | same p-y idealization family | included in side-by-side table | corrected |
