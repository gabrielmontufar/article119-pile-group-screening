from pathlib import Path
import csv, zipfile
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
CAPSULE = ROOT / "04 Supplementary" / "eries_aligned_2x2_screening_capsule"
ZIP_PATH = ROOT / "04 Supplementary" / "Supplementary files article 119 - IJGE.zip"

for name in [
    "v4s_passport_canonical_claims.csv",
    "claim_support_index_csi.csv",
    "claim_governance_novelty_audit.md",
]:
    assert (AUDIT / name).exists(), name

csi = list(csv.DictReader((AUDIT / "claim_support_index_csi.csv").open(encoding="utf-8")))
assert len(csi) >= 6
assert any(r["claim_id"] == "C6" and r["CSI_class"] in ["A", "B"] for r in csi)
assert all(float(r["CSI_score"]) > 0 for r in csi)

for name in ["README.md", "requirements.txt", "run_all.py", "capsule_manifest.csv", "v4s_passport_canonical_claims.csv", "claim_support_index_csi.csv"]:
    assert (CAPSULE / name).exists(), name

doc = Document(DOCX)
text = "\n".join(p.text for p in doc.paragraphs) + "\n" + "\n".join(
    "\n".join(" | ".join(c.text for c in row.cells) for row in table.rows) for table in doc.tables
)
for token in [
    "claim-level validation-governance workflow",
    "Claim Support Index for the V4-S passport",
    "Table 24q. Claim Support Index classes for the V4-S decision-validation passport.",
    "ERIES-aligned 2x2 pile-group screening capsule",
    "not a new empirical p-y law and not a general topology optimizer",
]:
    assert token in text, f"Missing token: {token}"

with zipfile.ZipFile(ZIP_PATH, "r") as z:
    names = set(z.namelist())
    for name in [
        "06 Journal instructions and audit/v4s_passport_canonical_claims.csv",
        "06 Journal instructions and audit/claim_support_index_csi.csv",
        "04 Supplementary/eries_aligned_2x2_screening_capsule/README.md",
        "04 Supplementary/eries_aligned_2x2_screening_capsule/run_all.py",
        "04 Supplementary/eries_aligned_2x2_screening_capsule/capsule_manifest.csv",
    ]:
        assert name in names, f"Missing ZIP entry: {name}"

print("CLAIM GOVERNANCE NOVELTY QA PASSED")
