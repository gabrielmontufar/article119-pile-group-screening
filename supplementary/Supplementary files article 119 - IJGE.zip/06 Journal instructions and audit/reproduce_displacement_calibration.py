from __future__ import annotations
import csv
from pathlib import Path
OUT=Path(__file__).resolve().parent
calcix_py_disp_mm=3.219416
calibration_multiplier=1.5
preliminary_prediction_mm=calibration_multiplier*calcix_py_disp_mm
band_lower_multiplier=1.0
band_upper_multiplier=2.0
band_lower_mm=band_lower_multiplier*calcix_py_disp_mm
band_upper_mm=band_upper_multiplier*calcix_py_disp_mm
screening_stress_test_mm=25.81380308925839
rows=[
("calcix_py_disp_mm",calcix_py_disp_mm),
("calibration_multiplier",calibration_multiplier),
("preliminary_prediction_mm",preliminary_prediction_mm),
("band_lower_multiplier",band_lower_multiplier),
("band_upper_multiplier",band_upper_multiplier),
("band_lower_mm",band_lower_mm),
("band_upper_mm",band_upper_mm),
("screening_stress_test_mm",screening_stress_test_mm),
("ratio_screening_to_prediction",screening_stress_test_mm/preliminary_prediction_mm),
("ratio_screening_to_calcix_py",screening_stress_test_mm/calcix_py_disp_mm),
("ratio_prediction_to_calcix_py",preliminary_prediction_mm/calcix_py_disp_mm),
("utilization_screening",0.8604601029752796),
("utilization_preliminary",preliminary_prediction_mm/30.0),
]
with (OUT/"displacement_calibration_trace.csv").open("w",newline="",encoding="utf-8") as f:
    w=csv.writer(f); w.writerow(["quantity","value","unit_or_note"])
    for k,v in rows: w.writerow([k,f"{v:.12g}","mm or dimensionless"])
checks=[
abs(preliminary_prediction_mm-4.829124)<1e-9,
abs(band_lower_mm-3.219416)<1e-9,
abs(band_upper_mm-6.438832)<1e-9,
abs(screening_stress_test_mm-25.81380308925839)<1e-9,
]
if not all(checks): raise SystemExit("DISPLACEMENT CALIBRATION TRACE FAILED")
for k,v in rows: print(f"{k} = {v:.6g}")
print("DISPLACEMENT CALIBRATION TRACE PASSED")
