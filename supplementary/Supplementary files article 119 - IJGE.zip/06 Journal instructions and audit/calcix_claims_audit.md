# CalculiX claims audit

| Location | Claim | Model | Evidence available | Evidence missing/limit | Value | Source | Action | Status |
|---|---|---|---|---|---|---|---|---|
| Section before Table 18 | CalculiX p-y FEM supports screening | p-y FEM | .inp/.dat/.frd, TOP set displacement | no field calibration or cyclic time history | 3.219 mm | py_fem_model.dat | documented as solver-level p-y traceability | corrected |
| Table 18 | p-y FEM summary | p-y FEM | B31, SPRINGA, mesh, load, extraction | not a 3D continuum model | 64 beams, 64 springs | py_fem_model.inp | replaced with model definition table | corrected |
| Figure 16 | p-y FEM visual check | p-y FEM | CSV trace and regenerated figure | not experimental validation | 3.219 mm | calcix_checks_trace.csv | regenerated from CSV | corrected |
| Section before Table 19 | 3D continuum check | 3D continuum | C3D8 .inp/.dat/.frd, TOPPILE extraction | bonded no-slip/no-gap interface stiffens response | 0.286/0.403 mm | continuum dat files | lower-bound language added | corrected |
| Table 19 | 3D continuum summary | 3D continuum | block, mesh, boundary, interface, load | no contact/gap/slip | 2048 elements | continuum inp files | replaced with model definition table | corrected |
| Table 20 | model hierarchy | all | ratios to 25.81 and 4.83 | no final design validation | 3.219, 0.286, 0.403 mm | trace CSV | replaced with quantitative comparison | corrected |
