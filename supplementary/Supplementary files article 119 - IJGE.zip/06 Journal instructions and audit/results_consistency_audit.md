# Results consistency audit

| Location | Reported issue | Source used | Canonical value | Action taken | Status |
|---|---|---|---|---|---|
| Abstract | 4.83 mm; 3.219-6.439 mm; UQ values | manuscript abstract + canonical_results.json | Already coherent after IJGE adaptation | retained | corrected |
| Table 4 | 25.81 mm used as selected head displacement | canonical_results.json + calibrated predictor CSV | 4.83 mm primary; 25.81 mm stress-test | table rewritten | corrected |
| Table 5 | single 2x2 row but surrounding text implied more topologies | design variables table + best_by_topology.csv | 2x2-only canonical enumeration | text/table aligned | corrected |
| Reserve text | 106.1 to 139.3 and 31.3% premium | robust_reserve_check.csv | 12.1 through 0.90; 12.2 at 0.85 | obsolete values removed | corrected |
| Degradation text/Table 8 | 175 to 174 feasible designs and non-monotonic selected utilization at multiplier 4 | degradation_sensitivity.csv | 175,175,175,175,175,174; final utilization 0.918 due selected spacing change | retained with canonical interpretation | corrected |
| Table 11/Fig. 8 text | five topology optima; Spearman rank correlation = 1.00 | independent_winkler_check.csv | single 2x2 numerical check | rank-correlation claim removed | corrected |
| Rollins benchmark paragraph | selected candidate D = 1.20 m | Table 2/Table 4/canonical_results.json | selected candidate D = 0.60 m | paragraph corrected | corrected |
| Model hierarchy | 25.81 mm could be read as primary prediction | calibrated_absolute_displacement_predictor.csv | 25.81 mm is severe-degradation stress-test envelope only | terminology standardized | corrected |
| Table 7 and Fig. 6 address the concern that a near-limit design may be numerically fragile | text/table inconsistency | DOCX audit | canonical text | Corrected reserve/topology transition text. | corrected |
| The reserve check is economically informative in a narrower, internally consistent sense.  | text/table inconsistency | DOCX audit | canonical text | Removed obsolete reserve-cost values from already corrected paragraph. | corrected |
| The degradation sensitivity in Table 8 and Fig. 7 varies the effective cycle multiplier. T | text/table inconsistency | DOCX audit | canonical text | Corrected obsolete feasible-count claim and explained non-monotonic utilization. | corrected |
| Because the current canonical enumeration is restricted to the ERIES-aligned 2x2 design se | text/table inconsistency | DOCX audit | canonical text | Removed residual Spearman wording from already corrected paragraph. | corrected |
| A further external p-y benchmark was added using the Rollins et al. (2005) liquefied-sand  | text/table inconsistency | DOCX audit | canonical text | Corrected selected-candidate diameter from obsolete D=1.20 m wording. | corrected |
| A second bridge analysis separates the ERIES low-amplitude range from the 100 kN screening | text/table inconsistency | DOCX audit | canonical text | Separated ERIES extrapolation, calibrated prediction and stress-test displacement. | corrected |
| The p-y FEM comparison also triggered an explicit discrepancy-resolution step. The severe- | text/table inconsistency | DOCX audit | canonical text | Separated FEM-calibrated prediction from stress-test wording. | corrected |
| The displacement estimate is made explicit in Table 21 and Fig. 19 instead of being left a | text/table inconsistency | DOCX audit | canonical text | Removed ambiguous primary/stress-test sentence. | corrected |
| The calibrated predictor has a defined domain. The degradation model is a transparent engi | text/table inconsistency | DOCX audit | canonical text | Removed ambiguous wording that could read as stress-test/main-prediction mixing. | corrected |
| The verification checks give the result practical weight within the declared 2x2 domain. T | text/table inconsistency | DOCX audit | canonical text | Separated conclusion values into primary prediction and stress-test. | corrected |
| Table 4 | text/table inconsistency | DOCX audit | canonical text | Separated calibrated prediction from stress-test envelope. | corrected |
| Table 5 | text/table inconsistency | DOCX audit | canonical text | Limited table to verified 2x2 canonical design set. | corrected |
| Table 11 | text/table inconsistency | DOCX audit | canonical text | Removed multi-topology ranks from single-row check. | corrected |
| Table 18 | text/table inconsistency | DOCX audit | canonical text | Renamed screening displacement as stress-test displacement. | corrected |
| Table 23 | text/table inconsistency | DOCX audit | canonical text | Removed Spearman/five-topology claim. | corrected |

Canonical hierarchy: 4.83 mm calibrated preliminary prediction; 3.219-6.439 mm prediction band; 25.81 mm severe-degradation stress-test envelope; 3.22 mm CalculiX nonlinear p-y check; 0.403 mm CalculiX 3D degraded continuum check; 0.286 mm CalculiX 3D static continuum check.