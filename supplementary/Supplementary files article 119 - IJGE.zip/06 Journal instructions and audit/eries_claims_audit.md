# ERIES claims audit

| Location | Original claim type | Evidence available | Evidence missing | Maximum defensible claim | Correction applied | Status |
|---|---|---|---|---|---|---|
| Abstract | support/validation implied | acceleration traces and geometry match | synchronized force-displacement phase and loops | limited small-amplitude dynamic-impedance consistency | rewritten abstract | corrected |
| Section 5.4 title | validation benchmark | selected acceleration traces | measured force/displacement histories | consistency check | retitled section | corrected |
| Table 14 | calibration/validation summary | normalized acceleration response | force/displacement loops | normalized response consistency | relabelled table/cells | corrected |
| Table 15 | impedance check | reconstructed force amplitude and inferred displacement amplitude | force phase and measured force channel | diameter-scaled impedance consistency | limitation retained | corrected |
| Table 16 | experimental anchor/extrapolation | small-amplitude impedance | 100 kN validation | evidence boundary table | replaced table | corrected |
| Figure 13 | hysteresis envelope | amplitude and assumed phase bounds | measured hysteresis loop | phase-bounded envelope only | caption/text corrected | corrected |
| Table 23 | credibility hierarchy | ERIES acceleration traces | cyclic degradation calibration | small-amplitude impedance consistency only | role narrowed | corrected |
