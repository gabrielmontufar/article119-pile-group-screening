from __future__ import annotations
from pathlib import Path
from docx import Document
ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc = Document(DOCX)
text = "\n".join([p.text for p in doc.paragraphs] + [c.text for t in doc.tables for r in t.rows for c in r.cells])
required = [
    "u_pred = gamma_FEM u_CalculiX",
    "gamma_FEM in [1.0, 2.0]",
    "not an experimental calibration constant",
    "Table 21b. FEM anchoring-factor sensitivity",
    "Table 21c. Role separation",
    "Table 21d. Group-efficiency sensitivity",
    "Table 21e. Evidence hierarchy",
    "Table 21f. Operational use rules",
    "Table 21g. Displacement comparison across model classes",
]
for token in required:
    if token.lower() not in text.lower():
        raise SystemExit("SCREENING FACTOR QA FAILED: missing " + token)
bad = ["1.5 multiplier is an engineering screening anchor", "25.81 mm value is the principal"]
for token in bad:
    if token.lower() in text.lower():
        raise SystemExit("SCREENING FACTOR QA FAILED: bad token " + token)
for name in ["screening_simplification_factor15_envelope_audit.md", "gamma_fem_sensitivity.csv", "eta_g_sensitivity.csv", "screening_use_rules.csv"]:
    if not (AUDIT / name).exists():
        raise SystemExit("SCREENING FACTOR QA FAILED: missing file " + name)
print("SCREENING FACTOR ENVELOPE QA PASSED")
