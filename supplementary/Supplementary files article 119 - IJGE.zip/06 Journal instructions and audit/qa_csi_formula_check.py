from pathlib import Path
import csv

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
CSI = ROOT / "06 Journal instructions and audit" / "claim_support_index_csi.csv"
rows = list(csv.DictReader(CSI.open(encoding="utf-8")))
assert rows, "missing CSI rows"
for r in rows:
    assert r.get("CSI_formula") == "CSI = 100*(0.30*E/4 + 0.20*Q + 0.20*R + 0.20*I - 0.10*F)", "missing formula"
    score = 100.0*(0.30*float(r["evidence_level_E"])/4.0 + 0.20*float(r["qa_gate_Q"]) + 0.20*float(r["reproducibility_R"]) + 0.20*float(r["mechanical_independence_I"]) - 0.10*float(r["falsifier_severity_F"]))
    assert abs(score - float(r["CSI_score"])) <= 0.051, (r["claim_id"], score, r["CSI_score"])
    if score >= 82:
        cls = "A"
    elif score >= 68:
        cls = "B"
    elif score >= 52:
        cls = "C"
    else:
        cls = "D"
    assert r["CSI_class"] == cls, (r["claim_id"], cls, r["CSI_class"])
print("CSI FORMULA QA PASSED")
