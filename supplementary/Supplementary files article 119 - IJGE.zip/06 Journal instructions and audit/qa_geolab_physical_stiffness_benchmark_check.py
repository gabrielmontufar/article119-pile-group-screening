from __future__ import annotations
import csv, sys
from pathlib import Path
from docx import Document

BASE=Path(__file__).resolve().parent
DOCX=BASE.parents[0]/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc=Document(DOCX)
text="\n".join(p.text for p in doc.paragraphs)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
for token in [
    "Table 24m. GEOLAB centrifuge-to-prototype stiffness scaling benchmark.",
    "Table 24n. Physical stiffness comparison between GEOLAB and selected-case predictors.",
    "Kp = N Km",
    "not a selected-profile calibration",
    "measured pile-group stiffness scale",
]:
    if token.lower() not in text.lower():
        errors.append("missing token: "+token)
for f in ["geolab_physical_stiffness_scaling.csv","geolab_selected_case_stiffness_comparison.csv","geolab_physical_stiffness_benchmark_audit.md"]:
    if not (BASE/f).exists():
        errors.append("missing "+f)
rows=list(csv.DictReader((BASE/"geolab_selected_case_stiffness_comparison.csv").open(encoding="utf-8")))
if len(rows) < 5:
    errors.append("comparison table too small")
if not any("Proposed FEM-anchored" in r["benchmark"] and float(r["ratio_to_GEOLAB"]) > 0 for r in rows):
    errors.append("missing proposed-to-GEOLAB ratio")
if errors:
    print("GEOLAB PHYSICAL STIFFNESS BENCHMARK QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("GEOLAB PHYSICAL STIFFNESS BENCHMARK QA PASSED")
