# GEOLAB physical stiffness benchmark audit

This adds a physical stiffness-scale comparison using the measured GEOLAB Test 4 force-displacement curve. Centrifuge similitude is applied as Kp = N Km because force scales as N^2 and displacement as N. The benchmark is explicitly not selected-profile calibration because topology, scale and soil profile differ from the ERIES-aligned 2x2 case.
