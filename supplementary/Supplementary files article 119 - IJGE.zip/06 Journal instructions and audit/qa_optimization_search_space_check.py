from __future__ import annotations
import csv
import re
from pathlib import Path
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"

def fail(msg):
    raise SystemExit("OPTIMIZATION SEARCH SPACE QA FAILED: " + msg)

with (AUDIT / "optimization_search_space.csv").open(encoding="utf-8", newline="") as f:
    space = list(csv.DictReader(f))
included = [r for r in space if r["included_in_final_search"] == "yes"]
topos = sorted({r["topology"] for r in included})
if topos != ["2x2"]:
    fail(f"final search topologies are not fixed 2x2: {topos}")
if len(included) != 175:
    fail(f"final candidate count is not 175: {len(included)}")

doc = Document(DOCX)
paras = [p.text for p in doc.paragraphs]
table_text = [cell.text for t in doc.tables for row in t.rows for cell in row.cells]
text = "\n".join(paras + table_text)
lower = text.lower()

if "2x2 only" not in text:
    fail("Table 2 or text does not state 2x2 only")
if "topology is not varied in the final reproduced search" not in lower:
    fail("explicit fixed-topology statement missing")
if "175 alternatives: 1 topology x 5 diameters x 7 lengths x 5 spacing values" not in text:
    fail("candidate-count statement missing or mismatched")

results_zone = "\n".join(paras[30:85]).lower()
for topo in ["3x2", "3x3", "4x3", "4x4"]:
    if topo in results_zone:
        fail(f"non-final topology appears in results zone: {topo}")

if "least-cost feasible screening candidate by topology" in lower:
    fail("Figure 2 still says by topology")
if "best topology-level candidate" in lower:
    fail("Table 5 still says topology-level")
if "spearman rank correlation" in lower:
    fail("Spearman ranking claim remains")
if "five evaluated topology-level optima" in lower:
    fail("five-topology ranking claim remains")
if re.search(r"\bshift(?:s|ed)? to 4x3\b|\bshift(?:s|ed)? to 4x4\b", lower):
    fail("unsupported topology shift claim remains")
if "larger groups reduced utilization" in lower or "smaller groups required" in lower:
    fail("multigroup conclusion remains in fixed-topology article")
if "showing which topologies deserve detailed analysis" in lower:
    fail("discussion still implies topologies were compared in final search")

print("OPTIMIZATION SEARCH SPACE QA PASSED")
