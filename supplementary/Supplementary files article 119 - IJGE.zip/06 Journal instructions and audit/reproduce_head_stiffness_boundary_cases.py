from __future__ import annotations
import csv, math
from pathlib import Path
OUT=Path(__file__).resolve().parent
rows, cols, n = 2, 2, 4
D,L,eta,k_eq,E,H = 0.60,8.0,0.6942574497178212,15648.90035871277,30000000.0,100.0
I=math.pi*D**4/64
T=(E*I/(k_eq*D))**0.25
def case(lambda_t, mode):
    Le=min(L,lambda_t*T); base=E*I/Le**3
    if mode=="cantilever":
        ks=3*base; kg=n*eta*ks; u=H/kg*1000; th=(H/(n*eta))*Le**2/(2*E*I)*1000; bc="cantilever-equivalent"
    elif mode=="guided":
        ks=12*base; kg=n*eta*ks; u=H/kg*1000; th=0; bc="guided-head"
    else:
        kuu=n*eta*12*E*I/Le**3; kut=n*eta*6*E*I/Le**2; ktt=n*eta*4*E*I/Le; kcap=ktt
        kg=kuu-kut**2/(ktt+kcap); u=H/kg*1000; th=-(kut*(u/1000))/(ktt+kcap)*1000; ks=kg/(n*eta); bc="finite-cap"
    return {"boundary_condition":bc,"lambda_T":lambda_t,"T_m":T,"Le_m":Le,"k_single_kN_m":ks,"k_group_kN_m":kg,"displacement_mm":u,"rotation_mrad":th,"utilization":u/30}
rows_out=[case(x,"cantilever") for x in [2.5,3.0,3.5,4.0,5.0]]+[case(3.5,m) for m in ["cantilever","guided","finite"]]
with (OUT/"head_stiffness_boundary_cases.csv").open("w",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f,fieldnames=list(rows_out[0].keys())); w.writeheader(); w.writerows(rows_out)
if abs(rows_out[2]["displacement_mm"]-25.81380308925839)>1e-6 or abs(rows_out[2]["Le_m"]-7.4316169086175945)>1e-6:
    raise SystemExit("HEAD STIFFNESS BOUNDARY QA FAILED")
print("HEAD STIFFNESS BOUNDARY QA PASSED")
