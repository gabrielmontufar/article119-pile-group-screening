# Optimization search-space audit

Editorial decision: Route A. The final reproduced search is intentionally restricted to the ERIES-aligned 2x2 topology. Diameter, length and spacing are optimized; topology is not varied in the final design space.

| Section | Table/Figure/Paragraph | Topology mentioned | Appears in Table 2 | Appears in CSV/script | Appears in results | Contradiction detected | Correction applied | Final status |
|---|---|---|---|---|---|---|---|---|
| Methods | Table 2 | 2x2 | yes | yes | yes | none after correction | Table 2 states 2x2 only and fixed topology | corrected |
| Methods | design vector paragraph | nr,nc/topology-aware | fixed in Table 2 | 2x2 only | 2x2 only | ambiguous before correction | Paragraph now says formulation is topology-aware but final search fixes nr=nc=2 | corrected |
| Results | Figure 2 caption | by topology | not applicable | 2x2 only | 2x2 selected case | by-topology wording with one topology | Caption changed to fixed 2x2 design space | corrected |
| Results | Table 5 title | topology-level candidate | not applicable | 2x2 only | 2x2 selected case | topology-level wording with one topology | Title changed to selected least-cost feasible candidate within fixed 2x2 space | corrected |
| Results/Discussion | general claims | larger/smaller groups/topologies | not in final Table 2 | 2x2 only | 2x2 only | legacy multitopology interpretation | Rewritten as diameter-length-spacing trade-off within fixed topology | corrected |
| External evidence | GEOLAB/Rollins references | external non-2x2 data | not in search | not search candidates | validation context only | could be misread as final search | Text marks these as external evidence, not search topologies | corrected |

The method formulation remains topology-aware, but the application is fixed-topology. A full multitopology extension is treated as future work and would require regenerating the design space, figures and reserve checks.