# International Journal of Geotechnical Engineering adaptation

Target journal: International Journal of Geotechnical Engineering (Taylor & Francis).

Why selected:
- More traditional geotechnical venue than Marine Geotechnics.
- Hybrid/Open Select: open access is optional, not mandatory; this avoids obligatory APC if the standard route is chosen.
- No evidence of prior exact target/submission to this journal was found in `articulos up`; only recommendation mentions.

Official sources:
- Journal page: https://www.tandfonline.com/journals/yjge20
- About this journal: https://www.tandfonline.com/journals/yjge20/about-this-journal

Format applied:
- Research Article.
- Word `.docx` manuscript.
- Traditional geotechnical title and abstract.
- Author metadata retained in the main manuscript unless the portal requests anonymization.
- Separate figures, tables ZIP and supplementary ZIP retained.
- Taylor & Francis-style disclosure, funding, data availability and AI statements prepared.

Local audit:
{
  "title_present": true,
  "traditional_terms_present": true,
  "marine_geotechnics_string_present": false,
  "online_resource_present": false,
  "abstract_word_count": 185,
  "keywords_count": 6,
  "tables_count": 24,
  "figures_copied": 20,
  "uq_present": true
}
