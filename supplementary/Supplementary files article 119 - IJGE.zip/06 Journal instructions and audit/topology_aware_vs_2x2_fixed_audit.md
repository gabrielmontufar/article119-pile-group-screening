﻿# Topology-aware vs fixed 2x2 correction audit

Route B was selected because the validation, ERIES alignment, reserve checks and commercial benchmark currently support a fixed ERIES-aligned 2x2 search rather than a regenerated broader-layout design space.

| Element | Current problem | Action | Corrected framing |
|---|---|---|---|
| Title | could imply broad mixed topology optimization | Route B selected; title narrowed to ERIES-aligned 2x2 diameter-length-spacing screening | Degradation-Aware Diameter-Length-Spacing Screening for an ERIES-Aligned 2x2 Laterally Loaded Pile Group |
| Abstract | mixed discrete-continuous wording could be read as topology-varying search | explicit fixed 2x2 and no general topology optimization claim | fixed-topology pre-design screening workflow |
| Introduction | gap statement said topology is not treated as a design variable | reframed gap around auditable fixed-layout diameter-length-spacing search | declared 2x2 layout, not topology selection |
| Contribution | topology-aware contribution overstated the demonstrated search | rewritten as fixed-topology 2x2 contribution | 175 ERIES-aligned 2x2 candidates |
| Results | selected topology language was redundant and potentially misleading | changed to fixed layout/candidate language | lowest-cost feasible 2x2 diameter-length-spacing candidate |
| Conclusions | topology-aware formulation remained in first conclusion | rewritten as fixed-topology 2x2 screening workflow with broader-layout future work | no general topology optimization claim |

## Route comparison

| Route | Novelty result | Editorial risk | Acceptance effect |
|---|---|---|---|
| A: broader-layout real search | Higher, but would require regenerated figures, reserve checks and validation hierarchy | High if added without full regeneration | Potentially stronger later, not safest now |
| B: fixed-topology honest 2x2 | Moderate but defensible | Lower; removes overclaim | Safest for current package |

## Final contribution statement

The contribution is a reproducible fixed-topology pre-design screening workflow for an ERIES-aligned 2x2 pile group that combines cyclic-degradation assumptions, lateral serviceability, soil-reaction checks, fatigue screening, cost normalization, FEM anchoring and independent numerical/external consistency checks.

