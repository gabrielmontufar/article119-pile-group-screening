from __future__ import annotations
import csv
from pathlib import Path
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
CSV = AUDIT / "group_demo_commercial_comparison.csv"
if not CSV.exists():
    raise SystemExit("GROUP DEMO COMMERCIAL QA FAILED: CSV missing")
row = next(csv.DictReader(CSV.open(encoding="utf-8")))
if "non-equivalent" not in row["allowed_claim"] or "not validation" not in row["allowed_claim"]:
    raise SystemExit("GROUP DEMO COMMERCIAL QA FAILED: claim boundary missing")
doc = Document(DOCX)
text = "\n".join([p.text for p in doc.paragraphs] + [c.text for t in doc.tables for r in t.rows for c in r.cells])
for token in ["Table 11g. Direct GROUP demo-mode commercial-tool output", "not used as selected-case validation", "real GROUP demo-mode pile-group result"]:
    if token not in text:
        raise SystemExit("GROUP DEMO COMMERCIAL QA FAILED: missing " + token)
print("GROUP DEMO COMMERCIAL QA PASSED")
