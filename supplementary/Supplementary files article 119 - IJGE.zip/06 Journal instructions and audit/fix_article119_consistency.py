from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path

from docx import Document
from docx.shared import Pt


ARTICLE = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art")
PACKAGE = ARTICLE / "Entrega International Journal of Geotechnical Engineering 20260515"
MANUSCRIPT = PACKAGE / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
FIGURES = PACKAGE / "02 Figures"
QA_DIR = PACKAGE / "06 Journal instructions and audit"
SUPPLEMENT = ARTICLE / "supplementary_pile_group_optimization"
DATA = SUPPLEMENT / "data"
ERIES = SUPPLEMENT / "validation_eries_respond"


CANONICAL = {
    "geometry": "ERIES-aligned 2x2 pile group",
    "topology": "2x2",
    "rows": 2,
    "columns": 2,
    "number_of_piles": 4,
    "D_m": 0.60,
    "L_m": 8.0,
    "spacing_D": 2.5,
    "spacing_m": 1.50,
    "load_case": "H = 100 kN; M = 0 kN m; N = 100000 cycles",
    "calibrated_preliminary_prediction_mm": 4.83,
    "prediction_band_mm": [3.219, 6.439],
    "severe_degradation_stress_test_envelope_mm": 25.81,
    "calculix_nonlinear_py_fem_check_mm": 3.22,
    "calculix_3d_static_continuum_check_mm": 0.286,
    "calculix_3d_degraded_continuum_check_mm": 0.403,
    "utilization_calibrated": 0.860,
    "utilization_stress_test": 0.860,
    "cost_index": 12.1,
    "feasible_design_count_baseline": 175,
    "feasible_design_count_severe_multiplier_4": 174,
    "selected_topology_under_reserve": {
        "utilization_limit_1.00": "2x2, D=0.60 m, L=8 m, s=2.5D, cost=12.1",
        "utilization_limit_0.95": "2x2, D=0.60 m, L=8 m, s=2.5D, cost=12.1",
        "utilization_limit_0.90": "2x2, D=0.60 m, L=8 m, s=2.5D, cost=12.1",
        "utilization_limit_0.85": "2x2, D=0.60 m, L=8 m, s=3.0D, cost=12.2",
    },
}


def style_para(paragraph, size: float = 11.0) -> None:
    for run in paragraph.runs:
        run.font.name = "Times New Roman"
        run.font.size = Pt(size)


def set_para(paragraph, text: str) -> None:
    paragraph.text = text
    style_para(paragraph)


def set_cell(cell, text: str) -> None:
    cell.text = str(text)
    for para in cell.paragraphs:
        style_para(para, 8.5)


def table_to_text(table) -> str:
    return "\n".join(" | ".join(c.text.strip() for c in r.cells) for r in table.rows)


def rewrite_table(doc: Document, table_index_1_based: int, headers: list[str], rows: list[list[str]]) -> None:
    table = doc.tables[table_index_1_based - 1]
    while len(table.rows) > 1:
        table._tbl.remove(table.rows[-1]._tr)
    while len(table.rows[0].cells) < len(headers):
        table.add_column(Pt(72))
    for idx, header in enumerate(headers):
        set_cell(table.rows[0].cells[idx], header)
    for row_values in rows:
        cells = table.add_row().cells
        for idx, value in enumerate(row_values):
            set_cell(cells[idx], value)


def replace_paragraphs(doc: Document) -> list[dict[str, str]]:
    changes: list[dict[str, str]] = []
    replacements = [
        (
            "The results show that the preferred screening candidate is not the largest group.",
            "The results show that the preferred ERIES-aligned screening candidate is the lowest-cost 2x2 design in the declared enumeration. Table 5 is intentionally limited to the final 2x2 design space; earlier multi-topology exploratory language has been removed so that the table, figures and text describe the same canonical design set.",
            "Removed unsupported multi-topology interpretation near Table 5.",
        ),
        (
            "Table 7 and Fig. 6 address the concern",
            "Table 7 and Fig. 6 address the concern that a near-limit design may be numerically fragile. For utilization limits of 1.00, 0.95 and 0.90, the selected ERIES-aligned 2x2 candidate remains unchanged with cost index 12.1 and utilization 0.860. Only when the reserve limit is tightened to 0.85 does the selected spacing change from 2.5D to 3.0D, increasing the cost index slightly to 12.2.",
            "Corrected reserve/topology transition text.",
        ),
        (
            "The reserve check is also economically informative.",
            "The reserve check is economically informative in a narrower, internally consistent sense. Tightening the utilization limit from 1.00 to 0.90 does not increase the cost because the same 2x2 candidate remains feasible. The first change in the selected candidate occurs at the 0.85 reserve limit, where spacing increases to 3.0D and the cost index rises from 12.1 to 12.2. No larger reserve-cost premium is claimed for the current canonical design set.",
            "Removed obsolete 106.1/139.3 reserve-cost claim.",
        ),
        (
            "The reserve check is economically informative in a narrower, internally consistent sense.",
            "The reserve check is economically informative in a narrower, internally consistent sense. Tightening the utilization limit from 1.00 to 0.90 does not increase the cost because the same 2x2 candidate remains feasible. The first change in the selected candidate occurs at the 0.85 reserve limit, where spacing increases to 3.0D and the cost index rises from 12.1 to 12.2. No larger reserve-cost premium is claimed for the current canonical design set.",
            "Removed obsolete reserve-cost values from already corrected paragraph.",
        ),
        (
            "Because the rank sequence is identical for the five evaluated topology-level optima",
            "Because the current canonical enumeration is restricted to the ERIES-aligned 2x2 design set, the independent Winkler calculation is used as a magnitude and stiffness cross-check for the selected candidate rather than as a multi-topology Spearman ranking test. The single-row comparison in Table 11 therefore supports numerical consistency for the final 2x2 case, not a five-topology rank-correlation claim.",
            "Removed unsupported five-topology Spearman claim.",
        ),
        (
            "Because the current canonical enumeration is restricted to the ERIES-aligned 2x2 design set",
            "Because the current canonical enumeration is restricted to the ERIES-aligned 2x2 design set, the independent Winkler calculation is used as a magnitude and stiffness cross-check for the selected candidate rather than as a multi-topology rank test. The single-row comparison in Table 11 therefore supports numerical consistency for the final 2x2 case, not a multi-topology rank-correlation claim.",
            "Removed residual Spearman wording from already corrected paragraph.",
        ),
        (
            "A further external p-y benchmark was added",
            "A further external p-y benchmark was added using the Rollins et al. (2005) liquefied-sand backbone as documented in OpenSeesPy and OpenBrIM. This check is deliberately conservative: it uses an external 1.0 m benchmark diameter for the published p-y backbone while the selected ERIES-aligned screening candidate uses D = 0.60 m. It compares the selected candidate's average lateral demand per pile and per unit embedded length with the mobilized p-y resistance at the stated displacement levels. The test does not replace nonlinear site-specific calibration, but it prevents the screening demand from being interpreted without an external resistance scale.",
            "Corrected selected-candidate diameter from obsolete D=1.20 m wording.",
        ),
        (
            "A second bridge analysis separates the ERIES low-amplitude range",
            "A second bridge analysis separates the ERIES low-amplitude range from the 100 kN screening scenario. The robust ERIES inlier median dynamic stiffness is 1470577 kN/m. A linear extrapolation of that small-amplitude stiffness to 100 kN gives 0.068 mm. For the selected 2x2 case, the calibrated preliminary prediction is 4.83 mm. The severe-degradation stress-test envelope is 25.81 mm and is retained only as an upper conservative scenario for ranking and sensitivity.",
            "Separated ERIES extrapolation, calibrated prediction and stress-test displacement.",
        ),
        (
            "The p-y FEM comparison also triggered an explicit discrepancy-resolution step.",
            "The p-y FEM comparison also triggered an explicit discrepancy-resolution step. The severe-degradation screening displacement is 25.81 mm, which is 8.02 times the CalculiX p-y result, so that value is retained only as a stress-test envelope. The calibrated preliminary screening case is 4.83 mm, defined as 1.5 times the independent CalculiX p-y displacement.",
            "Separated FEM-calibrated prediction from stress-test wording.",
        ),
        (
            "The degradation sensitivity in Table 8 and Fig. 7 varies the effective cycle multiplier.",
            "The degradation sensitivity in Table 8 and Fig. 7 varies the effective cycle multiplier. The selected topology remains 2x2 throughout the evaluated range, but the number of feasible designs decreases from 175 to 174 at four times the design-cycle multiplier. The final utilization decreases from 0.932 to 0.918 because the selected feasible candidate changes to a slightly larger spacing/cost combination; this is a discrete-design transition, not a physical stiffness recovery.",
            "Corrected obsolete feasible-count claim and explained non-monotonic utilization.",
        ),
        (
            "The displacement estimate is made explicit in Table 21 and Fig. 19",
            "The displacement estimate is made explicit in Table 21 and Fig. 19 instead of being left as a qualitative screening outcome. The primary predictor is the calibrated absolute head displacement for the stated 2x2 case. That predictor is anchored to the independent CalculiX nonlinear p-y reference, bounded by a two-times p-y prediction band, checked against the ERIES initial dynamic stiffness lower-bound and reported separately from the 25.81 mm stress-test envelope.",
            "Removed ambiguous primary/stress-test sentence.",
        ),
        (
            "The calibrated predictor has a defined domain.",
            "The calibrated predictor has a defined domain. The degradation model is a transparent engineering relation rather than a site-specific cyclic laboratory fit, and the group-efficiency function is deliberately simple and should be replaced by project-specific p-multipliers, nonlinear p-y analyses or three-dimensional numerical modelling when design consequences are high. The cost function is an index rather than a contractor estimate, but it is decomposed into concrete volume, installed pile length and cap footprint so that readers can replace the normalized weights with local project costs. Tables 12 to 22 make the validation boundary explicit: the paper supports a calibrated displacement-prediction claim for the stated 2x2 modelling domain through reproducibility, an independent Winkler check, external trend consistency, a published p-y backbone benchmark, a bounded nonlinear p-y calibration capsule with holdout validation, a measured GEOLAB group-response check, a CalculiX nonlinear beam-spring FEM capsule and a CalculiX 3D continuum check without p-y springs or group-efficiency factors. Direct cyclic group-test calibration remains project-specific future work. The stress-test envelope is retained as a conservative upper scenario, while the calibrated preliminary predictor is the 4.83 mm estimate based on 1.5 times the independent CalculiX p-y result.",
            "Removed ambiguous wording that could read as stress-test/main-prediction mixing.",
        ),
        (
            "The verification checks give the result practical weight.",
            "The verification checks give the result practical weight within the declared 2x2 domain. The reserve analysis shows no cost change from utilization limits of 1.00 to 0.90 and only a small cost-index increase from 12.1 to 12.2 at the 0.85 limit. The independent Winkler calculation, external spacing trend, Rollins p-y benchmark, GEOLAB measured-response check, CalculiX nonlinear p-y FEM and CalculiX 3D continuum checks support the reported calibrated preliminary prediction of 4.83 mm and the 3.219-6.439 mm prediction band. The severe-degradation stress-test envelope is reported separately as 25.81 mm.",
            "Corrected conclusions to match canonical reserve and validation claims.",
        ),
        (
            "The verification checks give the result practical weight within the declared 2x2 domain.",
            "The verification checks give the result practical weight within the declared 2x2 domain. The reserve analysis shows no cost change from utilization limits of 1.00 to 0.90 and only a small cost-index increase from 12.1 to 12.2 at the 0.85 limit. The independent Winkler calculation, external spacing trend, Rollins p-y benchmark, GEOLAB measured-response check, CalculiX nonlinear p-y FEM and CalculiX 3D continuum checks support the reported calibrated preliminary prediction of 4.83 mm and the 3.219-6.439 mm prediction band. The severe-degradation stress-test envelope is reported separately as 25.81 mm.",
            "Separated conclusion values into primary prediction and stress-test.",
        ),
    ]
    for para in doc.paragraphs:
        text = para.text.strip()
        for prefix, replacement, action in replacements:
            if text.startswith(prefix):
                changes.append({"location": text[:90], "action": action})
                set_para(para, replacement)
                break
    return changes


def rewrite_tables(doc: Document) -> list[dict[str, str]]:
    changes: list[dict[str, str]] = []
    rewrite_table(
        doc,
        4,
        ["Metric", "Value"],
        [
            ["Topology", "2x2"],
            ["Number of piles", "4"],
            ["Diameter", "0.60 m"],
            ["Length", "8.0 m"],
            ["Spacing", "2.5D (1.50 m)"],
            ["Group efficiency", "0.694"],
            ["Calibrated preliminary head displacement", "4.83 mm"],
            ["Prediction band", "3.219-6.439 mm"],
            ["Severe-degradation stress-test envelope", "25.81 mm"],
            ["Governing utilization", "0.860"],
            ["Cost index", "12.1"],
        ],
    )
    changes.append({"location": "Table 4", "action": "Separated calibrated prediction from stress-test envelope."})

    rewrite_table(
        doc,
        5,
        ["Topology", "Status", "D (m)", "L (m)", "Spacing", "Primary disp. (mm)", "Stress-test disp. (mm)", "Utilization", "Cost index"],
        [["2x2", "Feasible", "0.60", "8", "2.5D", "4.83", "25.81", "0.860", "12.1"]],
    )
    changes.append({"location": "Table 5", "action": "Limited table to verified 2x2 canonical design set."})

    rewrite_table(
        doc,
        11,
        ["Topology", "Stress-test disp. (mm)", "Independent Winkler disp. (mm)", "Winkler/stress-test ratio", "Role"],
        [["2x2", "25.81", "2.55", "0.10", "single-case numerical cross-check"]],
    )
    changes.append({"location": "Table 11", "action": "Removed multi-topology ranks from single-row check."})

    rewrite_table(
        doc,
        18,
        ["Solver/model", "Topology", "Beam elements", "p-y springs", "Stress-test disp.", "Winkler disp.", "CalculiX disp.", "Calc./stress-test"],
        [[
            "CalculiX 2.23.0; B31 beam piles with nonlinear SPRINGA p-y soil springs",
            "2x2", "64", "64", "25.81 mm", "2.55 mm", "3.22 mm", "0.12",
        ]],
    )
    changes.append({"location": "Table 18", "action": "Renamed screening displacement as stress-test displacement."})

    table23 = doc.tables[22]
    for row in table23.rows:
        if row.cells[0].text.strip().startswith("Independent Winkler check"):
            set_cell(row.cells[2], "Single-case stiffness and displacement comparison for the final 2x2 candidate.")
            set_cell(row.cells[3], "Checks numerical consistency for the selected case, not multi-topology rank stability.")
            changes.append({"location": "Table 23", "action": "Removed Spearman/five-topology claim."})
    return changes


def write_canonical_files() -> None:
    QA_DIR.mkdir(parents=True, exist_ok=True)
    (QA_DIR / "canonical_results.json").write_text(json.dumps(CANONICAL, indent=2), encoding="utf-8")
    with (QA_DIR / "canonical_results.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["field", "value"])
        for key, value in CANONICAL.items():
            writer.writerow([key, json.dumps(value) if isinstance(value, (dict, list)) else value])


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_figure_manifest() -> None:
    rows = []
    source_map = {
        "Fig3": "data/screening_2x2_design_space.csv",
        "Fig6": "data/robust_reserve_check.csv",
        "Fig7": "data/degradation_sensitivity.csv",
        "Fig8": "data/independent_winkler_check.csv",
        "Fig19": "validation_eries_respond/outputs/calibrated_absolute_displacement_predictor.csv",
        "Fig20": "validation_eries_respond/outputs/calibrated_prediction_uncertainty_summary.csv",
    }
    for fig in sorted(FIGURES.glob("*.png")):
        key = fig.stem.split("_")[0]
        rows.append({
            "figure": fig.name,
            "sha256": file_hash(fig),
            "source_data": source_map.get(key, "supplementary reproducibility script/data package"),
        })
    with (QA_DIR / "figure_generation_manifest.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=["figure", "sha256", "source_data"])
        writer.writeheader()
        writer.writerows(rows)


def write_audit(changes: list[dict[str, str]]) -> None:
    rows = [
        ["Abstract", "4.83 mm; 3.219-6.439 mm; UQ values", "manuscript abstract + canonical_results.json", "Already coherent after IJGE adaptation", "retained", "corrected"],
        ["Table 4", "25.81 mm used as selected head displacement", "canonical_results.json + calibrated predictor CSV", "4.83 mm primary; 25.81 mm stress-test", "table rewritten", "corrected"],
        ["Table 5", "single 2x2 row but surrounding text implied more topologies", "design variables table + best_by_topology.csv", "2x2-only canonical enumeration", "text/table aligned", "corrected"],
        ["Reserve text", "106.1 to 139.3 and 31.3% premium", "robust_reserve_check.csv", "12.1 through 0.90; 12.2 at 0.85", "obsolete values removed", "corrected"],
        ["Degradation text/Table 8", "175 to 174 feasible designs and non-monotonic selected utilization at multiplier 4", "degradation_sensitivity.csv", "175,175,175,175,175,174; final utilization 0.918 due selected spacing change", "retained with canonical interpretation", "corrected"],
        ["Table 11/Fig. 8 text", "five topology optima; Spearman rank correlation = 1.00", "independent_winkler_check.csv", "single 2x2 numerical check", "rank-correlation claim removed", "corrected"],
        ["Rollins benchmark paragraph", "selected candidate D = 1.20 m", "Table 2/Table 4/canonical_results.json", "selected candidate D = 0.60 m", "paragraph corrected", "corrected"],
        ["Model hierarchy", "25.81 mm could be read as primary prediction", "calibrated_absolute_displacement_predictor.csv", "25.81 mm is severe-degradation stress-test envelope only", "terminology standardized", "corrected"],
    ]
    for change in changes:
        rows.append([change["location"], "text/table inconsistency", "DOCX audit", "canonical text", change["action"], "corrected"])
    md = ["# Results consistency audit", "", "| Location | Reported issue | Source used | Canonical value | Action taken | Status |", "|---|---|---|---|---|---|"]
    md.extend("| " + " | ".join(str(cell).replace("|", "/") for cell in row) + " |" for row in rows)
    md.append("")
    md.append("Canonical hierarchy: 4.83 mm calibrated preliminary prediction; 3.219-6.439 mm prediction band; 25.81 mm severe-degradation stress-test envelope; 3.22 mm CalculiX nonlinear p-y check; 0.403 mm CalculiX 3D degraded continuum check; 0.286 mm CalculiX 3D static continuum check.")
    (QA_DIR / "results_consistency_audit.md").write_text("\n".join(md), encoding="utf-8")


def write_qa_script() -> None:
    script = r'''from __future__ import annotations

import re
import sys
from pathlib import Path
from docx import Document

DOCX = Path(__file__).resolve().parents[1] / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"

doc = Document(DOCX)
text = "\n".join(p.text for p in doc.paragraphs)
table_text = "\n".join(
    "\n".join(" | ".join(c.text for c in r.cells) for r in t.rows)
    for t in doc.tables
)
all_text = text + "\n" + table_text
errors = []

abstract = ""
for i, p in enumerate(doc.paragraphs):
    if p.text.strip().lower() == "abstract" and i + 1 < len(doc.paragraphs):
        abstract = doc.paragraphs[i + 1].text
        break

if "4.83 mm" not in abstract or "3.219-6.439 mm" not in abstract:
    errors.append("Abstract does not contain canonical 4.83 mm and 3.219-6.439 mm values.")
if "4.83 mm" not in all_text:
    errors.append("4.83 mm is absent from manuscript.")
if re.search(r"106\.1|139\.3", all_text):
    errors.append("Obsolete reserve-cost values 106.1/139.3 remain.")
if re.search(r"45\s+to\s+10|45-10|45[^.\n]{0,80}\b10\b", all_text, re.I):
    errors.append("Obsolete feasible-count claim 45 to 10 remains.")
if re.search(r"five evaluated topology-level optima|five topology|Spearman rank correlation\s*=\s*1\.00", all_text, re.I):
    errors.append("Unsupported five-topology/Spearman claim remains.")
if re.search(r"selected (?:screening )?candidate uses 1\.20 m|uses 1\.20 m piles", all_text, re.I):
    errors.append("Obsolete selected-candidate D=1.20 m wording remains.")
if re.search(r"25\.81 mm[^.\n]{0,80}(primary|calibrated preliminary|main prediction|principal calibrated)", all_text, re.I):
    errors.append("25.81 mm appears to be used as a primary calibrated prediction.")
if "Severe-degradation stress-test envelope | 25.81 mm" not in table_text:
    errors.append("Table 4 does not explicitly label 25.81 mm as stress-test envelope.")
if "Calibrated preliminary head displacement | 4.83 mm" not in table_text:
    errors.append("Table 4 does not explicitly label 4.83 mm as calibrated preliminary displacement.")
if "2x2 | Feasible | 0.60 | 8 | 2.5D | 4.83 | 25.81 | 0.860 | 12.1" not in table_text:
    errors.append("Table 5 does not match canonical 2x2 row.")

captions = [p.text.strip() for p in doc.paragraphs if re.match(r"^(Table|Figure)\s+\d+\.", p.text.strip())]
seen = set()
dupes = []
for cap in captions:
    key = re.match(r"^(Table|Figure)\s+\d+\.", cap).group(0)
    if key in seen:
        dupes.append(key)
    seen.add(key)
if dupes:
    errors.append("Duplicate captions: " + ", ".join(sorted(set(dupes))))

if errors:
    print("CONSISTENCY QA FAILED")
    for err in errors:
        print("- " + err)
    sys.exit(1)
print("CONSISTENCY QA PASSED")
'''
    (QA_DIR / "qa_consistency_check.py").write_text(script, encoding="utf-8")


def main() -> None:
    doc = Document(MANUSCRIPT)
    changes = []
    changes.extend(replace_paragraphs(doc))
    changes.extend(rewrite_tables(doc))
    doc.save(MANUSCRIPT)
    write_canonical_files()
    write_figure_manifest()
    write_audit(changes)
    write_qa_script()
    print(f"Corrected manuscript: {MANUSCRIPT}")
    print(f"Audit: {QA_DIR / 'results_consistency_audit.md'}")
    print(f"Canonical: {QA_DIR / 'canonical_results.json'}")
    print(f"QA: {QA_DIR / 'qa_consistency_check.py'}")


if __name__ == "__main__":
    main()
