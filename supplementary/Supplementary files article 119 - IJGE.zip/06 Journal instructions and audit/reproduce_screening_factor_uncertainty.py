from __future__ import annotations
import csv
from pathlib import Path
BASE = Path(__file__).resolve().parent
gamma = list(csv.DictReader((BASE / "gamma_fem_sensitivity.csv").open(encoding="utf-8")))
if [r["gamma_FEM"] for r in gamma] != ["1.0", "1.5", "2.0"]:
    raise SystemExit("gamma_FEM rows missing")
if abs(float(gamma[1]["u_pred_mm"]) - 4.829) > 0.01:
    raise SystemExit("central gamma displacement mismatch")
eta = list(csv.DictReader((BASE / "eta_g_sensitivity.csv").open(encoding="utf-8")))
if not all(r["candidate_changes"].startswith("no") for r in eta):
    raise SystemExit("eta sensitivity candidate-change flag mismatch")
print("SCREENING FACTOR UNCERTAINTY TRACE PASSED")
