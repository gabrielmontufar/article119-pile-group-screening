from __future__ import annotations

import csv
import re
from pathlib import Path

from docx import Document


ROOT = Path(
    r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art"
    r"\Entrega International Journal of Geotechnical Engineering 20260515"
)
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
FIGS = ROOT / "02 Figures"


def rows(name: str) -> list[dict[str, str]]:
    with (AUDIT / name).open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def fail(msg: str):
    raise SystemExit("TEXT TABLE FIGURE CONSISTENCY QA FAILED: " + msg)


doc = Document(DOCX)
text = "\n".join(
    [p.text for p in doc.paragraphs]
    + [cell.text for table in doc.tables for row in table.rows for cell in row.cells]
)
lower = text.lower()

required = [
    "canonical_sensitivity_reserve_results.csv",
    "table_06_baseline.csv",
    "table_07_reserve.csv",
    "table_08_degradation.csv",
    "figure_04_sensitivity_source.csv",
    "figure_06_reserve_check_source.csv",
    "figure_07_degradation_sensitivity_source.csv",
    "figure_08_winkler_ranking_source.csv",
    "text_table_figure_consistency_audit.md",
]
for name in required:
    if not (AUDIT / name).exists():
        fail(f"missing {name}")

for fig in [
    "Fig4_selected_design_sensitivity.png",
    "Fig6_robust_reserve_check.png",
    "Fig7_degradation_sensitivity.png",
    "Fig8_independent_winkler_check.png",
]:
    if not (FIGS / fig).exists():
        fail(f"missing figure {fig}")

table6 = rows("table_06_baseline.csv")
u6 = [float(r["Utilization"]) for r in table6]
if len(set(u6)) > 1 and "identical utilization" in lower:
    fail("identical utilization remains although Table 6 values differ")
if "increases from 0.640 to 0.860" not in text:
    fail("Table 6 utilization increase text missing")

table7 = rows("table_07_reserve.csv")
reserve_topos = {r["Topology"] for r in table7}
reserve_text_window = "\n".join(
    p.text for p in doc.paragraphs
    if "reserve" in p.text.lower() or "Figure 6" in p.text or "Table 7" in p.text
).lower()
if reserve_topos == {"2x2"} and re.search(r"\b4x3\b|\b4x4\b|31\.3%|106\.1|139\.3", reserve_text_window):
    fail("legacy multtopology reserve/cost claim remains")
if "cost index rises from 12.1 to 12.2" not in text and "C_norm rises from 12.1 to 12.2" not in text:
    fail("reserve cost change text missing")

sens = rows("figure_04_sensitivity_source.csv")
lat = [r for r in sens if r["case_id"] == "lateral_load"]
if len(lat) < 3:
    fail("Figure 4 source lacks lateral-load points")
u_by_f = {float(r["perturbation_factor"]): float(r["utilization"]) for r in lat}
if not all(f in u_by_f for f in [0.8, 1.0, 1.2]):
    fail("Figure 4 source lacks 0.8/1.0/1.2 lateral-load factors")
norm_sens = ((u_by_f[1.2] - u_by_f[0.8]) / u_by_f[0.8]) / ((1.2 - 0.8) / 0.8)
if "near-proportional" in lower and abs(norm_sens - 1.0) > 0.08:
    fail("near-proportional claim not supported by Figure 4 source")
if "normalized sensitivity of 1.00" not in text:
    fail("Figure 4 sensitivity text lacks numeric support")

table8 = rows("table_08_degradation.csv")
if not {"D (m)", "L (m)", "Spacing", "Stress-test disp. (mm)"}.issubset(table8[0].keys()):
    fail("Table 8 lacks required design-change detail")
feasible_counts = [r["Feasible designs"] for r in table8]
if "175" in "".join(feasible_counts) and "174" in "".join(feasible_counts) and "175 to 174" not in text:
    fail("Table 8 feasible-count trend is not described")
spacings = {r["Spacing"] for r in table8}
if "3.0D" in spacings and "spacing change from 2.5D to 3.0D" not in text:
    fail("Table 8 discrete spacing transition is not described")

table11 = rows("table_11_winkler.csv")
if len(table11) < 3 and "spearman rank correlation" in lower:
    fail("Spearman claim remains with fewer than three alternatives")
if "Independent rank" in text:
    fail("Table 11 still contains rank column")
if "single-case magnitude and stiffness cross-check" not in text:
    fail("Winkler single-case role missing")

for bad in ["45 to 10", "31.3% premium", "five evaluated topology-level optima"]:
    if bad.lower() in lower:
        fail(f"legacy unsupported phrase remains: {bad}")

print("TEXT TABLE FIGURE CONSISTENCY QA PASSED")
