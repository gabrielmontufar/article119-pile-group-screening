from __future__ import annotations
import csv
from pathlib import Path

BASE = Path(__file__).resolve().parent
COST = BASE / "canonical_cost_results.csv"
DOCX = BASE.parent / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"

with COST.open(encoding="utf-8", newline="") as f:
    rows = list(csv.DictReader(f))
if len(rows) != 175:
    raise SystemExit(f"unexpected cost row count: {len(rows)}")
selected = [r for r in rows if r["selected_candidate"] == "yes"]
if len(selected) != 1:
    raise SystemExit("expected one selected candidate")
s = selected[0]
vc = float(s["concrete_volume_m3"])
lt = float(s["total_pile_length_m"])
ac = float(s["cap_footprint_m2"])
c_raw = 780.0 * vc + 145.0 * lt + 95.0 * ac
c_norm = c_raw / float(s["C_ref"])
if abs(c_raw - float(s["C_raw"])) > 0.02:
    raise SystemExit("C_raw mismatch")
if abs(c_norm - float(s["C_norm"])) > 0.002:
    raise SystemExit("C_norm mismatch")
if round(c_norm, 1) != 12.1:
    raise SystemExit("selected normalized cost is not 12.1")
try:
    from docx import Document
    doc = Document(DOCX)
    text = "\n".join([p.text for p in doc.paragraphs] + [cell.text for t in doc.tables for row in t.rows for cell in row.cells])
    for required in ["C_norm = C_raw / C_ref", "C_ref = 1000", "C_norm = 12.1", "Normalized cost index C_norm"]:
        if required not in text:
            raise SystemExit(f"missing DOCX cost convention: {required}")
except ImportError:
    pass
print("COST INDEX AND AXIS QA PASSED")
