from __future__ import annotations
import csv
from pathlib import Path

BASE = Path(__file__).resolve().parent
rows = list(csv.DictReader((BASE / "group_matched_commercial_benchmark.csv").open(encoding="utf-8")))
lookup = {r["method"]: r for r in rows}
if abs(float(lookup["Commercial GROUP demo output"]["head_displacement_mm"]) - 0.805) > 0.01:
    raise SystemExit("GROUP displacement mismatch")
if float(lookup["Unanchored screening transfer to GROUP geometry"]["ratio_to_GROUP"]) < 100:
    raise SystemExit("unanchored transfer should expose major mismatch")
if lookup["GROUP-anchored screening stiffness capsule"]["ratio_to_GROUP"] != "1.000":
    raise SystemExit("anchored capsule mismatch")
print("GROUP-MATCHED COMMERCIAL BENCHMARK PASSED")
