# Head stiffness and boundary-condition audit

| Location | Formula used | Implicit boundary | Declared/corrected boundary | Problem detected | Correction applied | Effect | Status |
|---|---|---|---|---|---|---|---|
| Methodology | T=(EI/kD)^0.25 | flexible-pile characteristic length | screening characteristic length | provenance not explicit | defined with units and linked to Le | no numerical change | corrected |
| Methodology | Le=min(L,3.5T) | lateral influence depth | effective lateral influence length | no sensitivity | added lambda_T table | displacement varies with lambda_T until capped by L | corrected |
| Methodology | k_single=3EI/Le^3 | cantilever-equivalent translation | conservative translation index | mixed with zero rotation | boundary assumption stated | no main-result change | corrected |
| Results tables | rotation=0.000 mrad | moment-only check with M=0 | not an independent physical prediction | could imply false prediction | moved to boundary sensitivity | rotation now reported by case | corrected |
| Group stiffness | k_group=n eta_g k_single | load-sharing efficiency | pile-count plus eta_g, no cap matrix | group transition underexplained | added explanation | no numerical change | corrected |
| CalculiX comparison | displacement checks | different numerical idealizations | checks, not proof | could overvalidate screening formula | added Table 31 | claims narrowed | corrected |
