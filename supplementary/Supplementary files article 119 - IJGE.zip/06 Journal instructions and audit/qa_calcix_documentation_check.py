from __future__ import annotations
import re, sys, zipfile
from pathlib import Path
from docx import Document
BASE=Path(__file__).resolve().parent
PKG=BASE.parents[0]
DOCX=PKG/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc=Document(DOCX)
text="\n".join(p.text for p in doc.paragraphs)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
required=[
 "CalculiX p-y FEM model definition and reproducibility metadata",
 "CalculiX 3D continuum model definition and reproducibility metadata",
 "Quantitative comparison of screening and CalculiX checks",
 "B31 beams + nonlinear SPRINGA springs",
 "shared-node bonded no-slip/no-gap",
 "0.286",
 "0.403",
 "3.219",
 "Ratio to 4.83 mm",
 "Ratio to 25.81 mm",
 "calcix_checks_trace.csv",
]
for token in required:
    if token.lower() not in text.lower(): errors.append("missing "+token)
bad=[r"validated by CalculiX",r"confirmed by 3D FEM",r"proves the screening",r"full 3D validation",r"independent calibration",r"field-scale validation",r"exact nonlinear FEM benchmark"]
for pat in bad:
    if re.search(pat,text,re.I): errors.append("bad CalculiX claim: "+pat)
for f in ["calcix_claims_audit.md","calcix_py_fem_model_dossier.md","calcix_3d_continuum_model_dossier.md","reproduce_calcix_checks.py","calcix_checks_trace.csv"]:
    if not (BASE/f).exists(): errors.append("missing "+f)
calc=PKG/"04 Supplementary"/"calcix_checks"
for f in ["py_fem_model.inp","py_fem_model.dat","py_fem_model.frd","continuum_static.inp","continuum_static.dat","continuum_static.frd","continuum_degraded.inp","continuum_degraded.dat","continuum_degraded.frd","README_calcix_checks.md"]:
    if not (calc/f).exists(): errors.append("missing supplement calcix_checks/"+f)
if errors:
    print("CALCULIX DOCUMENTATION QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("CALCULIX DOCUMENTATION QA PASSED")
