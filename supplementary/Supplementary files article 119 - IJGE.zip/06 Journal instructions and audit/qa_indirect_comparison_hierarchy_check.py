from __future__ import annotations
from pathlib import Path
from docx import Document
ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc = Document(DOCX)
text = "\n".join([p.text for p in doc.paragraphs] + [c.text for t in doc.tables for r in t.rows for c in r.cells])
required = [
    "Hierarchy of comparison evidence",
    "primary independent selected-case comparison is the CalculiX 3D continuum",
    "same-family solver-level check",
    "not a calibrated nonlinear contact validation",
    "not used as selected-case validation",
    "Table 20b. E0-E6 classification",
    "Table 20c. Principal independent selected-case comparison error table",
]
for token in required:
    if token.lower() not in text.lower():
        raise SystemExit("INDIRECT COMPARISON QA FAILED: missing " + token)
bad = [
    "ERIES validation of the 100 kN",
    "GROUP demo validation",
    "Rollins validates",
    "CalculiX p-y field validation",
]
for token in bad:
    if token.lower() in text.lower():
        raise SystemExit("INDIRECT COMPARISON QA FAILED: bad claim " + token)
for name in ["comparison_evidence_E0_E6_classification.csv", "principal_independent_comparison_error.csv", "master_evidence_hierarchy_max_claims.csv"]:
    if not (AUDIT / name).exists():
        raise SystemExit("INDIRECT COMPARISON QA FAILED: missing file " + name)
print("INDIRECT COMPARISON HIERARCHY QA PASSED")
