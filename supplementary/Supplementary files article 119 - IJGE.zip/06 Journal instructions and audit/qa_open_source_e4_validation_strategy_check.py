from pathlib import Path
import csv, zipfile
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
ZIP_PATH = ROOT / "04 Supplementary" / "Supplementary files article 119 - IJGE.zip"

doc = Document(DOCX)
text = "\n".join(p.text for p in doc.paragraphs) + "\n" + "\n".join(
    "\n".join(" | ".join(c.text for c in row.cells) for row in table.rows) for table in doc.tables
)
for token in [
    "Open-source equivalent validation strategy",
    "Table 20f. Open-source E4 evidence matrix for the selected 2x2 case.",
    "Table 21h. Multi-model displacement evidence band for the selected 2x2 screening case.",
    "OpenSeesPy beam-zeroLength p-y model",
    "3.213030",
    "4.867612",
    "2.55-6.44 mm",
    "does not claim general topology optimization",
]:
    assert token in text, f"Missing token: {token}"

op = list(csv.DictReader((AUDIT / "openseespy_open_source_check.csv").open(encoding="utf-8")))[0]
assert op["analysis_ok"] == "True"
assert abs(float(op["top_displacement_mean_mm"]) - 3.21303) < 1e-4

band = list(csv.DictReader((AUDIT / "multi_model_open_source_displacement_band.csv").open(encoding="utf-8")))
assert any(r["quantity"] == "lower_open_source_bound" and r["value_mm"] == "2.550000" for r in band)
assert any(r["quantity"] == "upper_open_source_bound" and abs(float(r["value_mm"]) - 6.438832) < 1e-6 for r in band)
assert any(r["quantity"] == "stress_test_excluded_from_band" for r in band)

with zipfile.ZipFile(ZIP_PATH, "r") as z:
    names = set(z.namelist())
    for name in [
        "06 Journal instructions and audit/openseespy_open_source_check.csv",
        "06 Journal instructions and audit/open_source_e4_evidence_matrix.csv",
        "06 Journal instructions and audit/multi_model_open_source_displacement_band.csv",
        "06 Journal instructions and audit/open_source_e4_validation_strategy_audit.md",
        "04 Supplementary/openseespy_open_source_check/openseespy_open_source_check.csv",
    ]:
        assert name in names, f"Missing ZIP entry: {name}"

print("OPEN-SOURCE E4 VALIDATION STRATEGY QA PASSED")
