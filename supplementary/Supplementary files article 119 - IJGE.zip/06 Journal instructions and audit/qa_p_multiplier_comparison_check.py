from __future__ import annotations
import csv
from pathlib import Path
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
FIG = ROOT / "02 Figures" / "Fig21_p_multiplier_side_by_side_comparison.png"

def fail(msg):
    raise SystemExit("P-MULTIPLIER COMPARISON QA FAILED: " + msg)

for name in ["p_multiplier_comparison_trace.csv", "p_multiplier_comparison_audit.md", "table_11b_p_multiplier_comparison.csv", "table_11c_p_multiplier_compatibility.csv"]:
    if not (AUDIT / name).exists():
        fail(f"missing {name}")
if not FIG.exists():
    fail("missing Figure 21")
with (AUDIT / "p_multiplier_comparison_trace.csv").open(encoding="utf-8", newline="") as f:
    rows = list(csv.DictReader(f))
ids = {r["method_id"]: r for r in rows}
for mid in ["M0", "M1a", "M1b", "M2", "M5"]:
    if ids[mid]["implemented_numerically"] != "yes" or not ids[mid]["displacement_mm"]:
        fail(f"{mid} lacks numerical displacement")
for mid in ["M3", "M4"]:
    if ids[mid]["implemented_numerically"] != "no" or not ids[mid]["reason_if_not_implemented"]:
        fail(f"{mid} lacks reason for non-implementation")
doc = Document(DOCX)
text = "\n".join([p.text for p in doc.paragraphs] + [cell.text for t in doc.tables for row in t.rows for cell in row.cells])
for token in ["Brown", "Rollins", "API", "DNV", "p-multiplier"]:
    if token in text and "Table 11b" not in text:
        fail("citations exist without comparison table")
for token in ["outperforms API", "outperforms DNV", "proves accuracy", "state-of-the-art superiority", "validated against Brown"]:
    if token.lower() in text.lower():
        fail(f"unsupported superiority/validation claim remains: {token}")
if "not implemented" not in text:
    fail("non-implemented method rationale missing from DOCX")
if "No profile-matched measured group p-y benchmark was available" not in text:
    fail("measured benchmark limitation missing")
print("P-MULTIPLIER COMPARISON QA PASSED")
