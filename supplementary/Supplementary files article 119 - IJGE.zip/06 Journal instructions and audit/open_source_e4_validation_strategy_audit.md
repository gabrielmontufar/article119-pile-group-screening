# Open-source equivalent validation strategy audit

The validation/comparison architecture was strengthened without relying on commercial software.

- Added OpenSeesPy as a second open-source solver for the selected 2x2 p-y model.
- Retained CalculiX 3D bonded continuum as a stiff lower-bound check.
- Added CalculiX 3D soil-modulus compliance convergence as selected-case continuum support.
- Defined an open-source multi-model displacement evidence band of 2.55-6.44 mm, with 4.83 mm retained as the reportable central pre-design estimate.
- Excluded the 25.81 mm severe envelope, 29.869 mm Brown/Rollins surrogate and commercial GROUP demo from the central open-source band.

Allowed claim: the selected-case displacement is supported by an open-source multi-model E4/E3 architecture within the pre-design scope.
Prohibited claim: experimental validation, blind field calibration, or final design replacement.
