from pathlib import Path
from docx import Document
import csv

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
AUDIT = ROOT / "06 Journal instructions and audit"
text = "\n".join(p.text for p in Document(DOCX).paragraphs)
assert "absolute preliminary displacement band" not in text.lower()
for token in [
    "Secondary external and software evidence: summarized role",
    "fixed 2x2 diameter-length-spacing screening workflow",
    "V4-S passport",
    "multi-model evidence band",
    "claim/escalation rules",
    "Detailed secondary evidence tables are intentionally placed in the supplement",
]:
    assert token in text, token
for overlong in [
    "Table 12. Limited Rollins liquefied-sand p-y scale comparison",
    "Figure 11. Normalized 2x2 pile-group dynamic-response consistency check",
]:
    assert overlong not in text, overlong
csv_path = AUDIT / "recent_references_2024_2026_verification.csv"
assert csv_path.exists()
rows = list(csv.DictReader(csv_path.open(encoding="utf-8")))
assert len(rows) >= 10
bad = [r for r in rows if r["status"] == "FAILED" or r["title_match"].startswith("partial (0")]
assert not bad, bad
print("SECONDARY_EVIDENCE_FOCUS_AND_REFERENCES_QA_PASSED")
