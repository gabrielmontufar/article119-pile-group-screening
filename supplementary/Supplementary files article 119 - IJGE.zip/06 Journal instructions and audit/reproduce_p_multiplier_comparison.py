from __future__ import annotations
import csv
from pathlib import Path
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
TRACE = AUDIT / "p_multiplier_comparison_trace.csv"

with TRACE.open(encoding="utf-8", newline="") as f:
    rows = list(csv.DictReader(f))
required = {"M0", "M1a", "M1b", "M2", "M3", "M4", "M5"}
ids = {r["method_id"] for r in rows}
if not required.issubset(ids):
    raise SystemExit("missing comparison method rows")
lookup = {r["method_id"]: r for r in rows}
checks = {
    "M0": 17.921,
    "M1a": 25.814,
    "M1b": 4.830,
    "M2": 29.868,
    "M5": 3.219,
}
for mid, expected in checks.items():
    got = float(lookup[mid]["displacement_mm"])
    if abs(got - expected) > 0.03:
        raise SystemExit(f"{mid} displacement mismatch: {got}")
for mid in ["M3", "M4"]:
    if lookup[mid]["implemented_numerically"] != "no" or not lookup[mid]["reason_if_not_implemented"]:
        raise SystemExit(f"{mid} missing non-implementation reason")
doc = Document(DOCX)
text = "\n".join([p.text for p in doc.paragraphs] + [cell.text for t in doc.tables for row in t.rows for cell in row.cells])
for required_text in ["Side-by-side comparison against established group p-y approaches", "Brown/Reese-style row p-multiplier baseline", "No profile-matched measured group p-y benchmark was available", "not as proof that one method is universally superior"]:
    if required_text not in text:
        raise SystemExit(f"missing DOCX text: {required_text}")
print("P-MULTIPLIER COMPARISON TRACE PASSED")
