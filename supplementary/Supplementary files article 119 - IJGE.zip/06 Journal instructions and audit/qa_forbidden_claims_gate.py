from pathlib import Path
import re, sys
from docx import Document

ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
DOCS = [
    ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx",
    ROOT / "05 Cover and declarations" / "Cover letter - IJGE.docx",
    ROOT / "05 Cover and declarations" / "Highlights - IJGE.docx",
]
FORBIDDEN = [
    r"field validated",
    r"experimentally validated",
    r"calibrated cyclic response",
    r"validated by ERIES",
    r"validated by GEOLAB",
    r"full contact FEM",
    r"final design verification",
    r"calibrated absolute head displacement",
    r"calibrated predictor",
    r"ERIES calibration",
    r"general topology optimization",
]
errors = []
def negated_context(text: str, start: int, end: int) -> bool:
    ctx = text[max(0, start-90):min(len(text), end+90)].lower()
    negators = ["not ", "no ", "neither ", "does not claim", "is not", "not a ", "not an ", "not treated as"]
    return any(n in ctx for n in negators)

for docx in DOCS:
    if not docx.exists():
        continue
    doc = Document(docx)
    text = "\n".join(p.text for p in doc.paragraphs)
    for pat in FORBIDDEN:
        for m in re.finditer(pat, text, re.I):
            if not negated_context(text, m.start(), m.end()):
                errors.append(f"{docx.name} contains forbidden claim: {pat}")
if errors:
    print("FORBIDDEN CLAIMS QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("FORBIDDEN CLAIMS QA PASSED")
