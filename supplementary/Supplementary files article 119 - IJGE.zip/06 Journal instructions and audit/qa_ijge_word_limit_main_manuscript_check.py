
import re
from pathlib import Path
from docx import Document
ROOT = Path(r'C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515')
DOCX = ROOT / '01 Manuscript' / 'Cyclic Lateral Pile Group - IJGE manuscript.docx'
doc = Document(str(DOCX))
ps=[p.text.strip() for p in doc.paragraphs]
st=next(i for i,t in enumerate(ps) if t.startswith('1 Introduction'))
en=next(i for i,t in enumerate(ps) if t.startswith('References'))
wc=sum(len(re.findall(r"[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)?", t)) for t in ps[st:en])
if wc > 5000:
    raise SystemExit(f'IJGE word limit exceeded: {wc} > 5000')
if len(doc.inline_shapes) < 7:
    raise SystemExit(f'Expected embedded main figures, found {len(doc.inline_shapes)}')
if len(doc.tables) < 5:
    raise SystemExit(f'Expected essential main tables, found {len(doc.tables)}')
text='\n'.join(ps)
for needle in ['preliminary screening band','Online Resource 2','External blind','V4-S','Generative artificial intelligence tools were used']:
    if needle not in text:
        raise SystemExit(f'Missing required main manuscript text: {needle}')
print('IJGE_WORD_LIMIT_MAIN_MANUSCRIPT_QA_PASSED')
print(f'word_count={wc}; figures={len(doc.inline_shapes)}; tables={len(doc.tables)}')
