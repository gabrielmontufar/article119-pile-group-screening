from __future__ import annotations
import csv
from pathlib import Path

BASE = Path(__file__).resolve().parent
INV = BASE / "published_group_tests_inventory.csv"
rows = list(csv.DictReader(INV.open(encoding="utf-8")))
if not any(r["used quantitatively"].startswith("yes") and "GEOLAB" in r["reference"] for r in rows):
    raise SystemExit("GEOLAB limited quantitative check missing from inventory")
for r in rows:
    if r["used quantitatively"] == "yes" and r["compatibility with selected case"] == "low":
        raise SystemExit("low-compatibility test marked as direct quantitative validation")
print("PUBLISHED GROUP TEST INVENTORY CHECK PASSED")
