# CalculiX p-y FEM model dossier

## Identification
- Solver: CalculiX 2.23.0.
- Files: `py_fem_model.inp`, `py_fem_model.dat`, `py_fem_model.frd`, `py_fem_model.sta`, `py_fem_model.cvg`.
- Generator: `calculix_py_fem_check.py`.
- Units: kN and m; reported displacements are converted to mm.

## Geometry and Mesh
- Topology: selected 2x2 pile group.
- Piles: 4 piles, D = 0.60 m, embedded length = 8.0 m, spacing = 2.5D = 1.50 m.
- Pile coordinates: (+/-0.75 m, +/-0.75 m).
- Vertical discretization: 0.5 m; 16 segments per pile.
- Elements/nodes: 64 B31 beam elements and 64 nonlinear SPRINGA elements; 132 nodes in the input file.

## Structural Model
- Concrete: E = 30,000,000 kN/m2, nu = 0.20.
- Beam section: equivalent rectangular B31 section preserving bending inertia.
- Analysis: static-equivalent lateral load; no cyclic time-history integration.

## p-y Springs
- Element: CalculiX SPRINGA, nonlinear multilinear force-displacement law.
- Spacing: one spring at each 0.5 m depth increment below the pile head.
- Spring forces derive from the degraded layer profile, D = 0.60 m, dz = 0.5 m and eta_g = 0.694.
- The spring model is an independent solver implementation of the p-y idealization, not an experimental calibration.

## Boundary Conditions and Load
- Pile tips fixed.
- Auxiliary ground spring nodes fixed in translation.
- Head nodes are laterally loaded in +x.
- Total lateral load = 100 kN; load per pile = 25 kN.

## Result Extraction
- Source: `py_fem_model.dat`, set `TOP`.
- Component: Ux.
- Mean = 3.219 mm; max = 3.219 mm.
- Allowed claim: solver-level p-y traceability; not field validation.
