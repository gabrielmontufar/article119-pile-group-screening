# Indirect comparison correction audit

The primary independent selected-case comparison is now the CalculiX 3D continuum lower-bound check. It is equivalent in geometry/profile/load but limited by bonded-interface stiffness. All other evidence is secondary, contextual, same-family, surrogate or non-equivalent commercial evidence.

GROUP demo and GROUP-matched results are not used as selected ERIES-case validation. ERIES is only small-amplitude dynamic impedance. Rollins is only a severe external p-y scale check. CalculiX p-y is a same-family solver-level check.
