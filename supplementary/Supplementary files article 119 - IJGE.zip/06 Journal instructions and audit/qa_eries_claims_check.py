from __future__ import annotations
import re, sys
from pathlib import Path
from docx import Document
BASE=Path(__file__).resolve().parent
DOCX=BASE.parents[0]/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc=Document(DOCX)
text="\n".join(p.text for p in doc.paragraphs)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
bad=[
    r"ERIES calibration", r"ERIES-calibrated", r"validated against ERIES",
    r"full-scale ERIES[^.\n]{0,80}validation", r"ERIES[^.\n]{0,80}validation benchmark",
    r"calibrated absolute displacement[^.\n]{0,80}ERIES",
    r"100 kN validation", r"validates?[^.\n]{0,80}25\.81",
]
for pat in bad:
    if re.search(pat,text,re.I): errors.append("bad ERIES claim pattern: "+pat)
for m in re.finditer(r"force-displacement", text, re.I):
    ctx=text[max(0,m.start()-140):m.end()+180].lower()
    # This QA audits ERIES overclaims only. GEOLAB now intentionally includes a direct measured
    # force-displacement envelope and should not be blocked by the ERIES boundary check.
    if "eries" not in ctx:
        continue
    if not any(x in ctx for x in ["not available","does not provide","do not provide","no synchronized","not a force-displacement"]):
        errors.append("force-displacement near ERIES without limitation")
for m in re.finditer(r"hysteresis loop|hysteretic loop", text, re.I):
    ctx=text[max(0,m.start()-120):m.end()+160].lower()
    if not any(x in ctx for x in ["not a measured","no measured","not available","does not provide","do not provide"]):
        errors.append("hysteresis loop without not-measured limitation")
required=[
    "limited small-amplitude dynamic-impedance consistency check",
    "not a force-displacement calibration",
    "do not provide synchronized force-displacement loops",
    "do not calibrate cyclic degradation",
    "do not validate the 100 kN large-displacement screening case",
    "not used to calibrate the reported FEM-anchored preliminary displacement estimate",
    "small-amplitude dynamic-impedance consistency only",
]
for token in required:
    if token.lower() not in text.lower(): errors.append("missing required ERIES boundary: "+token)
for f in ["eries_claims_audit.md","eries_data_inventory.csv","reproduce_eries_impedance_check.py","eries_impedance_trace.csv"]:
    if not (BASE/f).exists(): errors.append("missing "+f)
if errors:
    print("ERIES CLAIMS QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("ERIES CLAIMS QA PASSED")
