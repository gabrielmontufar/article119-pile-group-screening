# GROUP demo-mode commercial-tool comparison

GROUP v2022.12.10 was installed locally and opened in demo mode. The files in this folder are the official bundled 3D Example 2 2x2 pile-group input/output files. They are not a selected-case run for the manuscript soil profile. The parsed values are used only as a non-equivalent commercial-tool sanity check.

Parsed resultant lateral load: 400.957 kN.
Parsed resultant displacement: 0.805 mm.
Linearized 100 kN displacement: 0.201 mm.
