# Commercial-tool and published group-test comparison audit

| Section/term audited | Manuscript section | Claim current or implied | Reference cited | Evidence type current | Commercial comparison existing | Group-test comparison existing | Problem detected | Corrective action | Final status |
|---|---|---|---|---|---|---|---|---|---|
| LPILE/GROUP/ALP | new comparison section | commercial comparison must not be implied without exports | none cited as direct output | none | no | no | would overstate validation | added explicit no-run row and QA blocker | bounded |
| p-multiplier | results/discussion | practice comparison exists but needed broader framing | Brown/Rollins-style row multipliers | numeric benchmark | no | surrogate only | could be misread as commercial validation | renamed as practice-equivalent surrogate | corrected |
| API/DNV | practice context | practice p-y guidance | API/DNV | contextual only | no | no | no auditable group formula for selected case in package | reason-not-implemented row added | bounded |
| Brown/Rollins | p-multiplier and trend checks | external pile-group evidence | published group tests | trend/practice/numeric surrogate | no | limited | not selected-profile calibration | inventory and surrogate table added | corrected |
| McVay/centrifuge | literature context | centrifuge group evidence | published tests | qualitative only | no | screened only | not digitized or profile-matched | inventory row added | bounded |
| GEOLAB | external evidence | measured group-response check | Deltares open dataset | numerical normalized check | no | yes, limited | different scale/configuration | kept as limited scale/configuration check | bounded |
| ERIES | dynamic evidence | full-scale dynamic-impedance check | ERIES-RESPOND | numerical impedance | no | not static group test | could be overread as hysteretic calibration | limited to dynamic impedance | bounded |
| external validation/benchmark | whole manuscript | validation hierarchy | multiple checks | mixed evidence | no direct commercial output | limited direct published-test fit | risk of overclaim | evidence matrix and QA added | corrected |
| GROUP demo mode | Table 11g | official installed commercial demo output | Ensoft GROUP v2022.12.10 | numerical commercial demo output | yes, non-equivalent demo | no selected-case group-test validation | selected case was not run/exported | official demo output copied and parsed; claim limited to non-equivalent commercial sanity check | bounded |
