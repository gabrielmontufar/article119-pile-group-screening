from __future__ import annotations
import csv
from pathlib import Path

BASE = Path(__file__).resolve().parent
CSV = BASE / "practice_equivalent_group_py_benchmark.csv"
rows = list(csv.DictReader(CSV.open(encoding="utf-8")))
required = {
    "Proposed FEM-anchored preliminary prediction": 4.83,
    "Proposed severe-degradation screening envelope": 25.813803,
    "Practice-equivalent Brown/Rollins-style row p-multiplier": 29.868,
    "CalculiX nonlinear p-y FEM check": 3.219416,
}
lookup = {r["method"]: r for r in rows}
for method, expected in required.items():
    if method not in lookup:
        raise SystemExit(f"missing method: {method}")
    got = float(lookup[method]["predicted_displacement_mm"])
    if abs(got - expected) > 0.05:
        raise SystemExit(f"displacement mismatch for {method}: {got}")
commercial_terms = ["LPILE", "GROUP", "ALP"]
for term in commercial_terms:
    if any(term in r["method"] and "commercial" not in r["allowed_claim"].lower() for r in rows):
        raise SystemExit(f"commercial term used without boundary: {term}")
print("PRACTICE-EQUIVALENT GROUP PY BENCHMARK PASSED")
