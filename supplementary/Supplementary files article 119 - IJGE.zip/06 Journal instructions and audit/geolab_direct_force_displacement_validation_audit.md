# GEOLAB direct force-displacement validation audit

Extracted from `C:\Users\gjm31\Documents\Codex\2026-05-14\cyclic-lateral-pile-group-optimization-with\geolab_test4_extract\Export Test 4\Loading at 50g_100Hz.MAT`.

Channels used: Channel 3 Force_loading_plunger; Channels 7-10 sign-oriented laser displacement channels; Channel 50 G-level.
This is a direct measured force-displacement envelope from an open pile-group test. It is not selected-profile calibration because topology, scale and soil profile differ from the ERIES-aligned 2x2 screening case.
Normalized RMSE against the linear screening shape = 0.099.
