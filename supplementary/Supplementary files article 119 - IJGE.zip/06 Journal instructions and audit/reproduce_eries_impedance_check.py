from __future__ import annotations
import csv, io, math, re, tempfile, zipfile
from pathlib import Path
import numpy as np

OUT = Path(__file__).resolve().parent
PILE_DIAMETER_M = 0.60
ECCENTRICITY_KG_M = {"FVA": 1.85, "FVAB": 3.93, "FVABC": 6.93, "FVABCD": 11.31, "FVABCD90": 11.31}


def find_package_zip() -> Path | None:
    candidates = [
        OUT.parent / "04 Supplementary" / "Supplementary files article 119 - IJGE.zip",
        OUT.parent / "Supplementary files article 119 - IJGE.zip",
    ]
    for path in candidates:
        if path.exists():
            return path
    return None


def extract_eries_from_zip(zip_path: Path) -> tuple[Path, tempfile.TemporaryDirectory]:
    prefix = "supplementary_pile_group_optimization/validation_eries_respond/"
    tmp = tempfile.TemporaryDirectory()
    with zipfile.ZipFile(zip_path) as zf:
        members = [m for m in zf.namelist() if m.startswith(prefix)]
        if not members:
            raise SystemExit("ERIES IMPEDANCE CHECK FAILED: ERIES files missing from ZIP")
        zf.extractall(tmp.name, members)
    return Path(tmp.name) / prefix, tmp


def find_eries_root() -> tuple[Path, tempfile.TemporaryDirectory | None]:
    for root in [OUT.parent, OUT.parent.parent]:
        cand = root / "supplementary_pile_group_optimization" / "validation_eries_respond"
        if cand.exists():
            return cand, None
    zip_path = find_package_zip()
    if zip_path:
        return extract_eries_from_zip(zip_path)
    raise SystemExit("ERIES IMPEDANCE CHECK FAILED: reproducibility data not found")


ERIES_ROOT, _TMP = find_eries_root()
DATA = ERIES_ROOT / "data_processed"
TARGET = ERIES_ROOT / "tables" / "eries_normalized_lateral_impedance.csv"


def harmonic_metrics(path: Path) -> dict:
    arr = np.loadtxt(path)
    t = arr[:, 0]
    a = arr[:, 1] - float(np.mean(arr[:, 1]))
    x = np.arange(len(a), dtype=float)
    slope, intercept = np.polyfit(x, a, 1)
    a = a - (slope * x + intercept)
    dt = float(np.median(np.diff(t)))
    freq = np.fft.rfftfreq(len(a), dt)
    spec = np.abs(np.fft.rfft(a))
    mask = (freq >= 1.0) & (freq <= 15.0)
    idx = np.where(mask)[0][int(np.argmax(spec[mask]))]
    f = float(freq[idx])
    acc_amp = float(2.0 * spec[idx] / len(a))
    disp_m = acc_amp / max((2.0 * math.pi * f) ** 2, 1e-12)
    m = re.match(r"(?P<date>\d+)_(?P<mass>FV[A-Z0-9]+)_(?P<loc>\d+\.\d+)_(?P<axis>[env])_", path.name)
    mass = m.group("mass") if m else ""
    ecc = ECCENTRICITY_KG_M[mass]
    force_kN = ecc * (2.0 * math.pi * f) ** 2 / 1000.0
    k_kN_m = force_kN / max(disp_m, 1e-15)
    return {
        "source_file": path.name,
        "dominant_frequency_hz": f,
        "acceleration_amplitude_m_s2": acc_amp,
        "displacement_amplitude_mm": 1000.0 * disp_m,
        "computed_shaker_force_kN": force_kN,
        "equivalent_dynamic_stiffness_kN_per_m": k_kN_m,
        "diameter_scaled_impedance_kN": k_kN_m * PILE_DIAMETER_M,
        "claim_limit": "limited small-amplitude dynamic-impedance consistency only",
    }


rows = [harmonic_metrics(p) for p in sorted(DATA.glob("20240523_FV*_1.1_e_acc_conv.xy"))]
target = {r["source_file"]: r for r in csv.DictReader(TARGET.open(encoding="utf-8"))}
with (OUT / "eries_impedance_trace.csv").open("w", newline="", encoding="utf-8") as f:
    fields = ["source_file", "dominant_frequency_hz", "acceleration_amplitude_m_s2", "displacement_amplitude_mm", "computed_shaker_force_kN", "equivalent_dynamic_stiffness_kN_per_m", "diameter_scaled_impedance_kN", "claim_limit"]
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        ref = target.get(r["source_file"])
        if not ref:
            raise SystemExit("ERIES IMPEDANCE CHECK FAILED: missing target row for " + r["source_file"])
        for k in fields[1:-1]:
            if abs(float(r[k]) - float(ref[k])) > max(1e-6, abs(float(ref[k])) * 0.02):
                raise SystemExit(f"ERIES IMPEDANCE CHECK FAILED: {r['source_file']} {k} {r[k]} != {ref[k]}")
        w.writerow(r)
print("NO SYNCHRONIZED FORCE CHANNEL AVAILABLE - HYSTERETIC CALIBRATION NOT PERFORMED")
if len(rows) < 5:
    raise SystemExit("ERIES IMPEDANCE CHECK FAILED")
print("ERIES IMPEDANCE CHECK REPRODUCED")
