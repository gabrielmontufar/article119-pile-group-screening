# Model specification audit

| Component | Current location | Current formulation | Missing information | Verifiable source | Correction applied | Final status |
|---|---|---|---|---|---|---|
| eta_g | Methodology | qualitative group-efficiency mention | equation, coefficients, clipping limits | run_pile_group_optimization.py | added equation and Table 25 | specified |
| spacing dependence | Results/Table 10 | trend check only | functional dependence on s/D | group_efficiency() | added exp spacing-decay term | specified |
| rows/columns dependence | Methodology | not explicit | nr,nc coefficients | group_efficiency() | added beta_r and beta_c | specified |
| eta bounds | not explicit | not stated | eta_min/eta_max | group_efficiency() | added clip limits | specified |
| depth weighting | Methodology | near-surface qualitative text | w_j equation and dz | weighted_soil_modulus() | added equation and Table 26 | specified |
| cyclic degradation | Methodology/Table 3 | partial equation | N0 and provenance | weighted_soil_modulus() | added Table 27 | specified |
| N0 | not explicit | hidden 10000 | normalization parameter | code constant in expression | declared as screening normalizer | specified |
| alpha_i | Table 3 | values without provenance | source/provenance/limitation | LAYERS in code | added provenance and limitation | specified |
| displacement link | Methodology | formula chain incomplete | T, Le, k_single, k_group, u | evaluate() | added connection paragraph and Table 28 | specified |