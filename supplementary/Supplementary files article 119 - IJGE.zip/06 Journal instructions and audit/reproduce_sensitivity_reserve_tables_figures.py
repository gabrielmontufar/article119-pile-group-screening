from __future__ import annotations

import csv
import json
import math
import re
import shutil
import zipfile
from pathlib import Path

from docx import Document
from docx.shared import Inches
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(
    r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art"
    r"\Entrega International Journal of Geotechnical Engineering 20260515"
)
ARTICLE_ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art")
SOURCE_DATA = ARTICLE_ROOT / "supplementary_pile_group_optimization" / "data"
AUDIT = ROOT / "06 Journal instructions and audit"
FIGS = ROOT / "02 Figures"
TABLES = ROOT / "03 Tables" / "IJGE separate tables corrected"
DOCX = ROOT / "01 Manuscript" / "Cyclic Lateral Pile Group - IJGE manuscript.docx"
ZIP_PATH = ROOT / "04 Supplementary" / "Supplementary files article 119 - IJGE.zip"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(rows[0].keys()) if rows else []
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def fnum(row: dict, key: str, default: float = 0.0) -> float:
    val = row.get(key, "")
    return default if val == "" else float(val)


def font(size: int, bold: bool = False):
    candidates = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\calibrib.ttf" if bold else r"C:\Windows\Fonts\calibri.ttf",
    ]
    for c in candidates:
        if Path(c).exists():
            return ImageFont.truetype(c, size)
    return ImageFont.load_default()


def draw_axes(d: ImageDraw.ImageDraw, box, xlabel: str, ylabel: str, title: str):
    x0, y0, x1, y1 = box
    d.rectangle(box, outline=(0, 0, 0), width=2)
    d.text((x0 + 20, y0 - 58), title, fill=(0, 0, 0), font=font(30, True))
    d.text((x0 + 20, y1 + 55), xlabel, fill=(0, 0, 0), font=font(25))
    d.text((42, y0 + (y1 - y0) // 2 - 20), ylabel, fill=(0, 0, 0), font=font(25))


def line_plot(path: Path, rows: list[dict], xkey: str, ykeys: list[tuple[str, str, tuple[int, int, int]]], title: str, xlabel: str, ylabel: str):
    img = Image.new("RGB", (1600, 950), "white")
    d = ImageDraw.Draw(img)
    box = (190, 135, 1420, 720)
    draw_axes(d, box, xlabel, ylabel, title)
    xs = [float(r[xkey]) for r in rows]
    yvals = [float(r[k]) for k, _, _ in ykeys for r in rows if r.get(k, "") != ""]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = 0.0, max(yvals) * 1.12
    for t in [xmin, 1.0, xmax]:
        if xmin <= t <= xmax:
            px = box[0] + int((t - xmin) / max(xmax - xmin, 1e-9) * (box[2] - box[0]))
            d.line((px, box[3], px, box[3] + 10), fill=(0, 0, 0), width=2)
            d.text((px - 24, box[3] + 18), f"{t:g}", fill=(0, 0, 0), font=font(21))
    for t in [0.0, 0.5, 1.0]:
        py = box[3] - int((t - ymin) / max(ymax - ymin, 1e-9) * (box[3] - box[1]))
        d.line((box[0] - 10, py, box[0], py), fill=(0, 0, 0), width=2)
        d.text((box[0] - 72, py - 12), f"{t:.1f}", fill=(0, 0, 0), font=font(21))
    for idx, (key, label, color) in enumerate(ykeys):
        pts = []
        for r in rows:
            if r.get(key, "") == "":
                continue
            x = float(r[xkey])
            y = float(r[key])
            px = box[0] + int((x - xmin) / max(xmax - xmin, 1e-9) * (box[2] - box[0]))
            py = box[3] - int((y - ymin) / max(ymax - ymin, 1e-9) * (box[3] - box[1]))
            pts.append((px, py))
            d.ellipse((px - 7, py - 7, px + 7, py + 7), fill=color, outline=(0, 0, 0))
        if len(pts) > 1:
            d.line(pts, fill=color, width=4)
        lx, ly = 1070, 245 + idx * 48
        d.rectangle((lx - 20, ly - 10, lx + 320, ly + 34), fill=(255, 255, 255))
        d.line((lx, ly + 12, lx + 44, ly + 12), fill=color, width=5)
        d.text((lx + 58, ly), label, fill=(0, 0, 0), font=font(22, True))
    img.save(path)


def reserve_bar(path: Path, rows: list[dict]):
    img = Image.new("RGB", (1700, 950), "white")
    d = ImageDraw.Draw(img)
    d.text((90, 45), "Robust reserve check within the 2x2 design space", fill=(0, 0, 0), font=font(31, True))
    x0, y0, width, height = 420, 135, 720, 65
    max_cost = max(float(r["cost_index"]) for r in rows) * 1.15
    for i, r in enumerate(rows):
        y = y0 + i * 120
        d.text((80, y + 14), f"limit <= {float(r['reserve_limit']):.2f}", font=font(27, True), fill=(0, 0, 0))
        bar = int(float(r["cost_index"]) / max_cost * width)
        d.rectangle((x0, y, x0 + width, y + height), outline=(0, 0, 0), width=2)
        d.rectangle((x0, y, x0 + bar, y + height), fill=(42, 91, 132))
        label = f"{r['topology']}  s={float(r['spacing_D']):.1f}D  util={float(r['utilization']):.3f}  cost={float(r['cost_index']):.1f}"
        d.text((x0 + width + 25, y + 15), label, font=font(23), fill=(0, 0, 0))
    d.text((x0, 760), "The topology remains 2x2; only spacing changes at the 0.85 limit.", fill=(0, 0, 0), font=font(25))
    img.save(path)


def winkler_bar(path: Path, rows: list[dict]):
    r = rows[0]
    vals = [
        ("stress-test envelope", float(r["stress_test_displacement_mm"]), (42, 91, 132)),
        ("Winkler check", float(r["independent_winkler_displacement_mm"]), (187, 120, 44)),
    ]
    img = Image.new("RGB", (1500, 850), "white")
    d = ImageDraw.Draw(img)
    d.text((110, 55), "Independent Winkler check for selected 2x2 case", fill=(0, 0, 0), font=font(31, True))
    x0, y0, w, h = 300, 190, 820, 80
    maxv = max(v for _, v, _ in vals) * 1.15
    for i, (lab, val, col) in enumerate(vals):
        y = y0 + i * 150
        d.text((75, y + 20), lab, font=font(25, True), fill=(0, 0, 0))
        d.rectangle((x0, y, x0 + w, y + h), outline=(0, 0, 0), width=2)
        d.rectangle((x0, y, x0 + int(val / maxv * w), y + h), fill=col)
        d.text((x0 + w + 25, y + 22), f"{val:.2f} mm", font=font(25), fill=(0, 0, 0))
    d.text((x0, 590), "Single-case magnitude check; no rank correlation is claimed.", font=font(24), fill=(0, 0, 0))
    img.save(path)


def table_rows_from_source():
    baseline_src = read_csv(SOURCE_DATA / "baseline_comparison.csv")
    reserve_src = read_csv(SOURCE_DATA / "robust_reserve_check.csv")
    degradation_src = read_csv(SOURCE_DATA / "degradation_sensitivity.csv")
    cost_src = read_csv(SOURCE_DATA / "cost_weight_sensitivity.csv")
    winkler_src = read_csv(SOURCE_DATA / "independent_winkler_check.csv")
    selected = read_csv(SOURCE_DATA / "selected_design.csv")[0]

    table6 = [{
        "Case": r["case"],
        "Topology": r["topology"],
        "D (m)": f'{fnum(r,"diameter_m"):.2f}',
        "L (m)": f'{fnum(r,"length_m"):.0f}',
        "Spacing": f'{fnum(r,"spacing_D"):.1f}D',
        "Soil k (kN/m3)": f'{fnum(r,"soil_modulus_kN_m3"):.0f}',
        "T (m)": f'{fnum(r,"characteristic_length_m"):.2f}',
        "Le (m)": f'{fnum(r,"effective_length_m"):.1f}',
        "Utilization": f'{fnum(r,"constraint_utilization"):.3f}',
        "Cost index": f'{fnum(r,"cost_index"):.1f}',
    } for r in baseline_src]

    table7 = [{
        "Reserve limit": f'{fnum(r,"reserve_limit"):.2f}',
        "Topology": r["topology"],
        "D (m)": f'{fnum(r,"diameter_m"):.2f}',
        "L (m)": f'{fnum(r,"length_m"):.0f}',
        "Spacing": f'{fnum(r,"spacing_D"):.1f}D',
        "Utilization": f'{fnum(r,"constraint_utilization"):.3f}',
        "Cost index": f'{fnum(r,"cost_index"):.1f}',
    } for r in reserve_src]

    table8 = [{
        "Cycle multiplier": f'{fnum(r,"cycle_multiplier"):.2f}',
        "Selected topology": r["topology"],
        "D (m)": f'{fnum(r,"diameter_m"):.2f}',
        "L (m)": f'{fnum(r,"length_m"):.0f}',
        "Spacing": f'{fnum(r,"spacing_D"):.1f}D',
        "Soil k (kN/m3)": f'{fnum(r,"soil_modulus_kN_m3"):.0f}',
        "Stress-test disp. (mm)": f'{fnum(r,"head_displacement_mm"):.2f}',
        "Feasible designs": f'{fnum(r,"feasible_count"):.0f}',
        "Utilization": f'{fnum(r,"constraint_utilization"):.3f}',
        "Cost index": f'{fnum(r,"cost_index"):.1f}',
    } for r in degradation_src]

    table9 = [{
        "Cost-weight case": r["cost_weight_case"],
        "Selected topology": r["topology"],
        "D (m)": f'{fnum(r,"diameter_m"):.2f}',
        "L (m)": f'{fnum(r,"length_m"):.1f}',
        "s/D": f'{fnum(r,"spacing_D"):.1f}',
        "Reweighted cost index": f'{fnum(r,"reweighted_cost_index"):.1f}',
        "Utilization": f'{fnum(r,"constraint_utilization"):.3f}',
    } for r in cost_src]

    table11 = [{
        "Topology": r["topology"],
        "Stress-test disp. (mm)": f'{fnum(r,"screening_displacement_mm"):.2f}',
        "Independent Winkler disp. (mm)": f'{fnum(r,"independent_fd_displacement_mm"):.2f}',
        "Winkler/stress-test ratio": f'{fnum(r,"independent_fd_displacement_mm") / fnum(r,"screening_displacement_mm"):.2f}',
        "Role": "single-case magnitude and stiffness cross-check",
    } for r in winkler_src]

    base_util = fnum(selected, "constraint_utilization")
    sens_rows = []
    for f in [0.80, 0.90, 1.00, 1.10, 1.20]:
        sens_rows.append({"analysis_type": "local_sensitivity", "case_id": "lateral_load", "perturbation_factor": f, "utilization": base_util * f})
    for f in [0.25, 0.50, 1.00, 2.00, 4.00]:
        sens_rows.append({"analysis_type": "local_sensitivity", "case_id": "cycles", "perturbation_factor": f, "utilization": max(base_util, fnum(selected, "fatigue_index") * f)})
    for f in [0.70, 0.85, 1.00, 1.15, 1.30]:
        sens_rows.append({"analysis_type": "local_sensitivity", "case_id": "soil_stiffness", "perturbation_factor": f, "utilization": base_util / math.sqrt(f)})

    return baseline_src, reserve_src, degradation_src, cost_src, winkler_src, selected, table6, table7, table8, table9, table11, sens_rows


def canonical_rows(baseline, reserve, degradation, cost, winkler, selected, sens_rows):
    rows = []
    fields = [
        "analysis_type", "case_id", "topology", "D_m", "L_m", "spacing_D", "soil_k_kN_m3", "T_m", "Le_m",
        "displacement_mm", "utilization", "cost_index", "feasible_designs", "active_constraint",
        "selected_candidate", "source_script", "notes",
    ]

    def add(src_rows, analysis, id_key, feasible_key="", cost_key="cost_index"):
        for r in src_rows:
            rows.append({
                "analysis_type": analysis,
                "case_id": r.get(id_key, ""),
                "topology": r.get("topology", ""),
                "D_m": r.get("diameter_m", ""),
                "L_m": r.get("length_m", ""),
                "spacing_D": r.get("spacing_D", ""),
                "soil_k_kN_m3": r.get("soil_modulus_kN_m3", ""),
                "T_m": r.get("characteristic_length_m", ""),
                "Le_m": r.get("effective_length_m", ""),
                "displacement_mm": r.get("head_displacement_mm", ""),
                "utilization": r.get("constraint_utilization", ""),
                "cost_index": r.get(cost_key, r.get("cost_index", "")),
                "feasible_designs": r.get(feasible_key, ""),
                "active_constraint": "lateral displacement screening limit",
                "selected_candidate": "yes",
                "source_script": "supplementary_pile_group_optimization/code/run_pile_group_optimization.py",
                "notes": "canonical source data copied from reproducible supplement",
            })

    add(baseline, "baseline_comparison", "case")
    add(reserve, "reserve_check", "reserve_limit")
    add(degradation, "degradation_sensitivity", "cycle_multiplier", "feasible_count")
    add(cost, "cost_weight_sensitivity", "cost_weight_case", cost_key="reweighted_cost_index")
    for r in sens_rows:
        rows.append({
            "analysis_type": r["analysis_type"],
            "case_id": r["case_id"],
            "topology": selected["topology"],
            "D_m": selected["diameter_m"],
            "L_m": selected["length_m"],
            "spacing_D": selected["spacing_D"],
            "soil_k_kN_m3": selected["soil_modulus_kN_m3"],
            "T_m": selected["characteristic_length_m"],
            "Le_m": selected["effective_length_m"],
            "displacement_mm": "",
            "utilization": r["utilization"],
            "cost_index": selected["cost_index"],
            "feasible_designs": "",
            "active_constraint": "lateral displacement screening limit",
            "selected_candidate": "selected 2x2 candidate",
            "source_script": "06 Journal instructions and audit/reproduce_sensitivity_reserve_tables_figures.py",
            "notes": f'perturbation_factor={r["perturbation_factor"]}',
        })
    for r in winkler:
        rows.append({
            "analysis_type": "independent_winkler_check",
            "case_id": "selected_2x2",
            "topology": r["topology"],
            "D_m": r["diameter_m"],
            "L_m": r["length_m"],
            "spacing_D": r["spacing_D"],
            "soil_k_kN_m3": "",
            "T_m": "",
            "Le_m": "",
            "displacement_mm": r["independent_fd_displacement_mm"],
            "utilization": "",
            "cost_index": "",
            "feasible_designs": "",
            "active_constraint": "single-case Winkler cross-check",
            "selected_candidate": "selected 2x2 candidate",
            "source_script": "supplementary_pile_group_optimization/code/independent_winkler_check.py",
            "notes": "not a multi-topology rank correlation",
        })
    return rows, fields


def write_sources(table6, table7, table8, table9, table11, reserve_src, degradation_src, winkler_src, sens_rows):
    write_csv(AUDIT / "table_06_baseline.csv", table6)
    write_csv(AUDIT / "table_07_reserve.csv", table7)
    write_csv(AUDIT / "table_08_degradation.csv", table8)
    write_csv(AUDIT / "table_09_cost_weight.csv", table9)
    write_csv(AUDIT / "table_11_winkler.csv", table11)
    for name, rows in [
        ("Table_06.csv", table6), ("Table_07.csv", table7), ("Table_08.csv", table8),
        ("Table_09.csv", table9), ("Table_11.csv", table11),
    ]:
        write_csv(TABLES / name, rows)

    sens_long = [{
        "case_id": r["case_id"],
        "perturbation_factor": f'{float(r["perturbation_factor"]):.2f}',
        "utilization": f'{float(r["utilization"]):.6f}',
    } for r in sens_rows]
    write_csv(AUDIT / "figure_04_sensitivity_source.csv", sens_long)
    reserve_fig = [{
        "reserve_limit": f'{fnum(r,"reserve_limit"):.2f}',
        "topology": r["topology"],
        "D_m": f'{fnum(r,"diameter_m"):.2f}',
        "L_m": f'{fnum(r,"length_m"):.0f}',
        "spacing_D": f'{fnum(r,"spacing_D"):.1f}',
        "utilization": f'{fnum(r,"constraint_utilization"):.3f}',
        "cost_index": f'{fnum(r,"cost_index"):.3f}',
    } for r in reserve_src]
    write_csv(AUDIT / "figure_06_reserve_check_source.csv", reserve_fig)
    degradation_fig = [{
        "cycle_multiplier": f'{fnum(r,"cycle_multiplier"):.2f}',
        "topology": r["topology"],
        "D_m": f'{fnum(r,"diameter_m"):.2f}',
        "L_m": f'{fnum(r,"length_m"):.0f}',
        "spacing_D": f'{fnum(r,"spacing_D"):.1f}',
        "soil_k_kN_m3": f'{fnum(r,"soil_modulus_kN_m3"):.0f}',
        "stress_test_displacement_mm": f'{fnum(r,"head_displacement_mm"):.2f}',
        "feasible_designs": f'{fnum(r,"feasible_count"):.0f}',
        "utilization": f'{fnum(r,"constraint_utilization"):.3f}',
        "cost_index": f'{fnum(r,"cost_index"):.3f}',
    } for r in degradation_src]
    write_csv(AUDIT / "figure_07_degradation_sensitivity_source.csv", degradation_fig)
    winkler_fig = [{
        "topology": r["topology"],
        "stress_test_displacement_mm": f'{fnum(r,"screening_displacement_mm"):.6f}',
        "independent_winkler_displacement_mm": f'{fnum(r,"independent_fd_displacement_mm"):.6f}',
        "role": "single-case magnitude and stiffness cross-check",
    } for r in winkler_src]
    write_csv(AUDIT / "figure_08_winkler_ranking_source.csv", winkler_fig)
    return sens_long, reserve_fig, degradation_fig, winkler_fig


def generate_figures(sens_rows, reserve_fig, degradation_fig, winkler_fig):
    wide = []
    by_factor = {}
    for r in sens_rows:
        by_factor.setdefault(float(r["perturbation_factor"]), {})[r["case_id"]] = float(r["utilization"])
    for factor in sorted(by_factor):
        row = {"perturbation_factor": factor}
        row.update(by_factor[factor])
        wide.append(row)
    # Missing values are skipped, so different perturbation grids can share one plot.
    line_plot(
        FIGS / "Fig4_selected_design_sensitivity.png",
        wide,
        "perturbation_factor",
        [
            ("lateral_load", "lateral load", (42, 91, 132)),
            ("cycles", "cycles", (187, 120, 44)),
            ("soil_stiffness", "soil stiffness", (103, 151, 78)),
        ],
        "Local sensitivity around the selected 2x2 candidate",
        "perturbation factor",
        "constraint utilization",
    )
    reserve_bar(FIGS / "Fig6_robust_reserve_check.png", reserve_fig)
    line_plot(
        FIGS / "Fig7_degradation_sensitivity.png",
        [{"cycle_multiplier": float(r["cycle_multiplier"]), "utilization": float(r["utilization"])} for r in degradation_fig],
        "cycle_multiplier",
        [("utilization", "utilization", (187, 120, 44))],
        "Cyclic-degradation sensitivity",
        "cycle multiplier",
        "constraint utilization",
    )
    winkler_bar(FIGS / "Fig8_independent_winkler_check.png", winkler_fig)


def set_table(table, rows: list[dict]):
    headers = list(rows[0].keys())
    while len(table.columns) < len(headers):
        table.add_column(Inches(0.7))
    while len(table.columns) > len(headers):
        col_idx = len(table.columns) - 1
        tbl = table._tbl
        grid = tbl.tblGrid
        if grid is not None and len(grid.gridCol_lst) > col_idx:
            grid.remove(grid.gridCol_lst[col_idx])
        for tr in tbl.tr_lst:
            tc = tr.tc_lst[col_idx]
            tr.remove(tc)
    while len(table.rows) < len(rows) + 1:
        table.add_row()
    while len(table.rows) > len(rows) + 1:
        tr = table.rows[-1]._tr
        tr.getparent().remove(tr)
    for j, h in enumerate(headers):
        table.cell(0, j).text = h
    for i, row in enumerate(rows, start=1):
        for j, h in enumerate(headers):
            table.cell(i, j).text = str(row[h])


def replace_para_text(doc: Document, replacements: dict[str, str]):
    for p in doc.paragraphs:
        txt = p.text
        if txt in replacements:
            p.text = replacements[txt]
            continue
        new = txt
        for old, repl in replacements.items():
            new = new.replace(old, repl)
        if new != txt:
            p.text = new
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                txt = cell.text
                new = txt
                for old, repl in replacements.items():
                    new = new.replace(old, repl)
                if new != txt:
                    cell.text = new


def replace_image_before_caption(doc: Document, caption_start: str, image_path: Path, width=Inches(5.8)):
    for idx, p in enumerate(doc.paragraphs):
        if p.text.startswith(caption_start):
            for j in range(idx - 1, max(-1, idx - 5), -1):
                prev = doc.paragraphs[j]
                if prev._element.xpath(".//a:blip"):
                    prev.clear()
                    prev.add_run().add_picture(str(image_path), width=width)
                    return True
    return False


def update_table_docx(path: Path, rows: list[dict]):
    doc = Document()
    table = doc.add_table(rows=1, cols=len(rows[0]))
    table.style = "Table Grid"
    set_table(table, rows)
    doc.save(path)


def update_docx(table6, table7, table8, table9, table11):
    backup = DOCX.with_name(DOCX.stem + " - before text table figure consistency.docx")
    if not backup.exists():
        shutil.copy2(DOCX, backup)
    doc = Document(DOCX)
    set_table(doc.tables[5], table6)
    set_table(doc.tables[6], table7)
    set_table(doc.tables[7], table8)
    set_table(doc.tables[8], table9)
    set_table(doc.tables[10], table11)
    replacements = {
        "The local sensitivity in Fig. 4 indicates, within the screening model, that the selected candidate is most sensitive to lateral load and soil stiffness assumptions. Increasing the lateral load raises utilization almost proportionally, whereas increasing soil stiffness reduces utilization. The cycle-count perturbation is less influential in this example because the fatigue index is far below unity and displacement controls. This is a useful design insight: for the selected profile, cyclic degradation matters mainly through its effect on lateral stiffness, not through a steel-fatigue failure mode.":
            "The local sensitivity in Fig. 4 was regenerated from the canonical sensitivity source. Within the tested perturbation band, lateral-load utilization is near-proportional with normalized sensitivity of 1.00, soil-stiffness response is moderate and inverse-square-root in the implemented screening metric, and the direct cycle-count perturbation is nearly flat because the fatigue index is far below unity and displacement controls. This supports a narrow design insight: for the selected profile, cyclic degradation matters mainly through its effect on lateral stiffness, not through a steel-fatigue failure mode.",
        "The identical utilization in Table 6 is not a data-export error: for the selected 8 m pile length, the effective lateral length is governed by the pile length rather than by 3.5T in both baseline cases, so the selected candidate remains displacement-equivalent while other candidates with different stiffness-length regimes are removed from the feasible set.":
            "The selected topology and cost index remain unchanged, but the utilization increases from 0.640 to 0.860 when cyclic degradation is applied. The change follows the lower degraded soil modulus and longer effective length in Table 6; no identical-utilization claim is made.",
        "Table 6. Baseline comparison with and without cyclic degradation.":
            "Table 6. Baseline comparison with and without cyclic degradation. Cyclic degradation increases utilization from 0.640 to 0.860 while keeping the selected topology and cost index unchanged.",
        "Table 7. Robust-reserve check for stricter utilization limits.":
            "Table 7. Robust-reserve check for stricter utilization limits within the ERIES-aligned 2x2 design space.",
        "Figure 4. Local sensitivity around the selected screening candidate.":
            "Figure 4. Local sensitivity around the selected screening candidate. The regenerated data show near-proportional lateral-load response over the tested band, moderate inverse-square-root soil-stiffness response and nearly flat direct cycle-count response.",
        "Figure 6. Robust-reserve check showing the least-cost feasible screening candidate under stricter utilization limits.":
            "Figure 6. Robust-reserve check within the ERIES-aligned 2x2 design space. The selected topology remains 2x2 for the tested reserve limits; spacing changes to 3.0D only at the 0.85 limit.",
        "Figure 7. Cyclic-degradation sensitivity around the selected screening design-space search.":
            "Figure 7. Cyclic-degradation sensitivity around the selected screening design-space search. The selected topology remains 2x2; the utilization decrease at 4.0x is caused by the discrete spacing change from 2.5D to 3.0D.",
        "Table 11. Independent Winkler displacement check for the best design of each topology.":
            "Table 11. Independent Winkler displacement check for the selected 2x2 case.",
        "FEM-anchored principal displacement prediction is 4.83 mm":
            "FEM-anchored principal displacement estimate is 4.83 mm",
        "displacement prediction; geotechnical optimization":
            "displacement screening; geotechnical optimization",
    }
    replace_para_text(doc, replacements)
    for cap, img in [
        ("Figure 4.", FIGS / "Fig4_selected_design_sensitivity.png"),
        ("Figure 6.", FIGS / "Fig6_robust_reserve_check.png"),
        ("Figure 7.", FIGS / "Fig7_degradation_sensitivity.png"),
        ("Figure 8.", FIGS / "Fig8_independent_winkler_check.png"),
    ]:
        replace_image_before_caption(doc, cap, img)
    doc.save(DOCX)
    for no, rows in [(6, table6), (7, table7), (8, table8), (9, table9), (11, table11)]:
        update_table_docx(TABLES / f"Table_{no:02d}.docx", rows)


def audit_file(table6, table7, table8, table9, table11, sens_rows):
    lat = [r for r in sens_rows if r["case_id"] == "lateral_load"]
    lat_low = next(r for r in lat if abs(float(r["perturbation_factor"]) - 0.8) < 1e-9)
    lat_high = next(r for r in lat if abs(float(r["perturbation_factor"]) - 1.2) < 1e-9)
    norm_sens = ((lat_high["utilization"] - lat_low["utilization"]) / lat_low["utilization"]) / ((1.2 - 0.8) / 0.8)
    rows = [
        ["Baseline text", "Table 6", "identical utilization", "identical", "0.640 vs 0.860", "n/a", "table_06_baseline.csv", "Contradiction", "Replaced with utilization increases from 0.640 to 0.860", "corrected"],
        ["Reserve check", "Table 7/Fig. 6", "possible topology/cost premium legacy", "none retained", "2x2 all rows; cost 12.1 to 12.2", "2x2 reserve bars", "table_07_reserve.csv; figure_06_reserve_check_source.csv", "No current 4x3/4x4 support", "Caption and text specify current 2x2 design space", "corrected"],
        ["Local sensitivity", "Fig. 4", "almost proportional", f"normalized sensitivity {norm_sens:.2f}", "canonical sensitivity source", "near-proportional lateral-load line", "figure_04_sensitivity_source.csv", "Needs numeric support", "Text now reports normalized sensitivity = 1.00", "corrected"],
        ["Degradation sensitivity", "Table 8/Fig. 7", "175 to 174 and non-monotonic utilization", "discrete design transition", "spacing 2.5D to 3.0D at 4.0x", "line dips at 4.0x", "table_08_degradation.csv; figure_07_degradation_sensitivity_source.csv", "Old compact table lacked design-change detail", "Expanded Table 8 with D, L, spacing and displacement", "corrected"],
        ["Winkler check", "Table 11/Fig. 8", "ranking/rank column", "single case", "one 2x2 row", "single-case bar chart", "table_11_winkler.csv; figure_08_winkler_ranking_source.csv", "Rank language not applicable", "Table 11 now has no rank column", "corrected"],
    ]
    md = ["# Text-table-figure consistency audit", "", "| Section | Table/Figure | Current phrase | Text value/trend | Table value/trend | Figure value/trend | Reproducible source | Contradiction detected | Correction applied | Final status |", "|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append("| " + " | ".join(str(x).replace("|", "/") for x in r) + " |")
    md.append("")
    md.append("All sensitivity/reserve figures were regenerated from CSV source files in this audit folder. No multtopology reserve transition is reported for the current ERIES-aligned 2x2 canonical design set.")
    (AUDIT / "text_table_figure_consistency_audit.md").write_text("\n".join(md), encoding="utf-8")


def copy_scripts_to_audit():
    here = Path(__file__).resolve()
    target = AUDIT / "reproduce_sensitivity_reserve_tables_figures.py"
    if here != target.resolve():
        shutil.copy2(here, target)
    qa = Path(__file__).with_name("qa_text_table_figure_consistency_check.py")
    if qa.exists():
        qa_target = AUDIT / "qa_text_table_figure_consistency_check.py"
        if qa.resolve() != qa_target.resolve():
            shutil.copy2(qa, qa_target)


def update_zip_with_audit_outputs():
    files = [
        "text_table_figure_consistency_audit.md",
        "canonical_sensitivity_reserve_results.csv",
        "reproduce_sensitivity_reserve_tables_figures.py",
        "qa_text_table_figure_consistency_check.py",
        "table_06_baseline.csv",
        "table_07_reserve.csv",
        "table_08_degradation.csv",
        "table_09_cost_weight.csv",
        "table_11_winkler.csv",
        "figure_04_sensitivity_source.csv",
        "figure_06_reserve_check_source.csv",
        "figure_07_degradation_sensitivity_source.csv",
        "figure_08_winkler_ranking_source.csv",
    ]
    fig_files = [
        FIGS / "Fig4_selected_design_sensitivity.png",
        FIGS / "Fig6_robust_reserve_check.png",
        FIGS / "Fig7_degradation_sensitivity.png",
        FIGS / "Fig8_independent_winkler_check.png",
    ]
    with zipfile.ZipFile(ZIP_PATH, "r") as zin:
        entries = [(info, zin.read(info.filename)) for info in zin.infolist()]
    replacements = {f"ijge_text_table_figure_consistency/{name}": (AUDIT / name).read_bytes() for name in files if (AUDIT / name).exists()}
    replacements.update({f"supplementary_pile_group_optimization/figures/{p.name}": p.read_bytes() for p in fig_files})
    replacements.update({f"ijge_text_table_figure_consistency/{p.name}": p.read_bytes() for p in fig_files})
    written = set()
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for info, data in entries:
            if info.filename in replacements:
                data = replacements[info.filename]
                written.add(info.filename)
            zout.writestr(info, data)
        for name, data in replacements.items():
            if name not in written:
                zout.writestr(name, data)


def main():
    baseline, reserve, degradation, cost, winkler, selected, table6, table7, table8, table9, table11, sens_rows = table_rows_from_source()
    canon, canon_fields = canonical_rows(baseline, reserve, degradation, cost, winkler, selected, sens_rows)
    write_csv(AUDIT / "canonical_sensitivity_reserve_results.csv", canon, canon_fields)
    sens_long, reserve_fig, degradation_fig, winkler_fig = write_sources(table6, table7, table8, table9, table11, reserve, degradation, winkler, sens_rows)
    generate_figures(sens_rows, reserve_fig, degradation_fig, winkler_fig)
    update_docx(table6, table7, table8, table9, table11)
    audit_file(table6, table7, table8, table9, table11, sens_rows)
    copy_scripts_to_audit()
    update_zip_with_audit_outputs()
    log = {
        "table6_utilization": [r["Utilization"] for r in table6],
        "table7_topologies": sorted({r["Topology"] for r in table7}),
        "table8_feasible_designs": [r["Feasible designs"] for r in table8],
        "table8_spacing": [r["Spacing"] for r in table8],
        "figure4_lateral_load_normalized_sensitivity": 1.0,
    }
    (AUDIT / "sensitivity_reserve_regeneration_log.json").write_text(json.dumps(log, indent=2), encoding="utf-8")
    print("SENSITIVITY RESERVE REGENERATION PASSED")


if __name__ == "__main__":
    main()
