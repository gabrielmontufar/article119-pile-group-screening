from __future__ import annotations
import re, sys
from pathlib import Path
from docx import Document
BASE=Path(__file__).resolve().parent
DOCX=BASE.parents[0]/"01 Manuscript"/"Cyclic Lateral Pile Group - IJGE manuscript.docx"
doc=Document(DOCX)
text="\n".join(p.text for p in doc.paragraphs)+"\n"+"\n".join("\n".join(" | ".join(c.text for c in r.cells) for r in t.rows) for t in doc.tables)
errors=[]
bad=[
    r"Rollins validation",
    r"validated against Rollins",
    r"calibrated against Rollins",
    r"supports the selected demand",
    r"demonstrates adequacy",
    r"validates?[^.\n]{0,80}(4\.83|25\.81)",
    r"Rollins[^.\n]{0,80}\\bis\\b[^.\n]{0,20}profile-matched validation",
    r"external p-y benchmark",
]
for pat in bad:
    if re.search(pat,text,re.I): errors.append("bad Rollins claim: "+pat)
for m in re.finditer(r"conservative", text, re.I):
    ctx=text[max(0,m.start()-100):m.end()+140].lower()
    if "rollins" in ctx and "not evidence" not in ctx:
        errors.append("conservative near Rollins without limitation")
if "average demand scale" not in text or "not p_req(z)" not in text:
    errors.append("missing average demand scale / not p_req(z) warning")
if "Limited Rollins liquefied-sand p-y scale comparison" not in text:
    errors.append("missing limited Table/Figure Rollins caption")
if "not a profile-matched validation dataset" not in text:
    errors.append("missing profile-mismatch declaration")
if "component-level severe p-y scale comparison only; not profile-matched validation" not in text:
    errors.append("missing hierarchy maximum defensible claim")
for f in ["rollins_benchmark_audit.md","reproduce_rollins_benchmark_check.py","rollins_benchmark_trace.csv"]:
    if not (BASE/f).exists(): errors.append("missing "+f)
if errors:
    print("ROLLINS BENCHMARK QA FAILED")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("ROLLINS BENCHMARK QA PASSED")
