
from pathlib import Path
from docx import Document

BASE = Path(r'C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515')
DOCX = BASE / '01 Manuscript' / 'Cyclic Lateral Pile Group - IJGE manuscript.docx'

doc = Document(str(DOCX))
text = '\n'.join(p.text for p in doc.paragraphs)
required = [
    '04 Supplementary/eries_aligned_2x2_screening_capsule',
    '04 Supplementary/blind_validation',
    '06 Journal instructions and audit/blind_validation',
    'Online Resource 1 contains the reproducibility package',
    'Generative artificial intelligence tools were used to support language editing, organization and formatting.',
    'no existing repository URL was found in the local article package',
]
missing = [s for s in required if s not in text]
if missing:
    raise SystemExit('Missing required statement text: ' + '; '.join(missing))
if len(doc.inline_shapes) < 7:
    raise SystemExit(f'Expected at least 7 embedded main-manuscript figure images, found {len(doc.inline_shapes)}')
print('DATA_AI_SUPPLEMENTARY_AND_FIGURES_QA_PASSED')
print(f'inline_shapes={len(doc.inline_shapes)}')
