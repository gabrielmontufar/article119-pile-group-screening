# README_calcix_checks

This folder contains the CalculiX solver-level checks used in the IJGE manuscript.

## Contents
- `py_fem_model.*`: B31 beam piles with nonlinear SPRINGA p-y springs.
- `continuum_static.*`: C3D8 bonded continuum model with static layer stiffness.
- `continuum_degraded.*`: C3D8 bonded continuum model with degraded layer stiffness.
- `generate_py_fem_model.py` and `generate_3d_continuum_models.py`: generator scripts from the reproducibility package.
- `reproduce_calcix_checks.py`: parser/QA script that extracts top displacements from `.dat` files and writes `calcix_checks_trace.csv`.

## Reproduction commands
If CalculiX is installed and `ccx` is on PATH:

```bash
ccx py_fem_model
ccx continuum_static
ccx continuum_degraded
python reproduce_calcix_checks.py
```

On this Windows workstation the original generation used CalculiX 2.23.0. The manuscript uses the already included `.dat` and `.frd` files so a reviewer can inspect the results even without rerunning the solver.

## Claim boundary
The p-y FEM is a solver-level independent implementation of the p-y idealization. The 3D continuum cases impose a bonded shared-node no-slip/no-gap interface and are therefore lower-bound stiffness checks, not full nonlinear field validation.
