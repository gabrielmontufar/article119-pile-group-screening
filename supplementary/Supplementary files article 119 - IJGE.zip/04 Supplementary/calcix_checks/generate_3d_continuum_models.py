from __future__ import annotations

import csv
import math
import os
import re
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

import run_pile_group_optimization as base


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FIGS = ROOT / "figures"
CALC = ROOT / "calculix_3d_continuum"
CALC.mkdir(exist_ok=True)


def font(size: int, bold: bool = False):
    candidates = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\calibri.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            pass
    return ImageFont.load_default()


def ccx_path() -> Path:
    env_path = os.environ.get("CCX_EXE")
    if env_path and Path(env_path).exists():
        return Path(env_path)
    local = Path(
        r"C:\Users\gjm31\Documents\Codex\2026-05-14\cyclic-lateral-pile-group-optimization-with"
        r"\tools\calculix\CalculiX-2.23.0-win-x64\bin\ccx.exe"
    )
    if local.exists():
        return local
    raise FileNotFoundError("Set CCX_EXE to the CalculiX ccx.exe executable.")


def layer_modulus(depth: float, degraded: bool) -> float:
    layer = base.layer_at_depth(depth)
    reduction = (1.0 + base.N_CYCLES / 10000.0) ** (-layer.degradation_alpha) if degraded else 1.0
    # Independent continuum approximation: convert the tabulated subgrade-modulus scale
    # to a small-strain continuum Young modulus without p-y springs or group efficiency.
    return 3.0 * layer.k_static_mn_m3 * 1000.0 * reduction


def is_pile_cell(xc: float, yc: float, centers: list[tuple[float, float]], diameter: float) -> bool:
    radius = diameter / 2.0
    return any(abs(xc - x0) <= radius and abs(yc - y0) <= radius for x0, y0 in centers)


def write_inp(selected: dict[str, str], case: str, degraded: bool) -> tuple[Path, dict[str, float | int | str]]:
    rows = int(selected["rows"])
    cols = int(selected["cols"])
    diameter = float(selected["diameter_m"])
    spacing = float(selected["spacing_m"])
    length = float(selected["length_m"])
    half_width = spacing * 2.4
    centers = []
    for r in range(rows):
        for c in range(cols):
            x = (r - (rows - 1) / 2.0) * spacing
            y = (c - (cols - 1) / 2.0) * spacing
            centers.append((x, y))

    coords_xy = {round(-half_width, 6), round(half_width, 6)}
    # Put element faces on pile boundaries and add intermediate soil lines.
    for x0, y0 in centers:
        for value in [x0 - diameter / 2, x0 + diameter / 2, y0 - diameter / 2, y0 + diameter / 2]:
            coords_xy.add(round(value, 6))
    step = diameter
    v = -half_width
    while v <= half_width + 1e-9:
        coords_xy.add(round(v, 6))
        v += step
    xy = sorted(coords_xy)
    z = [round(-length + i * 1.0, 6) for i in range(int(length) + 1)]

    node_id = 1
    node_map: dict[tuple[int, int, int], int] = {}
    lines = [
        "** CalculiX 3D continuum validation capsule for article 119",
        "** Units: kN, m. C3D8 soil block with concrete pile inclusions; no p-y springs and no group-efficiency factor.",
        "*NODE,NSET=NALL",
    ]
    for k, zz in enumerate(z):
        for j, yy in enumerate(xy):
            for i, xx in enumerate(xy):
                node_map[(i, j, k)] = node_id
                lines.append(f"{node_id}, {xx:.6f}, {yy:.6f}, {zz:.6f}")
                node_id += 1

    elem_id = 1
    soil_sets: dict[str, list[int]] = {"SOIL1": [], "SOIL2": [], "SOIL3": []}
    pile_elems: list[int] = []
    top_pile_nodes: set[int] = set()
    bottom_nodes: set[int] = set()
    xminus: set[int] = set()
    xplus: set[int] = set()
    yminus: set[int] = set()
    yplus: set[int] = set()
    lines.append("*ELEMENT,TYPE=C3D8")
    for k in range(len(z) - 1):
        for j in range(len(xy) - 1):
            for i in range(len(xy) - 1):
                n1 = node_map[(i, j, k)]
                n2 = node_map[(i + 1, j, k)]
                n3 = node_map[(i + 1, j + 1, k)]
                n4 = node_map[(i, j + 1, k)]
                n5 = node_map[(i, j, k + 1)]
                n6 = node_map[(i + 1, j, k + 1)]
                n7 = node_map[(i + 1, j + 1, k + 1)]
                n8 = node_map[(i, j + 1, k + 1)]
                lines.append(f"{elem_id}, {n1}, {n2}, {n3}, {n4}, {n5}, {n6}, {n7}, {n8}")
                xc = 0.5 * (xy[i] + xy[i + 1])
                yc = 0.5 * (xy[j] + xy[j + 1])
                depth = -0.5 * (z[k] + z[k + 1])
                if is_pile_cell(xc, yc, centers, diameter):
                    pile_elems.append(elem_id)
                    if k == len(z) - 2:
                        top_pile_nodes.update([n5, n6, n7, n8])
                else:
                    if depth < 4.0:
                        soil_sets["SOIL1"].append(elem_id)
                    elif depth < 11.0:
                        soil_sets["SOIL2"].append(elem_id)
                    else:
                        soil_sets["SOIL3"].append(elem_id)
                elem_id += 1

    for (i, j, k), nid in node_map.items():
        if k == 0:
            bottom_nodes.add(nid)
        if i == 0:
            xminus.add(nid)
        if i == len(xy) - 1:
            xplus.add(nid)
        if j == 0:
            yminus.add(nid)
        if j == len(xy) - 1:
            yplus.add(nid)

    def emit_set(name: str, values: list[int] | set[int], kind: str) -> None:
        vals = sorted(values)
        lines.append(f"*{kind}, {kind}={name}")
        for start in range(0, len(vals), 12):
            lines.append(",".join(str(v) for v in vals[start:start + 12]))

    emit_set("PILES", pile_elems, "ELSET")
    for name, elems in soil_sets.items():
        emit_set(name, elems, "ELSET")
    emit_set("TOPPILE", top_pile_nodes, "NSET")
    emit_set("BOTTOM", bottom_nodes, "NSET")
    emit_set("XMINUS", xminus, "NSET")
    emit_set("XPLUS", xplus, "NSET")
    emit_set("YMINUS", yminus, "NSET")
    emit_set("YPLUS", yplus, "NSET")

    lines.extend([
        "*MATERIAL,NAME=CONCRETE",
        "*ELASTIC",
        f"{base.E_CONCRETE:.6f}, 0.20",
        "*SOLID SECTION,ELSET=PILES,MATERIAL=CONCRETE",
    ])
    for idx, layer_name in enumerate(["SOIL1", "SOIL2", "SOIL3"], start=1):
        mid_depth = [2.0, 7.5, 12.0][idx - 1]
        lines.extend([
            f"*MATERIAL,NAME={layer_name}_MAT",
            "*ELASTIC",
            f"{layer_modulus(mid_depth, degraded):.6f}, 0.35",
            f"*SOLID SECTION,ELSET={layer_name},MATERIAL={layer_name}_MAT",
        ])

    total_load = base.H_SERVICE
    load_per_node = total_load / len(top_pile_nodes)
    lines.extend([
        "*BOUNDARY",
        "BOTTOM, 1, 3",
        "XMINUS, 1, 1",
        "XPLUS, 1, 1",
        "YMINUS, 2, 2",
        "YPLUS, 2, 2",
        "*STEP",
        "*STATIC",
        "1.0, 1.0",
        "*CLOAD",
    ])
    for node in sorted(top_pile_nodes):
        lines.append(f"{node}, 1, {load_per_node:.8f}")
    lines.extend([
        "*NODE PRINT,NSET=TOPPILE",
        "U",
        "*NODE FILE,NSET=TOPPILE",
        "U",
        "*END STEP",
    ])
    inp = CALC / f"{case}.inp"
    inp.write_text("\n".join(lines) + "\n", encoding="ascii")
    return inp, {
        "case": case,
        "degraded_soil": str(degraded),
        "n_nodes": node_id - 1,
        "n_elements": elem_id - 1,
        "n_pile_elements": len(pile_elems),
        "n_soil_elements": sum(len(v) for v in soil_sets.values()),
        "n_loaded_top_nodes": len(top_pile_nodes),
        "load_per_top_node_kN": load_per_node,
        "soil_block_half_width_m": half_width,
    }


def run_ccx(inp: Path) -> None:
    proc = subprocess.run(
        [str(ccx_path()), inp.with_suffix("").name],
        cwd=str(inp.parent),
        capture_output=True,
        text=True,
        timeout=180,
    )
    inp.with_suffix(".stdout.txt").write_text(proc.stdout, encoding="utf-8", errors="replace")
    inp.with_suffix(".stderr.txt").write_text(proc.stderr, encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout)


def parse_last_top_displacements(dat: Path) -> list[float]:
    text = dat.read_text(errors="replace")
    blocks: list[list[float]] = []
    current: list[float] = []
    in_block = False
    for line in text.splitlines():
        if "displacements (vx,vy,vz)" in line:
            if current:
                blocks.append(current)
            current = []
            in_block = True
            continue
        parts = line.split()
        if in_block and len(parts) >= 4 and parts[0].isdigit():
            try:
                current.append(float(parts[1]))
            except ValueError:
                pass
    if current:
        blocks.append(current)
    if not blocks:
        raise ValueError(f"No displacement block found in {dat}")
    return blocks[-1]


def save_figure(rows: list[dict[str, str]]) -> None:
    img = Image.new("RGB", (1700, 950), "white")
    d = ImageDraw.Draw(img)
    d.text((70, 55), "CalculiX 3D continuum pile-soil-group FEM check", font=font(34, True), fill=(0, 0, 0))
    labels = ["Screening", "Beam-spring\nFEM", "3D continuum\nstatic soil", "3D continuum\ndegraded soil"]
    vals = [
        float(rows[0]["screening_head_displacement_mm"]),
        float(rows[0]["beam_spring_calculix_displacement_mm"]),
        float(rows[0]["mean_top_displacement_mm"]),
        float(rows[1]["mean_top_displacement_mm"]),
    ]
    maxv = max(vals) * 1.25
    x0, y0, x1, y1 = 170, 170, 1550, 710
    d.rectangle((x0, y0, x1, y1), outline=(0, 0, 0), width=2)
    for tick in [0, 10, 20, 30]:
        y = y1 - int(tick / maxv * (y1 - y0))
        d.line((x0 - 8, y, x1, y), fill=(215, 215, 215), width=1)
        d.text((95, y - 12), str(tick), font=font(22), fill=(0, 0, 0))
    colors = [(42, 91, 132), (74, 128, 96), (187, 120, 44), (150, 70, 80)]
    for i, (label, val, color) in enumerate(zip(labels, vals, colors)):
        cx = x0 + 110 + i * 330
        bh = int(val / maxv * (y1 - y0))
        d.rectangle((cx, y1 - bh, cx + 145, y1), fill=color, outline=(0, 0, 0))
        d.text((cx - 20, y1 + 30), label, font=font(22), fill=(0, 0, 0))
        d.text((cx - 2, y1 - bh - 35), f"{val:.1f} mm", font=font(23, True), fill=(0, 0, 0))
    d.text((55, 420), "head displacement (mm)", font=font(24), fill=(0, 0, 0))
    d.text((70, 805), "3D continuum model uses C3D8 soil and concrete pile inclusions; no p-y springs and no group-efficiency factor.", font=font(24), fill=(0, 0, 0))
    img.save(FIGS / "Fig13_calculix_3d_continuum_check.png")


def main() -> None:
    selected = next(csv.DictReader((DATA / "selected_design.csv").open(encoding="utf-8")))
    beam = next(csv.DictReader((DATA / "calculix_py_fem_check.csv").open(encoding="utf-8")))
    rows: list[dict[str, str]] = []
    for case, degraded in [("selected_2x2_3d_continuum_static", False), ("selected_2x2_3d_continuum_degraded", True)]:
        inp, meta = write_inp(selected, case, degraded)
        run_ccx(inp)
        values = parse_last_top_displacements(inp.with_suffix(".dat"))
        row = {
            **{k: str(v) for k, v in meta.items()},
            "solver": "CalculiX 2.23.0",
            "model": "C3D8 3D continuum soil block with concrete pile inclusions; no p-y springs; no group-efficiency factor",
            "screening_head_displacement_mm": selected["head_displacement_mm"],
            "beam_spring_calculix_displacement_mm": beam["calculix_mean_top_displacement_mm"],
            "mean_top_displacement_mm": str(1000.0 * sum(values) / len(values)),
            "max_top_displacement_mm": str(1000.0 * max(values)),
            "ratio_to_screening": str((1000.0 * sum(values) / len(values)) / float(selected["head_displacement_mm"])),
            "input_file": str(inp.relative_to(ROOT)),
        }
        rows.append(row)
    with (DATA / "calculix_3d_continuum_check.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    save_figure(rows)
    for row in rows:
        print(row)


if __name__ == "__main__":
    main()
