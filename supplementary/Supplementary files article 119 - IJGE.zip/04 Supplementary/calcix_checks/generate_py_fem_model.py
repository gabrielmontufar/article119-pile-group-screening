from __future__ import annotations

import csv
import math
import os
import re
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

import run_pile_group_optimization as base


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FIGS = ROOT / "figures"
CALC = ROOT / "calculix_fem"
CALC.mkdir(exist_ok=True)


def font(size: int, bold: bool = False):
    candidates = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\calibri.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            pass
    return ImageFont.load_default()


def ccx_path() -> Path:
    env_path = os.environ.get("CCX_EXE")
    if env_path and Path(env_path).exists():
        return Path(env_path)
    local = Path(
        r"C:\Users\gjm31\Documents\Codex\2026-05-14\cyclic-lateral-pile-group-optimization-with"
        r"\tools\calculix\CalculiX-2.23.0-win-x64\bin\ccx.exe"
    )
    if local.exists():
        return local
    raise FileNotFoundError(
        "CalculiX solver not found. Set CCX_EXE to ccx.exe or place CalculiX 2.23 under the local tools folder."
    )


def layer_degraded_values(z: float) -> tuple[float, float]:
    layer = base.layer_at_depth(z)
    degradation = (1.0 + base.N_CYCLES / 10000.0) ** (-layer.degradation_alpha)
    return layer.k_static_mn_m3 * 1000.0 * degradation, layer.pult_kpa


def write_inp(selected: dict[str, str], path: Path) -> dict[str, float]:
    rows = int(selected["rows"])
    cols = int(selected["cols"])
    n_piles = rows * cols
    diameter = float(selected["diameter_m"])
    length = float(selected["length_m"])
    spacing = float(selected["spacing_m"])
    eta = float(selected["group_efficiency"])
    dz = 0.5
    nseg = int(round(length / dz))
    area = math.pi * diameter**2 / 4.0
    inertia = math.pi * diameter**4 / 64.0
    square_side = (12.0 * inertia) ** 0.25
    # Rectangular beam section chosen to preserve bending inertia about the loaded axis.
    pile_nodes: list[list[int]] = []
    ground_nodes: list[int] = []
    spring_elsets: list[tuple[str, float, float]] = []
    node_id = 1
    elem_id = 1
    lines: list[str] = [
        "** CalculiX p-y FEM validation capsule for article 119",
        "** Units: kN, m. Piles are B31 beams; soil is represented by nonlinear SPRINGA p-y elements.",
        "*NODE, NSET=NALL",
    ]
    for r in range(rows):
        for c in range(cols):
            y = (c - (cols - 1) / 2.0) * spacing
            x = (r - (rows - 1) / 2.0) * spacing
            nodes = []
            for j in range(nseg + 1):
                z = -j * dz
                lines.append(f"{node_id}, {x:.6f}, {y:.6f}, {z:.6f}")
                nodes.append(node_id)
                node_id += 1
            pile_nodes.append(nodes)
            for j in range(1, nseg + 1):
                z = -j * dz
                lines.append(f"{node_id}, {x - 1.0:.6f}, {y:.6f}, {z:.6f}")
                ground_nodes.append(node_id)
                node_id += 1
    top_nodes = [nodes[0] for nodes in pile_nodes]
    bottom_nodes = [nodes[-1] for nodes in pile_nodes]
    lines.append("*NSET,NSET=TOP")
    lines.append(",".join(str(n) for n in top_nodes))
    lines.append("*NSET,NSET=BOTTOM")
    lines.append(",".join(str(n) for n in bottom_nodes))
    lines.append("*NSET,NSET=GROUND")
    for i in range(0, len(ground_nodes), 12):
        lines.append(",".join(str(n) for n in ground_nodes[i:i + 12]))

    lines.append("*ELEMENT,TYPE=B31,ELSET=PILES")
    spring_defs: list[tuple[int, int, int, str]] = []
    for nodes in pile_nodes:
        for j in range(nseg):
            lines.append(f"{elem_id}, {nodes[j]}, {nodes[j + 1]}")
            elem_id += 1
    lines.append("*MATERIAL,NAME=CONCRETE_EQ")
    lines.append("*ELASTIC")
    lines.append(f"{base.E_CONCRETE:.6f}, 0.20")
    lines.append("*BEAM SECTION,ELSET=PILES,MATERIAL=CONCRETE_EQ,SECTION=RECT")
    lines.append(f"{square_side:.8f}, {square_side:.8f}")
    lines.append("1., 0., 0.")

    ground_index = 0
    for pile_index, nodes in enumerate(pile_nodes):
        for j in range(1, nseg + 1):
            depth = j * dz
            pile_node = nodes[j]
            ground_node = ground_nodes[ground_index]
            ground_index += 1
            elset = f"PY{pile_index + 1}_{j}"
            lines.append(f"*ELEMENT,TYPE=SPRINGA,ELSET={elset}")
            lines.append(f"{elem_id}, {ground_node}, {pile_node}")
            spring_defs.append((elem_id, ground_node, pile_node, elset))
            k_soil, pult = layer_degraded_values(depth)
            k_node = eta * k_soil * diameter * dz
            pult_node = eta * pult * diameter * dz
            spring_elsets.append((elset, k_node, pult_node))
            elem_id += 1

    for elset, k_node, pult_node in spring_elsets:
        y50 = max(pult_node / max(k_node, 1e-9), 1e-6)
        curve = [
            (0.0, 0.0),
            (0.25 * pult_node, 0.25 * y50),
            (0.50 * pult_node, 0.60 * y50),
            (0.80 * pult_node, 1.50 * y50),
            (1.00 * pult_node, 4.00 * y50),
        ]
        lines.append(f"*SPRING,ELSET={elset},NONLINEAR")
        for force, disp in curve:
            lines.append(f"{force:.8f}, {disp:.8f}")

    lines.extend([
        "*BOUNDARY",
        "BOTTOM, 1, 6",
        "GROUND, 1, 3",
        "*STEP,NLGEOM",
        "*STATIC",
        "0.1, 1.0, 1e-05, 0.1",
        "*CLOAD",
    ])
    load_per_top_node = base.H_SERVICE / n_piles
    for node in top_nodes:
        lines.append(f"{node}, 1, {load_per_top_node:.8f}")
    lines.extend([
        "*NODE PRINT,NSET=TOP",
        "U",
        "*NODE FILE,NSET=TOP",
        "U",
        "*END STEP",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="ascii")
    return {
        "n_piles": n_piles,
        "n_beam_elements": n_piles * nseg,
        "n_py_springs": len(spring_defs),
        "dz_m": dz,
        "rectangular_section_side_m": square_side,
        "bending_inertia_m4": inertia,
        "load_per_pile_kN": load_per_top_node,
    }


def run_ccx(inp: Path) -> tuple[str, str]:
    solver = ccx_path()
    job = inp.with_suffix("")
    proc = subprocess.run(
        [str(solver), job.name],
        cwd=str(inp.parent),
        capture_output=True,
        text=True,
        timeout=120,
    )
    return proc.stdout, proc.stderr


def parse_top_displacements(dat: Path) -> list[tuple[int, float]]:
    text = dat.read_text(errors="replace")
    blocks: list[list[tuple[int, float]]] = []
    current: list[tuple[int, float]] = []
    in_disp = False
    for line in text.splitlines():
        if "displacements (vx,vy,vz)" in line:
            if current:
                blocks.append(current)
            current = []
            in_disp = True
            continue
        if in_disp and "INCREMENT" in line and current:
            blocks.append(current)
            current = []
            in_disp = False
        parts = line.split()
        if in_disp and len(parts) >= 4 and parts[0].isdigit():
            try:
                current.append((int(parts[0]), float(parts[1])))
            except ValueError:
                continue
    if current:
        blocks.append(current)
    if not blocks:
        raise ValueError(f"No top-node displacement values found in {dat}")
    return blocks[-1]


def save_figure(row: dict[str, str]) -> None:
    img = Image.new("RGB", (1600, 900), "white")
    d = ImageDraw.Draw(img)
    title = "CalculiX nonlinear p-y FEM check for selected 2x2 pile group"
    d.text((70, 55), title, font=font(34, True), fill=(0, 0, 0))
    labels = ["Screening", "Independent\nWinkler", "CalculiX\np-y FEM"]
    vals = [
        float(row["screening_head_displacement_mm"]),
        float(row["independent_winkler_head_displacement_mm"]),
        float(row["calculix_mean_top_displacement_mm"]),
    ]
    maxv = max(vals) * 1.25
    x0, y0, x1, y1 = 180, 170, 1450, 690
    d.rectangle((x0, y0, x1, y1), outline=(0, 0, 0), width=2)
    for tick in [0, 20, 40, 60, 80]:
        if tick > maxv:
            continue
        y = y1 - int(tick / maxv * (y1 - y0))
        d.line((x0 - 8, y, x1, y), fill=(210, 210, 210), width=1)
        d.text((95, y - 14), str(tick), font=font(22), fill=(0, 0, 0))
    colors = [(42, 91, 132), (187, 120, 44), (74, 128, 96)]
    for i, (label, value, color) in enumerate(zip(labels, vals, colors)):
        cx = x0 + 170 + i * 390
        bar_h = int(value / maxv * (y1 - y0))
        d.rectangle((cx, y1 - bar_h, cx + 150, y1), fill=color, outline=(0, 0, 0))
        d.text((cx - 25, y1 + 30), label, font=font(24), fill=(0, 0, 0))
        d.text((cx - 5, y1 - bar_h - 35), f"{value:.1f} mm", font=font(24, True), fill=(0, 0, 0))
    d.text((55, 410), "head displacement (mm)", font=font(24), fill=(0, 0, 0))
    note = (
        "CalculiX model: B31 beam piles + nonlinear SPRINGA p-y springs; "
        "soil profile and group-efficiency factor match the screening case."
    )
    d.text((70, 770), note, font=font(24), fill=(0, 0, 0))
    FIGS.mkdir(exist_ok=True)
    img.save(FIGS / "Fig12_calculix_py_fem_check.png")


def main() -> None:
    selected = next(csv.DictReader((DATA / "selected_design.csv").open(encoding="utf-8")))
    independent = next(r for r in csv.DictReader((DATA / "independent_winkler_check.csv").open(encoding="utf-8")) if r["topology"] == selected["topology"])
    inp = CALC / "selected_2x2_py_fem.inp"
    metadata = write_inp(selected, inp)
    stdout, stderr = run_ccx(inp)
    (CALC / "selected_2x2_py_fem.stdout.txt").write_text(stdout, encoding="utf-8", errors="replace")
    (CALC / "selected_2x2_py_fem.stderr.txt").write_text(stderr, encoding="utf-8", errors="replace")
    dat = CALC / "selected_2x2_py_fem.dat"
    displacements = parse_top_displacements(dat)
    mean_disp_m = sum(u for _, u in displacements) / len(displacements)
    max_disp_m = max(u for _, u in displacements)
    screening_mm = float(selected["head_displacement_mm"])
    winkler_mm = float(independent["independent_fd_displacement_mm"])
    row = {
        "solver": "CalculiX 2.23.0",
        "model": "B31 beam piles with nonlinear SPRINGA p-y soil springs",
        "topology": selected["topology"],
        "n_piles": metadata["n_piles"],
        "n_beam_elements": metadata["n_beam_elements"],
        "n_py_springs": metadata["n_py_springs"],
        "spring_spacing_m": metadata["dz_m"],
        "load_per_pile_kN": metadata["load_per_pile_kN"],
        "screening_head_displacement_mm": screening_mm,
        "independent_winkler_head_displacement_mm": winkler_mm,
        "calculix_mean_top_displacement_mm": mean_disp_m * 1000.0,
        "calculix_max_top_displacement_mm": max_disp_m * 1000.0,
        "calculix_to_screening_ratio": (mean_disp_m * 1000.0) / screening_mm,
        "calculix_to_winkler_ratio": (mean_disp_m * 1000.0) / winkler_mm,
        "status": "ccx completed; top-node displacement extracted from .dat",
        "input_file": str(inp.relative_to(ROOT)),
    }
    with (DATA / "calculix_py_fem_check.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(row.keys()))
        writer.writeheader()
        writer.writerow(row)
    save_figure({k: str(v) for k, v in row.items()})
    print(row)


if __name__ == "__main__":
    main()
