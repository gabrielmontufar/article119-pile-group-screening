from __future__ import annotations
import csv, re, sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
if (BASE / "py_fem_model.inp").exists():
    CALC = BASE
elif (BASE.parent / "calcix_checks" / "py_fem_model.inp").exists():
    CALC = BASE.parent / "calcix_checks"
else:
    CALC = BASE.parent / "04 Supplementary" / "calcix_checks"
STRESS=25.81380308925839
PRED=4.83
def count_inp(path):
    n_nodes=n_elems=0; types={}; mode=None; etype=""
    for line in path.read_text(errors="ignore").splitlines():
        s=line.strip()
        if not s or s.startswith("**"): continue
        if s.startswith("*"):
            mode=None
            if s.upper().startswith("*NODE"): mode="node"
            elif s.upper().startswith("*ELEMENT"):
                mode="elem"; m=re.search(r"TYPE=([^,\s]+)",s,re.I); etype=m.group(1).upper() if m else "UNKNOWN"
            continue
        if mode=="node" and re.match(r"^\d+\s*,",s): n_nodes+=1
        elif mode=="elem" and re.match(r"^\d+\s*,",s):
            n_elems+=1; types[etype]=types.get(etype,0)+1
    return n_nodes,n_elems,types
def parse_dat(path,set_name):
    blocks=[]; cur=[]; on=False
    for line in path.read_text(errors="replace").splitlines():
        if f"for set {set_name}" in line:
            if cur: blocks.append(cur)
            cur=[]; on=True; continue
        parts=line.split()
        if on and len(parts)>=4 and parts[0].isdigit(): cur.append(float(parts[1])*1000.0)
        elif on and "INCREMENT" in line and cur:
            blocks.append(cur); cur=[]; on=False
    if cur: blocks.append(cur)
    if not blocks: raise SystemExit("missing displacement block "+str(path))
    return blocks[-1]
specs=[
    ("CalculiX p-y beam-spring FEM","py_fem_model.inp","py_fem_model.dat","TOP","B31 beams + nonlinear SPRINGA springs","solver-level independent implementation of p-y idealization; not field validation"),
    ("CalculiX 3D continuum static","continuum_static.inp","continuum_static.dat","TOPPILE","C3D8 solid continuum","stiff continuum lower-bound check; not full nonlinear soil-pile validation"),
    ("CalculiX 3D continuum degraded","continuum_degraded.inp","continuum_degraded.dat","TOPPILE","C3D8 solid continuum","stiff continuum lower-bound check; not full nonlinear soil-pile validation"),
]
rows=[]
for name,inp,dat,set_name,etype,claim in specs:
    ip=CALC/inp; dp=CALC/dat
    for suffix in [".inp",".dat"]:
        if not (CALC/(Path(inp if suffix==".inp" else dat).name)).exists(): raise SystemExit("missing "+suffix)
    n_nodes,n_elems,types=count_inp(ip)
    disp=parse_dat(dp,set_name)
    mean=sum(disp)/len(disp); maxd=max(abs(x) for x in disp)
    rows.append({"model_name":name,"solver_version":"CalculiX 2.23.0","input_file":inp,"output_file":dat,"element_type":etype,"n_elements":n_elems,"n_nodes":n_nodes,"load_total_kN":100.0,"displacement_mean_mm":mean,"displacement_max_mm":maxd,"ratio_to_screening_25p81":mean/STRESS,"ratio_to_prediction_4p83":mean/PRED,"boundary_condition_summary":"see README_calcix_checks.md","interface_summary":"SPRINGA p-y springs" if "p-y" in name else "bonded shared-node no-slip/no-gap pile-soil interface","allowed_claim":claim})
with (BASE/"calcix_checks_trace.csv").open("w",newline="",encoding="utf-8") as f:
    fields=list(rows[0].keys()); w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
if abs(float(rows[0]["displacement_mean_mm"])-3.219416)>1e-3: raise SystemExit("p-y displacement mismatch")
if abs(float(rows[1]["displacement_mean_mm"])-0.286267)>1e-3: raise SystemExit("static continuum mismatch")
if abs(float(rows[2]["displacement_mean_mm"])-0.403105)>1e-3: raise SystemExit("degraded continuum mismatch")
print("CALCULIX CHECKS TRACE PASSED")
