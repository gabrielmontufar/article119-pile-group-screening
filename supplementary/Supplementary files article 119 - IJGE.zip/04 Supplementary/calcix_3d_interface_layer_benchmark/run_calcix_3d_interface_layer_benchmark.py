from __future__ import annotations

import csv
import math
import shutil
import subprocess
import zipfile
from pathlib import Path


ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
SUPP = ROOT / "04 Supplementary"
OUT = SUPP / "calcix_3d_interface_layer_benchmark"
ZIP_PATH = SUPP / "Supplementary files article 119 - IJGE.zip"
CCX = Path(r"C:\Users\gjm31\Documents\Codex\2026-05-14\cyclic-lateral-pile-group-optimization-with\tools\calculix\CalculiX-2.23.0-win-x64\bin\ccx.exe")

D = 0.60
R = D / 2.0
L = 8.0
SPACING = 1.5
LOAD = 100.0
E_CONC = 30_000_000.0
PRED = 4.83
LOW = 3.219
HIGH = 6.439
CENTERS = [(-0.75, -0.75), (-0.75, 0.75), (0.75, -0.75), (0.75, 0.75)]
SOIL_E = {"SOIL1": 35070.590349, "SOIL2": 96502.550712, "SOIL3": 165226.622861}


def layer_name(depth: float) -> str:
    if depth < 4.0:
        return "SOIL1"
    if depth < 8.0:
        return "SOIL2"
    return "SOIL3"


def build_coords(half_width: float, h: float, interface_thickness: float) -> list[float]:
    vals = {-half_width, half_width, 0.0}
    v = -half_width
    while v <= half_width + 1e-9:
        vals.add(round(v, 6))
        v += h
    for x0, y0 in CENTERS:
        for c in [x0, y0]:
            for off in [-R - interface_thickness, -R, R, R + interface_thickness]:
                if -half_width <= c + off <= half_width:
                    vals.add(round(c + off, 6))
    return sorted(vals)


def in_pile(xc: float, yc: float) -> bool:
    return any(abs(xc - x0) <= R and abs(yc - y0) <= R for x0, y0 in CENTERS)


def in_interface(xc: float, yc: float, thickness: float) -> bool:
    for x0, y0 in CENTERS:
        dx = abs(xc - x0)
        dy = abs(yc - y0)
        outside_square = max(dx - R, dy - R)
        near_face = outside_square >= -1e-9 and outside_square <= thickness + 1e-9
        overlaps_side = dx <= R + thickness + 1e-9 and dy <= R + thickness + 1e-9
        if near_face and overlaps_side:
            return True
    return False


def write_inp(case: str, half_width: float, hxy: float, hz: float, interface_factor: float, thickness: float) -> tuple[Path, dict[str, str]]:
    OUT.mkdir(exist_ok=True)
    xy = build_coords(half_width, hxy, thickness)
    z = [round(-L + i * hz, 6) for i in range(int(round(L / hz)) + 1)]
    if z[-1] != 0.0:
        z.append(0.0)
    z = sorted(set(z))

    node_map = {}
    node_id = 1
    lines = [
        "** CalculiX 3D interface-layer benchmark for article 119",
        "** Units: kN, m. C3D8 soil block, concrete pile inclusions, reduced-modulus interface-zone elements.",
        "*NODE,NSET=NALL",
    ]
    for k, zz in enumerate(z):
        for j, yy in enumerate(xy):
            for i, xx in enumerate(xy):
                node_map[(i, j, k)] = node_id
                lines.append(f"{node_id}, {xx:.6f}, {yy:.6f}, {zz:.6f}")
                node_id += 1

    sets = {"PILES": [], "INTERFACE": [], "SOIL1": [], "SOIL2": [], "SOIL3": []}
    top_nodes: set[int] = set()
    bottom: set[int] = set()
    xmin: set[int] = set()
    xmax: set[int] = set()
    ymin: set[int] = set()
    ymax: set[int] = set()
    lines.append("*ELEMENT,TYPE=C3D8")
    eid = 1
    for k in range(len(z) - 1):
        for j in range(len(xy) - 1):
            for i in range(len(xy) - 1):
                ns = [
                    node_map[(i, j, k)], node_map[(i + 1, j, k)], node_map[(i + 1, j + 1, k)], node_map[(i, j + 1, k)],
                    node_map[(i, j, k + 1)], node_map[(i + 1, j, k + 1)], node_map[(i + 1, j + 1, k + 1)], node_map[(i, j + 1, k + 1)],
                ]
                lines.append(f"{eid}, " + ", ".join(str(n) for n in ns))
                xc = 0.5 * (xy[i] + xy[i + 1])
                yc = 0.5 * (xy[j] + xy[j + 1])
                depth = -0.5 * (z[k] + z[k + 1])
                if in_pile(xc, yc):
                    sets["PILES"].append(eid)
                    if k == len(z) - 2:
                        top_nodes.update(ns[4:8])
                elif in_interface(xc, yc, thickness):
                    sets["INTERFACE"].append(eid)
                else:
                    sets[layer_name(depth)].append(eid)
                eid += 1

    for (i, j, k), nid in node_map.items():
        if k == 0:
            bottom.add(nid)
        if i == 0:
            xmin.add(nid)
        if i == len(xy) - 1:
            xmax.add(nid)
        if j == 0:
            ymin.add(nid)
        if j == len(xy) - 1:
            ymax.add(nid)

    def emit(kind: str, name: str, values) -> None:
        vals = sorted(values)
        lines.append(f"*{kind}, {kind}={name}")
        for start in range(0, len(vals), 12):
            lines.append(",".join(str(v) for v in vals[start:start + 12]))

    for name, values in sets.items():
        emit("ELSET", name, values)
    for name, values in [("TOPPILE", top_nodes), ("BOTTOM", bottom), ("XMINUS", xmin), ("XPLUS", xmax), ("YMINUS", ymin), ("YPLUS", ymax)]:
        emit("NSET", name, values)

    lines.extend(["*MATERIAL,NAME=CONCRETE", "*ELASTIC", f"{E_CONC:.6f}, 0.20", "*SOLID SECTION,ELSET=PILES,MATERIAL=CONCRETE"])
    for name, e in SOIL_E.items():
        lines.extend([f"*MATERIAL,NAME={name}_MAT", "*ELASTIC", f"{e:.6f}, 0.35", f"*SOLID SECTION,ELSET={name},MATERIAL={name}_MAT"])
    # Reduced-modulus layer represents unresolved gap/slip/contact compliance; modulus is
    # bounded as a fraction of the shallow degraded soil modulus, not fitted by changing all soil.
    e_interface = SOIL_E["SOIL1"] * interface_factor
    lines.extend(["*MATERIAL,NAME=INTERFACE_MAT", "*ELASTIC", f"{e_interface:.6f}, 0.35", "*SOLID SECTION,ELSET=INTERFACE,MATERIAL=INTERFACE_MAT"])
    load_per = LOAD / len(top_nodes)
    lines.extend([
        "*BOUNDARY",
        "BOTTOM, 1, 3",
        "XMINUS, 1, 1",
        "XPLUS, 1, 1",
        "YMINUS, 2, 2",
        "YPLUS, 2, 2",
        "*STEP",
        "*STATIC",
        "1.0, 1.0",
        "*CLOAD",
    ])
    for n in sorted(top_nodes):
        lines.append(f"{n}, 1, {load_per:.8f}")
    lines.extend(["*NODE PRINT,NSET=TOPPILE", "U", "*NODE FILE,NSET=TOPPILE", "U", "*END STEP"])
    inp = OUT / f"{case}.inp"
    inp.write_text("\n".join(lines) + "\n", encoding="ascii")
    meta = {
        "case": case,
        "mesh_hxy_m": f"{hxy:.3f}",
        "mesh_hz_m": f"{hz:.3f}",
        "domain_half_width_m": f"{half_width:.3f}",
        "interface_thickness_m": f"{thickness:.3f}",
        "interface_modulus_factor": f"{interface_factor:.5f}",
        "interface_E_kPa": f"{e_interface:.6f}",
        "n_nodes": str(node_id - 1),
        "n_elements": str(eid - 1),
        "n_interface_elements": str(len(sets["INTERFACE"])),
        "n_top_nodes": str(len(top_nodes)),
    }
    return inp, meta


def parse_dat(dat: Path) -> tuple[float, float]:
    blocks = []
    current = []
    in_block = False
    for line in dat.read_text(errors="replace").splitlines():
        if "displacements (vx,vy,vz)" in line or "for set TOPPILE" in line:
            if current:
                blocks.append(current)
            current = []
            in_block = True
            continue
        parts = line.split()
        if in_block and len(parts) >= 4 and parts[0].isdigit():
            current.append(float(parts[1]) * 1000.0)
        elif in_block and "INCREMENT" in line and current:
            blocks.append(current)
            current = []
            in_block = False
    if current:
        blocks.append(current)
    if not blocks:
        raise RuntimeError(f"No TOPPILE displacement block in {dat}")
    vals = blocks[-1]
    return sum(vals) / len(vals), max(abs(v) for v in vals)


def run_case(case: str, half_width: float, hxy: float, hz: float, factor: float, thickness: float) -> dict[str, str]:
    inp, meta = write_inp(case, half_width, hxy, hz, factor, thickness)
    proc = subprocess.run([str(CCX), inp.stem], cwd=str(OUT), capture_output=True, text=True, timeout=300)
    inp.with_suffix(".stdout.txt").write_text(proc.stdout, encoding="utf-8", errors="replace")
    inp.with_suffix(".stderr.txt").write_text(proc.stderr, encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout)
    mean, maxd = parse_dat(inp.with_suffix(".dat"))
    meta.update({
        "mean_top_displacement_mm": f"{mean:.6f}",
        "max_top_displacement_mm": f"{maxd:.6f}",
        "ratio_to_4p83": f"{mean / PRED:.6f}",
        "inside_3p219_6p439_band": str(LOW <= mean <= HIGH).lower(),
        "claim_allowed": "physically bounded reduced-modulus interface-layer benchmark; not field validation",
    })
    return meta


def main() -> None:
    OUT.mkdir(exist_ok=True)
    cases = [
        ("3D-0_bonded_reference", 3.6, 0.60, 1.00, 1.00000, 0.00),
        ("3D-4_interface_high", 3.6, 0.60, 1.00, 0.10000, 0.30),
        ("3D-5_interface_medium", 3.6, 0.60, 1.00, 0.03000, 0.30),
        ("3D-6_interface_low", 3.6, 0.60, 1.00, 0.01000, 0.30),
        ("3D-6b_interface_very_low", 3.6, 0.60, 1.00, 0.00300, 0.30),
        ("3D-6c_interface_extreme_low", 3.6, 0.60, 1.00, 0.00100, 0.30),
        ("3D-6d_interface_thick_low", 3.6, 0.60, 1.00, 0.00300, 0.60),
        ("3D-6e_interface_thick_extreme", 3.6, 0.60, 1.00, 0.00100, 0.60),
        ("3D-7_recommended_coarse", 3.6, 0.75, 1.00, 0.00300, 0.30),
        ("3D-7_recommended_medium", 3.6, 0.60, 1.00, 0.00300, 0.30),
        ("3D-7_recommended_xy_fine", 3.6, 0.45, 1.00, 0.00300, 0.30),
        ("3D-7_recommended_z_fine", 3.6, 0.60, 0.50, 0.00300, 0.30),
        ("3D-7_recommended_fine", 3.6, 0.45, 0.50, 0.00300, 0.30),
        ("3D-1_domain_large", 5.4, 0.60, 1.00, 0.00300, 0.30),
        ("3D-8_fine_domain_large", 5.4, 0.45, 0.50, 0.00300, 0.30),
        ("3D-9_fine_domain_extra", 7.2, 0.45, 0.50, 0.00300, 0.30),
        ("3D-10_t_half", 5.4, 0.45, 0.50, 0.00300, 0.15),
        ("3D-11_t_double", 5.4, 0.45, 0.50, 0.00300, 0.60),
        ("3D-12_Eint_low", 5.4, 0.45, 0.50, 0.00200, 0.30),
        ("3D-13_Eint_high", 5.4, 0.45, 0.50, 0.00500, 0.30),
    ]
    rows = []
    for args in cases:
        row = run_case(*args)
        rows.append(row)
        print(row)
    out_csv = AUDIT / "calcix_3d_interface_layer_benchmark.csv"
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    shutil.copy2(out_csv, OUT / out_csv.name)
    audit = AUDIT / "calcix_3d_interface_layer_benchmark_audit.md"
    medium = next(r for r in rows if r["case"] == "3D-7_recommended_medium")
    fine = next(r for r in rows if r["case"] == "3D-7_recommended_fine")
    change = (float(fine["mean_top_displacement_mm"]) / float(medium["mean_top_displacement_mm"]) - 1.0) * 100.0
    audit.write_text(
        "\n".join([
            "# CalculiX 3D interface-layer benchmark audit",
            "",
            "Purpose: replace a purely global soil-modulus compliance sweep with a physically localized reduced-modulus interface-layer benchmark.",
            "",
            "Interface representation: C3D8 elements surrounding each pile are assigned to an INTERFACE elset with reduced modulus; the remaining soil retains the degraded stratified profile.",
            "This is not nonlinear contact with gap/slip; it is a reproducible open-source approximation of unresolved interface compliance when contact modelling is not used.",
            "",
            f"Recommended medium case displacement: {medium['mean_top_displacement_mm']} mm.",
            f"Recommended fine case displacement: {fine['mean_top_displacement_mm']} mm.",
            f"Fine-vs-medium change: {change:.2f}%.",
            "",
            "Allowed claim: physically bounded interface-layer model-form benchmark within the pre-design E4 architecture.",
            "Prohibited claim: field validation or full contact FEM calibration.",
            "",
        ]),
        encoding="utf-8",
    )
    shutil.copy2(audit, OUT / audit.name)
    shutil.copy2(Path(__file__), OUT / Path(__file__).name)
    tmp = ZIP_PATH.with_suffix(".tmp.zip")
    entries = {}
    with zipfile.ZipFile(ZIP_PATH, "r") as zin:
        for info in zin.infolist():
            entries[info.filename] = zin.read(info.filename)
    for path in [out_csv, audit]:
        entries[f"06 Journal instructions and audit/{path.name}"] = path.read_bytes()
    for path in OUT.iterdir():
        if path.is_file():
            entries[f"04 Supplementary/calcix_3d_interface_layer_benchmark/{path.name}"] = path.read_bytes()
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for name, data in sorted(entries.items()):
            zout.writestr(name, data)
    tmp.replace(ZIP_PATH)


if __name__ == "__main__":
    main()
