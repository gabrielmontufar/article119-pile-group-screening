# CalculiX 3D interface-layer benchmark audit

Purpose: replace a purely global soil-modulus compliance sweep with a physically localized reduced-modulus interface-layer benchmark.

Interface representation: C3D8 elements surrounding each pile are assigned to an INTERFACE elset with reduced modulus; the remaining soil retains the degraded stratified profile.
This is not nonlinear contact with gap/slip; it is a reproducible open-source approximation of unresolved interface compliance when contact modelling is not used.

Recommended medium case displacement: 4.143226 mm.
Recommended fine case displacement: 5.642838 mm.
Fine-vs-medium change: 36.19%.

Allowed claim: physically bounded interface-layer model-form benchmark within the pre-design E4 architecture.
Prohibited claim: field validation or full contact FEM calibration.
