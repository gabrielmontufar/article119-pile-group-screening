# OpenSeesPy open-source model-form check

Purpose: add a second open-source solver so the selected-case evidence does not depend only on CalculiX.

Mean top displacement: 3.213030 mm.
Ratio to 4.83 mm FEM-anchored estimate: 0.665224.

The model uses OpenSeesPy elasticBeamColumn pile members and zeroLength ElasticMultiLinear p-y springs. The nonlinear spring backbones are parsed from the reproducible CalculiX p-y input file, but the solver, element formulation and spring implementation are independent.

Permitted claim: open-source implementation/model-form check of the p-y spring idealization.
Prohibited claim: field validation or independent physical calibration.
