from __future__ import annotations

import csv
import math
import re
import shutil
import zipfile
from pathlib import Path


ROOT = Path(r"C:\Users\gjm31\OneDrive\Escritorio\articulos up\119 avo art\Entrega International Journal of Geotechnical Engineering 20260515")
AUDIT = ROOT / "06 Journal instructions and audit"
SUPP = ROOT / "04 Supplementary"
CALCIX_INP = SUPP / "calcix_checks" / "py_fem_model.inp"
OUTDIR = SUPP / "openseespy_open_source_check"
ZIP_PATH = SUPP / "Supplementary files article 119 - IJGE.zip"


def parse_calcix_py_model(inp: Path):
    nodes: dict[int, tuple[float, float, float]] = {}
    beams: list[tuple[int, int, int]] = []
    spring_conn: list[tuple[int, str, int, int]] = []
    spring_curves: dict[str, list[tuple[float, float]]] = {}
    top_nodes = [1, 34, 67, 100]
    bottom_nodes = [17, 50, 83, 116]

    lines = inp.read_text(encoding="ascii", errors="ignore").splitlines()
    i = 0
    mode = None
    while i < len(lines):
        line = lines[i].strip()
        up = line.upper()
        if up.startswith("*NODE"):
            mode = "node"
            i += 1
            continue
        if up.startswith("*ELEMENT") and "TYPE=B31" in up:
            mode = "beam"
            i += 1
            continue
        if up.startswith("*ELEMENT") and "TYPE=SPRINGA" in up:
            m = re.search(r"ELSET=([^,\s]+)", line, re.I)
            elset = m.group(1) if m else f"SPRING_{len(spring_conn)+1}"
            raw = lines[i + 1].strip()
            parts = [p.strip() for p in raw.split(",")]
            spring_conn.append((int(parts[0]), elset, int(parts[1]), int(parts[2])))
            i += 2
            mode = None
            continue
        if up.startswith("*SPRING") and "NONLINEAR" in up:
            m = re.search(r"ELSET=([^,\s]+)", line, re.I)
            elset = m.group(1) if m else f"CURVE_{len(spring_curves)+1}"
            curve: list[tuple[float, float]] = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("*"):
                raw = lines[i].strip()
                if raw:
                    parts = [p.strip() for p in raw.split(",")]
                    if len(parts) >= 2:
                        # CalculiX nonlinear spring rows are force, displacement.
                        force = float(parts[0])
                        disp = float(parts[1])
                        curve.append((disp, force))
                i += 1
            spring_curves[elset] = curve
            mode = None
            continue
        if line.startswith("*"):
            mode = None
            i += 1
            continue

        if mode == "node" and line and not line.startswith("**"):
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 4:
                nodes[int(parts[0])] = (float(parts[1]), float(parts[2]), float(parts[3]))
        elif mode == "beam" and line and not line.startswith("**"):
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 3:
                beams.append((int(parts[0]), int(parts[1]), int(parts[2])))
        i += 1
    return nodes, beams, spring_conn, spring_curves, top_nodes, bottom_nodes


def run_opensees() -> dict[str, float | str]:
    import openseespy.opensees as ops

    nodes, beams, spring_conn, spring_curves, top_nodes, bottom_nodes = parse_calcix_py_model(CALCIX_INP)
    ops.wipe()
    ops.model("basic", "-ndm", 2, "-ndf", 3)

    pile_node_ids = sorted({n for _, n1, n2 in beams for n in (n1, n2)})
    for nid in pile_node_ids:
        x, y, z = nodes[nid]
        ops.node(nid, x, z)

    for nid in bottom_nodes:
        ops.fix(nid, 1, 1, 1)

    # Fixed auxiliary nodes colocated with pile nodes; this creates direction-1 p-y springs
    # without relying on the axial orientation convention of CalculiX SPRINGA.
    for eid, elset, _soil, pile in spring_conn:
        x, y, z = nodes[pile]
        aux = 100000 + eid
        ops.node(aux, x, z)
        ops.fix(aux, 1, 1, 1)
        curve = spring_curves[elset]
        pos = [(d, f) for d, f in curve if d >= 0]
        pts = [(-d, -f) for d, f in reversed(pos) if d > 0] + pos
        strains = [p[0] for p in pts]
        stresses = [p[1] for p in pts]
        mat = 100000 + eid
        ops.uniaxialMaterial("ElasticMultiLinear", mat, "-strain", *strains, "-stress", *stresses)
        ops.element("zeroLength", 100000 + eid, aux, pile, "-mat", mat, "-dir", 1)

    E = 30_000_000.0  # kN/m2
    nu = 0.20
    b = 0.52564076
    h = 0.52564076
    A = b * h
    Iz = b * h**3 / 12.0
    ops.geomTransf("Linear", 1)
    for eid, n1, n2 in beams:
        ops.element("elasticBeamColumn", eid, n1, n2, A, E, Iz, 1)

    ops.timeSeries("Linear", 1)
    ops.pattern("Plain", 1, 1)
    for nid in top_nodes:
        ops.load(nid, 25.0, 0.0, 0.0)

    ops.constraints("Transformation")
    ops.numberer("RCM")
    ops.system("BandGeneral")
    ops.test("NormDispIncr", 1e-10, 50)
    ops.algorithm("Newton")
    ops.integrator("LoadControl", 0.05)
    ops.analysis("Static")

    ok = 0
    for _ in range(20):
        ok = ops.analyze(1)
        if ok != 0:
            break

    disps = [ops.nodeDisp(nid, 1) * 1000.0 for nid in top_nodes]
    mean = sum(disps) / len(disps)
    maxd = max(abs(x) for x in disps)
    ops.wipe()
    return {
        "solver": "OpenSeesPy",
        "model": "independent beam-zeroLength p-y implementation",
        "source_backbone": "Calcix p-y spring backbones parsed from py_fem_model.inp",
        "load_total_kN": 100.0,
        "top_displacement_mean_mm": mean,
        "top_displacement_max_mm": maxd,
        "ratio_to_4p83": mean / 4.83,
        "analysis_ok": ok == 0,
        "allowed_claim": "open-source implementation/model-form check of the p-y spring idealization; not field validation",
    }


def write_outputs(row: dict[str, float | str]) -> None:
    OUTDIR.mkdir(exist_ok=True)
    out_csv = AUDIT / "openseespy_open_source_check.csv"
    fields = list(row.keys())
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerow(row)
    audit = AUDIT / "openseespy_open_source_check_audit.md"
    audit.write_text(
        "\n".join([
            "# OpenSeesPy open-source model-form check",
            "",
            "Purpose: add a second open-source solver so the selected-case evidence does not depend only on CalculiX.",
            "",
            f"Mean top displacement: {float(row['top_displacement_mean_mm']):.6f} mm.",
            f"Ratio to 4.83 mm FEM-anchored estimate: {float(row['ratio_to_4p83']):.6f}.",
            "",
            "The model uses OpenSeesPy elasticBeamColumn pile members and zeroLength ElasticMultiLinear p-y springs. The nonlinear spring backbones are parsed from the reproducible CalculiX p-y input file, but the solver, element formulation and spring implementation are independent.",
            "",
            "Permitted claim: open-source implementation/model-form check of the p-y spring idealization.",
            "Prohibited claim: field validation or independent physical calibration.",
            "",
        ]),
        encoding="utf-8",
    )
    shutil.copy2(out_csv, OUTDIR / out_csv.name)
    shutil.copy2(audit, OUTDIR / audit.name)
    shutil.copy2(Path(__file__), OUTDIR / Path(__file__).name)


def update_zip() -> None:
    tmp = ZIP_PATH.with_suffix(".tmp.zip")
    entries: dict[str, bytes] = {}
    if ZIP_PATH.exists():
        with zipfile.ZipFile(ZIP_PATH, "r") as zin:
            for info in zin.infolist():
                entries[info.filename] = zin.read(info.filename)
    for path in [
        AUDIT / "openseespy_open_source_check.csv",
        AUDIT / "openseespy_open_source_check_audit.md",
    ]:
        entries[f"06 Journal instructions and audit/{path.name}"] = path.read_bytes()
    for path in OUTDIR.iterdir():
        if path.is_file():
            entries[f"04 Supplementary/openseespy_open_source_check/{path.name}"] = path.read_bytes()
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for name, data in sorted(entries.items()):
            zout.writestr(name, data)
    tmp.replace(ZIP_PATH)


def main() -> None:
    row = run_opensees()
    write_outputs(row)
    update_zip()
    print(row)


if __name__ == "__main__":
    main()
